# Changelog — Endpoint Portal Tool

## [1.2.0] — 2026-10-10

### Changed
- New interface layout: dark navbar with purple underline, "Device sections" sidebar, device health
  bar, Find Device / Recent Devices / Activity Log column, and a Selected Device card with a
  12-tile diagnostics grid and action chips. Still fully offline (no CDN, no web fonts).
- Sections reorganized: Overview, Client Actions, Updates & Compliance, Apps & Software,
  Services & Processes, Users & Power, ConfigMgr Agent, Repair, Remote & Tools.
- Results now open inside the device card, under the section actions.

### Added
- Overview section with quick safe actions, hardware & agent details and storage bars.
- Device health summary computed from the diagnostics (agent service, disk, policy age,
  inventory age, cache usage, pending reboot, uptime).
- Recent Devices list remembers user, OS and health of the last 12 devices on this workstation.
- `Get-MachineInfo.ps1` now returns CcmExec state, last Machine Policy time, client cache usage,
  AD site (Netlogon DynamicSiteName) and the user's manager from Active Directory.

## [1.1.0] — 2026-10-10

### Changed
- The whole project is now in English: interface, manifest (tabs, groups, buttons, confirmations),
  script output and messages, column names, audit log, comments, README and changelog.
- Select-list values changed to English (`Yes`/`No`, `All`/`Running`/`Stopped`/`Automatic but stopped`,
  `Errors`/`Errors and warnings`). Custom buttons or scripts written for 1.0.0 that pass the old
  Portuguese values must be updated.
- Table columns renamed to English (e.g. `Nome` → `Name`, `Estado` → `State`); row-action `map`
  entries in the manifest were updated to match.
- Audit CSV header is now `Date, Operator, Computer, Action, State, Detail`. Start a new monthly
  file if you merge 1.0.0 and 1.1.0 logs.

## [1.0.0] — 2026-10-10

First web version, converted from the desktop tool (WinForms) and inspired by
SCCM Client Center 1.0.6.1 (Roger Zander) and Right Click Tools.

### Architecture
- Local server in PowerShell 5.1 (`HttpListener`), nothing to install; offline web interface.
- Every button = one `.ps1` under `scripts/`, registered in `scripts/manifest.json`.
- Parallel execution in a runspace pool with progress, live log and cancellation.
- CIM connection over WinRM with automatic fallback to DCOM.
- Session token, external Host blocking, parameter validation and CSV audit log.

### Features (76 actions)
- **Overview**: user (name and e-mail via Global Catalog), Windows release/build with UBR,
  FQDN, IP, MAC, uptime, last boot, HW/SW inventory dates, hardware, disks, agent, pending reboot.
- **Client actions**: 18 agent cycles + "run all" + full HW/SW/DDR inventory.
- **ConfigMgr agent**: details, CMTrace log reader (29 logs), maintenance windows, CCMEval,
  cache (list, delete item, clear, resize), policy reset, restart CcmExec, repair,
  exit provisioning mode, clear message queue.
- **Software**: assigned updates (list/install one, all, or mandatory), Software Center
  applications (install/repair/uninstall), installed programs.
- **System**: services (start/stop/restart), processes (terminate), run command as SYSTEM,
  user sessions, message to user, error events, pending reboot, GPUpdate,
  restart/shut down with warning, and log off.
- **Repair**: disk and system cleanup (Purge) with space gained, print queue,
  Windows Update reset, WMI verify/salvage, enable remote WinRM, flush/register DNS, renew IP.
- **Tools (local)**: connectivity test (DNS, ping, ports), RDP, C$, Computer Management,
  Event Viewer, Services MMC, MSRA, MSInfo, remote PowerShell, CM Remote Control, Registry.

### Fixes compared with the desktop version
- Errors are now shown for real (before, failures displayed placeholder data and "SUCCESS").
- `elif` (not valid PowerShell) replaced; release read from the registry (`DisplayVersion`) — build 22621
  was mapped as 23H2.
- Inventory status read from `root\ccm\invagt` (was `invcomp`, a namespace that does not exist).
- Agent cache cleared through the supported API (deleting `ccmcache` directly corrupts the client index).
- Purge deletes only `SoftwareDistribution\Download`; the full WU reset became a separate action.
