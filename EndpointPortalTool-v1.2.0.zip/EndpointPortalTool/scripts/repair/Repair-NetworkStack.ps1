<#
.SYNOPSIS  Network actions on the endpoint: flush DNS, register DNS, or renew the IP address.
.NOTES     Endpoint Portal Tool 1.1.0 - requires WinRM
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [ValidateSet('FlushDNS', 'RegisterDNS', 'RenewIP')][string]$Operation = 'FlushDNS'
)
$ErrorActionPreference = 'Stop'
$out = Invoke-EPRemote -ComputerName $ComputerName -ArgumentList $Operation -ScriptBlock {
    param($op)
    switch ($op) {
        'FlushDNS'    { ipconfig.exe /flushdns }
        'RegisterDNS' { ipconfig.exe /registerdns }
        'RenewIP'     { Start-Process cmd.exe -ArgumentList '/c ipconfig /release && ipconfig /renew' -WindowStyle Hidden; 'IP renewal started (the connection may drop for a few seconds).' }
    }
}
$out | Where-Object { "$_".Trim() } | ForEach-Object { Write-EPLog ("$_".Trim()) -Level info }
Write-EPLog "$Operation finished." -Level ok
"$Operation executed on $ComputerName."
