<#
.SYNOPSIS  Verifies or salvages the WMI repository (winmgmt /verifyrepository | /salvagerepository).
.NOTES     Endpoint Portal Tool 1.1.0 - requires WinRM
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [ValidateSet('Verify', 'Salvage')][string]$Mode = 'Verify'
)
$ErrorActionPreference = 'Stop'
Write-EPProgress 30 "winmgmt /$($Mode.ToLower())repository"
$out = Invoke-EPRemote -ComputerName $ComputerName -ArgumentList $Mode -ScriptBlock {
    param($m)
    $o = & winmgmt.exe "/$($m.ToLower())repository" 2>&1
    [pscustomobject]@{ Output = ($o -join ' ').Trim(); Code = $LASTEXITCODE }
}
Write-EPProgress 100
Write-EPLog "winmgmt: $($out.Output) (exit code $($out.Code))" -Level $(if ($out.Code -eq 0) { 'ok' } else { 'warn' })
"WMI $Mode on ${ComputerName}: $($out.Output)"
