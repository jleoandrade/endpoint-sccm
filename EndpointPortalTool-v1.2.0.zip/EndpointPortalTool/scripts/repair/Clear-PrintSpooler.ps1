<#
.SYNOPSIS  Clears a stuck print queue (stops Spooler, deletes spool\PRINTERS, starts Spooler).
.NOTES     Endpoint Portal Tool 1.1.0 - uses CIM + admin$ (WinRM not required)
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    $svc = Get-CimInstance -CimSession $s -ClassName Win32_Service -Filter "Name='Spooler'"
    Write-EPProgress 25 'Stopping Spooler'
    if ($svc.State -ne 'Stopped') {
        Invoke-CimMethod -InputObject $svc -MethodName StopService | Out-Null
        if (-not (Wait-EPServiceState -CimSession $s -Name 'Spooler' -State 'Stopped')) { throw 'Spooler did not stop.' }
    }
    Write-EPProgress 55 'Clearing queue'
    $files = @(Get-ChildItem "\\$ComputerName\admin$\System32\spool\PRINTERS" -File -Force -ErrorAction SilentlyContinue)
    $files | Remove-Item -Force -ErrorAction SilentlyContinue
    Write-EPLog "$($files.Count) queue file(s) removed." -Level ok
    Write-EPProgress 80 'Starting Spooler'
    Invoke-CimMethod -InputObject (Get-CimInstance -CimSession $s -ClassName Win32_Service -Filter "Name='Spooler'") -MethodName StartService | Out-Null
    if (-not (Wait-EPServiceState -CimSession $s -Name 'Spooler' -State 'Running')) { throw 'Spooler did not start.' }
    Write-EPProgress 100
    "Print queue cleared on $ComputerName."
}
