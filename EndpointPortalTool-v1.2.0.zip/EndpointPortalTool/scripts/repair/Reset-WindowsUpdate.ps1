<#
.SYNOPSIS  Full reset of Windows Update components (renames SoftwareDistribution and catroot2).
.NOTES     Endpoint Portal Tool 1.1.0 - requires WinRM. Deletes the local update history.
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
Write-EPProgress 15 'Stopping services (wuauserv, bits, cryptsvc, msiserver)'
$out = Invoke-EPRemote -ComputerName $ComputerName -ScriptBlock {
    $svcs = 'wuauserv', 'bits', 'cryptsvc', 'msiserver'
    Stop-Service $svcs -Force -ErrorAction SilentlyContinue
    $stamp = Get-Date -Format 'yyyyMMddHHmmss'
    $log = @()
    foreach ($p in "$env:windir\SoftwareDistribution", "$env:windir\System32\catroot2") {
        if (Test-Path $p) {
            try { Rename-Item $p "$(Split-Path $p -Leaf).bak$stamp" -ErrorAction Stop; $log += "Renamed: $p" }
            catch { $log += "Could not rename $p : $($_.Exception.Message)" }
        }
    }
    Start-Service $svcs -ErrorAction SilentlyContinue
    & "$env:windir\System32\wuauclt.exe" /resetauthorization 2>$null
    $log += 'Services restarted.'
    $log
}
Write-EPProgress 100
$out | ForEach-Object { Write-EPLog $_ -Level $(if ($_ -like 'Could not*') { 'warn' } else { 'ok' }) }
"Windows Update components reset on $ComputerName. Run 'Software Update Scan' next."
