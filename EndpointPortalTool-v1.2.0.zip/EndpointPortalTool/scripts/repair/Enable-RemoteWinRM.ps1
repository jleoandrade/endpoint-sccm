<#
.SYNOPSIS  Enables PowerShell Remoting (WinRM) on the endpoint over DCOM/WMI (same as the EnablePSRemoting plugin).
.NOTES     Endpoint Portal Tool 1.1.0
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
Write-EPProgress 10 'Connecting over DCOM'
try {
    $s = New-CimSession -ComputerName $ComputerName -SessionOption (New-CimSessionOption -Protocol Dcom) -ErrorAction Stop
} catch { throw "DCOM/RPC is also unavailable on $ComputerName (firewall?). Detail: $($_.Exception.Message)" }
try {
    $cmd = 'powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Enable-PSRemoting -Force -SkipNetworkProfileCheck; Set-Service WinRM -StartupType Automatic"'
    Write-EPProgress 30 'Running Enable-PSRemoting on the endpoint'
    $r = Invoke-CimMethod -CimSession $s -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cmd }
    if ($r.ReturnValue -ne 0) { throw "Win32_Process.Create returned $($r.ReturnValue)" }
    $deadline = (Get-Date).AddSeconds(60)
    do {
        Start-Sleep -Seconds 3
        Write-EPProgress 60 'Waiting for WinRM to respond'
        $ok = $false
        try { $null = Test-WSMan -ComputerName $ComputerName -ErrorAction Stop; $ok = $true } catch {}
    } until ($ok -or (Get-Date) -gt $deadline)
    Write-EPProgress 100
    if (-not $ok) { throw 'Command sent, but WinRM is still not responding. A GPO or firewall may be blocking port 5985.' }
    Write-EPLog 'WinRM enabled and responding.' -Level ok
    "WinRM enabled on $ComputerName."
}
finally { Remove-CimSession $s -ErrorAction SilentlyContinue }
