<#
.SYNOPSIS  Disk and system cleanup ("Disk and System Purge" from the desktop version) with real per-step progress.
.DESCRIPTION
    Steps: Windows\Temp, profile Temp folders, WER, Prefetch, CBS/WU logs, print spooler, CCM\Temp,
    agent cache (supported API), SoftwareDistribution\Download and Recycle Bin.
    Shows free space before and after.
.NOTES     Endpoint Portal Tool 1.1.0 - requires WinRM
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [ValidateSet('Yes', 'No')][string]$IncludeCcmCache = 'Yes'
)
$ErrorActionPreference = 'Stop'

Write-EPProgress 2 'Opening remote session'
try { $ps = New-PSSession -ComputerName $ComputerName -ErrorAction Stop }
catch { throw "WinRM did not respond on $ComputerName. Use 'Repair > Enable remote WinRM'. Detail: $($_.Exception.Message)" }

# Generic block run on the endpoint: removes folder contents and returns the bytes freed
$purge = {
    param([string[]]$Paths, [string]$Pattern = '*')
    $freed = 0; $count = 0
    foreach ($p in $Paths) {
        $p = [Environment]::ExpandEnvironmentVariables($p)
        foreach ($dir in @(Get-Item -Path $p -Force -ErrorAction SilentlyContinue)) {
            Get-ChildItem -LiteralPath $dir.FullName -Filter $Pattern -Force -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object {
                $len = $_.Length
                try { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction Stop; $freed += $len; $count++ } catch {}
            }
            if ($Pattern -eq '*') {
                Get-ChildItem -LiteralPath $dir.FullName -Force -Directory -ErrorAction SilentlyContinue |
                    Sort-Object { $_.FullName.Length } -Descending | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
            }
        }
    }
    [pscustomobject]@{ Bytes = $freed; Files = $count }
}

$steps = @(
    @{ P = 8;  N = 'Windows\Temp';                    S = $purge; A = @(, @('%windir%\Temp')) }
    @{ P = 20; N = 'User profile Temp folders';       S = $purge; A = @(, @('%SystemDrive%\Users\*\AppData\Local\Temp')) }
    @{ P = 30; N = 'Windows Error Reporting (WER)';   S = $purge; A = @(, @('%ProgramData%\Microsoft\Windows\WER\ReportQueue', '%ProgramData%\Microsoft\Windows\WER\ReportArchive')) }
    @{ P = 38; N = 'Prefetch';                        S = $purge; A = @(, @('%windir%\Prefetch')) }
    @{ P = 46; N = 'CBS logs (*.cab)';                S = $purge; A = @(@('%windir%\Logs\CBS'), '*.cab') }
    @{ P = 50; N = 'Old CBS logs';                    S = $purge; A = @(@('%windir%\Logs\CBS'), 'CbsPersist*.log') }
    @{ P = 56; N = 'Agent temp (CCM\Temp)';           S = $purge; A = @(, @('%windir%\CCM\Temp')) }
    @{ P = 64; N = 'Print spooler'; S = {
        Stop-Service Spooler -Force -ErrorAction SilentlyContinue
        $d = Join-Path $env:windir 'System32\spool\PRINTERS'; $b = 0; $c = 0
        Get-ChildItem $d -File -Force -ErrorAction SilentlyContinue | ForEach-Object { $b += $_.Length; $c++; Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue }
        Start-Service Spooler -ErrorAction SilentlyContinue
        [pscustomobject]@{ Bytes = $b; Files = $c } }; A = @() }
    @{ P = 76; N = 'ConfigMgr agent cache'; Skip = ($IncludeCcmCache -ne 'Yes'); S = {
        $b = 0; $c = 0
        try {
            $ci = (New-Object -ComObject UIResource.UIResourceMgr).GetCacheInfo()
            foreach ($e in @($ci.GetCacheElements())) { try { $ci.DeleteCacheElement($e.CacheElementID); $b += $e.ContentSize * 1KB; $c++ } catch {} }
        } catch {}
        [pscustomobject]@{ Bytes = $b; Files = $c } }; A = @() }
    @{ P = 88; N = 'Windows Update (Download)'; S = {
        Stop-Service wuauserv, bits -Force -ErrorAction SilentlyContinue
        $d = Join-Path $env:windir 'SoftwareDistribution\Download'; $b = 0; $c = 0
        Get-ChildItem $d -Recurse -File -Force -ErrorAction SilentlyContinue | ForEach-Object { $b += $_.Length; $c++ }
        Get-ChildItem $d -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        Start-Service bits, wuauserv -ErrorAction SilentlyContinue
        [pscustomobject]@{ Bytes = $b; Files = $c } }; A = @() }
    @{ P = 95; N = 'Recycle Bin';                     S = $purge; A = @(, @('%SystemDrive%\$Recycle.Bin\*')) }
)

try {
    $free = { (Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'").FreeSpace }
    $before = Invoke-Command -Session $ps -ScriptBlock $free
    $total = 0
    foreach ($st in $steps) {
        if ($st.Skip) { Write-EPLog "$($st.N): skipped" -Level debug; continue }
        Write-EPProgress $st.P $st.N
        try {
            $r = Invoke-Command -Session $ps -ScriptBlock $st.S -ArgumentList $st.A -ErrorAction Stop
            $total += $r.Bytes
            Write-EPLog ("{0}: {1} file(s), {2}" -f $st.N, $r.Files, (Format-EPSize $r.Bytes)) -Level ok
        } catch { Write-EPLog "$($st.N): $($_.Exception.Message)" -Level warn }
    }
    $after = Invoke-Command -Session $ps -ScriptBlock $free
    Write-EPProgress 100 'Done'
    Write-EPLog ("Cleanup finished. Free space: {0} -> {1} (+{2})" -f (Format-EPSize $before), (Format-EPSize $after), (Format-EPSize ([Math]::Max(0, $after - $before)))) -Level ok
    [pscustomobject]@{
        'Free before'    = Format-EPSize $before
        'Free after'     = Format-EPSize $after
        'Space gained'   = Format-EPSize ([Math]::Max(0, $after - $before))
        'Total removed'  = Format-EPSize $total
    }
}
finally { Remove-PSSession $ps -ErrorAction SilentlyContinue }
