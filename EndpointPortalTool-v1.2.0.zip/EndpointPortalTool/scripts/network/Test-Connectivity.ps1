<#
.SYNOPSIS  Connectivity diagnostics for the endpoint: DNS, ping and management ports.
.NOTES     Endpoint Portal Tool 1.1.0 - runs on the technician's workstation
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'

function Test-Port([string]$h, [int]$port, [int]$timeout = 1500) {
    $c = New-Object Net.Sockets.TcpClient
    try { $a = $c.BeginConnect($h, $port, $null, $null); if ($a.AsyncWaitHandle.WaitOne($timeout) -and $c.Connected) { $c.EndConnect($a); return $true }; return $false }
    catch { return $false } finally { $c.Close() }
}

$rows = New-Object System.Collections.Generic.List[object]
Write-EPProgress 10 'Resolving DNS'
$ips = @()
try { $ips = @([Net.Dns]::GetHostAddresses($ComputerName) | Where-Object AddressFamily -eq 'InterNetwork' | ForEach-Object IPAddressToString) } catch {}
$rows.Add([pscustomobject]@{ Test = 'DNS'; Result = $(if ($ips) { 'OK' } else { 'FAIL' }); Detail = $(if ($ips) { $ips -join ', ' } else { 'Name does not resolve' }) })
if ($ips -and $ComputerName -notmatch '^\d+\.\d+\.\d+\.\d+$') {
    try {
        $rev = [Net.Dns]::GetHostEntry($ips[0]).HostName
        $same = $rev.Split('.')[0] -eq $ComputerName.Split('.')[0]
        $rows.Add([pscustomobject]@{ Test = 'Reverse DNS'; Result = $(if ($same) { 'OK' } else { 'WARNING' }); Detail = "$($ips[0]) -> $rev" + $(if (-not $same) { ' (stale DNS record?)' } else { '' }) })
    } catch { $rows.Add([pscustomobject]@{ Test = 'Reverse DNS'; Result = 'N/A'; Detail = 'No PTR record' }) }
}

Write-EPProgress 30 'Ping'
$ping = New-Object Net.NetworkInformation.Ping
$replies = @(1..4 | ForEach-Object { try { $ping.Send($ComputerName, 1000) } catch { $null } })
$okRep = @($replies | Where-Object { $_ -and $_.Status -eq 'Success' })
$rows.Add([pscustomobject]@{ Test = 'Ping (ICMP)'; Result = $(if ($okRep) { 'OK' } else { 'FAIL' })
    Detail = $(if ($okRep) { "$($okRep.Count)/4 replies, average $([int]($okRep | Measure-Object RoundtripTime -Average).Average) ms" } else { 'No reply (may be a firewall)' }) })

$ports = [ordered]@{ 135 = 'RPC/DCOM (WMI)'; 445 = 'SMB (admin$)'; 3389 = 'RDP'; 5985 = 'WinRM HTTP'; 5986 = 'WinRM HTTPS'; 2701 = 'CM Remote Control'; 10123 = 'ConfigMgr Client Notification' }
$i = 0
foreach ($kv in $ports.GetEnumerator()) {
    $i++; Write-EPProgress (40 + [int](55 * $i / $ports.Count)) "Port $($kv.Key)"
    $open = Test-Port $ComputerName ([int]$kv.Key)
    $rows.Add([pscustomobject]@{ Test = "TCP $($kv.Key)"; Result = $(if ($open) { 'OPEN' } else { 'CLOSED' }); Detail = $kv.Value })
}
Write-EPProgress 100
$fail = @($rows | Where-Object { $_.Result -in 'FAIL' }).Count
Write-EPLog "Diagnostics finished for $ComputerName." -Level $(if ($fail) { 'warn' } else { 'ok' })
$rows
