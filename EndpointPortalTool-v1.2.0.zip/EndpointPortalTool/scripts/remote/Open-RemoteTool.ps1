<#
.SYNOPSIS  Opens admin tools ON THE TECHNICIAN'S WORKSTATION pointed at the endpoint (Right Click Tools style).
.NOTES     Endpoint Portal Tool 1.1.0
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][ValidateSet('RDP', 'CShare', 'CompMgmt', 'EventViewer', 'Services', 'MSRA', 'MSInfo', 'PSSession', 'CMRemote', 'Regedit')][string]$Tool
)
$ErrorActionPreference = 'Stop'
$c = $ComputerName
switch ($Tool) {
    'RDP'         { Start-Process 'mstsc.exe' -ArgumentList "/v:$c" }
    'CShare'      { Start-Process 'explorer.exe' -ArgumentList "\\$c\C$" }
    'CompMgmt'    { Start-Process 'compmgmt.msc' -ArgumentList "/computer:\\$c" }
    'EventViewer' { Start-Process 'eventvwr.msc' -ArgumentList "/computer:$c" }
    'Services'    { Start-Process 'services.msc' -ArgumentList "/computer:$c" }
    'MSRA'        { Start-Process 'msra.exe' -ArgumentList "/offerra $c" }
    'MSInfo'      { Start-Process 'msinfo32.exe' -ArgumentList "/computer $c" }
    'Regedit'     { Start-Process 'regedit.exe'; Write-EPLog "In Regedit use File > Connect Network Registry > $c" -Level info }
    'PSSession'   { Start-Process 'powershell.exe' -ArgumentList '-NoExit', '-Command', "Enter-PSSession -ComputerName $c" }
    'CMRemote'    {
        $paths = @()
        if ($env:SMS_ADMIN_UI_PATH) { $paths += Join-Path (Split-Path $env:SMS_ADMIN_UI_PATH) 'i386\CmRcViewer.exe' }
        $paths += "${env:ProgramFiles(x86)}\Microsoft Endpoint Manager\AdminConsole\bin\i386\CmRcViewer.exe",
                  "${env:ProgramFiles(x86)}\Microsoft Configuration Manager\AdminConsole\bin\i386\CmRcViewer.exe"
        $exe = $paths | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
        if (-not $exe) { throw 'CmRcViewer.exe not found. Install the ConfigMgr console on this workstation.' }
        Start-Process $exe -ArgumentList $c
    }
}
Write-EPLog "$Tool opened for $c on this workstation." -Level ok
"$Tool opened for $c."
