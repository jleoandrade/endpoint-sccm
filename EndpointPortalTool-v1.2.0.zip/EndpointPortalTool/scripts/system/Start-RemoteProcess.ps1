<#
.SYNOPSIS  Runs a command on the endpoint as SYSTEM via Win32_Process.Create (no window, no output returned).
.NOTES     Endpoint Portal Tool 1.1.0
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][string]$CommandLine
)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    $r = Invoke-CimMethod -CimSession $s -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $CommandLine }
    if ($r.ReturnValue -ne 0) { throw "Create: $(Get-EPWin32Message $r.ReturnValue)" }
    Write-EPLog "Process started (PID $($r.ProcessId)): $CommandLine" -Level ok
    "Command started on $ComputerName (PID $($r.ProcessId))."
}
