<#
.SYNOPSIS  Recent critical/error/warning events from the Event Viewer.
.NOTES     Endpoint Portal Tool 1.1.0 - WinRM; falls back to RPC (Get-WinEvent -ComputerName)
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [ValidateSet('System', 'Application', 'Setup')][string]$LogName = 'System',
    [int]$Hours = 24,
    [ValidateSet('Errors', 'Errors and warnings')][string]$Level = 'Errors'
)
$ErrorActionPreference = 'Stop'
$levels = if ($Level -eq 'Errors') { 1, 2 } else { 1, 2, 3 }
$filter = @{ LogName = $LogName; Level = $levels; StartTime = (Get-Date).AddHours(-[Math]::Min([Math]::Max($Hours, 1), 720)) }
Write-EPProgress 30 "Reading $LogName"
$sb = { param($f) Get-WinEvent -FilterHashtable $f -MaxEvents 300 -ErrorAction SilentlyContinue |
        Select-Object TimeCreated, LevelDisplayName, ProviderName, Id, Message }
try { $ev = Invoke-EPRemote -ComputerName $ComputerName -ScriptBlock $sb -ArgumentList $filter }
catch {
    Write-EPLog 'WinRM unavailable; using RPC.' -Level debug
    $ev = Get-WinEvent -ComputerName $ComputerName -FilterHashtable $filter -MaxEvents 300 -ErrorAction SilentlyContinue
}
$rows = @($ev | ForEach-Object {
    [pscustomobject]@{
        Time     = Format-EPDate $_.TimeCreated
        Level    = $_.LevelDisplayName
        Source   = $_.ProviderName
        EventId  = $_.Id
        Message  = if ($_.Message) { ($_.Message -split "`r?`n")[0] } else { '' }
    }
})
Write-EPProgress 100
Write-EPLog "$($rows.Count) event(s) in $LogName over the last $Hours h." -Level $(if ($rows.Count) { 'warn' } else { 'ok' })
$rows
