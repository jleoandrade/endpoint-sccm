<#
.SYNOPSIS  Forces a Group Policy update (computer) on the endpoint.
.NOTES     Endpoint Portal Tool 1.1.0 - requires WinRM
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [ValidateSet('Computer', 'Computer+User')][string]$Target = 'Computer'
)
$ErrorActionPreference = 'Stop'
Write-EPProgress 20 'Running gpupdate /force'
$out = Invoke-EPRemote -ComputerName $ComputerName -ArgumentList $Target -ScriptBlock {
    param($t)
    if ($t -eq 'Computer') { gpupdate.exe /target:computer /force /wait:120 2>&1 } else { gpupdate.exe /force /wait:120 2>&1 }
}
Write-EPProgress 100
$out | Where-Object { $_ -and "$_".Trim() } | ForEach-Object { Write-EPLog ("$_".Trim()) -Level info }
Write-EPLog 'gpupdate finished.' -Level ok
"Group Policy updated on $ComputerName."
