<#
.SYNOPSIS  Sends a pop-up message to every session on the endpoint (msg.exe).
.NOTES     Endpoint Portal Tool 1.1.0 - WinRM; falls back to msg /server (RPC)
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][string]$Message,
    [int]$TimeoutSeconds = 300
)
$ErrorActionPreference = 'Stop'
$Message = $Message -replace '[\r\n]+', ' '
try {
    Invoke-EPRemote -ComputerName $ComputerName -ArgumentList $Message, $TimeoutSeconds -ScriptBlock {
        param($m, $t) & msg.exe * /TIME:$t $m; if ($LASTEXITCODE) { throw "msg.exe returned $LASTEXITCODE" }
    }
} catch {
    Write-EPLog "WinRM failed ($($_.Exception.Message)); trying msg /server." -Level debug
    & msg.exe * /SERVER:$ComputerName /TIME:$TimeoutSeconds $Message
    if ($LASTEXITCODE) { throw "msg.exe returned $LASTEXITCODE" }
}
Write-EPLog 'Message delivered.' -Level ok
"Message sent to $ComputerName."
