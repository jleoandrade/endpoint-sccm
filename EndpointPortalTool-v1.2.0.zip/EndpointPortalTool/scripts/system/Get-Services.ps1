<#
.SYNOPSIS  Windows services on the endpoint.
.NOTES     Endpoint Portal Tool 1.1.0
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [ValidateSet('All', 'Running', 'Stopped', 'Automatic but stopped')][string]$Show = 'All'
)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    $svc = @(Get-CimInstance -CimSession $s -ClassName Win32_Service)
    switch ($Show) {
        'Running'               { $svc = @($svc | Where-Object State -eq 'Running') }
        'Stopped'               { $svc = @($svc | Where-Object State -eq 'Stopped') }
        'Automatic but stopped' { $svc = @($svc | Where-Object { $_.StartMode -eq 'Auto' -and $_.State -ne 'Running' }) }
    }
    Write-EPLog "$($svc.Count) service(s)." -Level ok
    $svc | Sort-Object DisplayName | ForEach-Object {
        [pscustomobject]@{ Name = $_.Name; DisplayName = $_.DisplayName; State = $_.State; StartMode = $_.StartMode; Account = $_.StartName; PID = $_.ProcessId }
    }
}
