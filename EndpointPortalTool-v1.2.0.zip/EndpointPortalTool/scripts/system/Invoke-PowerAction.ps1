<#
.SYNOPSIS  Restart, shut down or log off the endpoint, warning the user with a countdown.
.NOTES     Endpoint Portal Tool 1.1.0
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][ValidateSet('Restart', 'Shutdown', 'Logoff')][string]$Operation,
    [int]$DelaySeconds = 300,
    [string]$Message = 'IT Support will restart this computer. Please save your work.'
)
$ErrorActionPreference = 'Stop'
$DelaySeconds = [Math]::Min([Math]::Max($DelaySeconds, 0), 3600)
$flags = @{ Logoff = 4; Shutdown = 12; Restart = 6 }   # 4 = forced, 8 = power off, 2 = reboot
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    $os = Get-CimInstance -CimSession $s -ClassName Win32_OperatingSystem
    if ($Operation -eq 'Logoff') {
        $r = Invoke-CimMethod -InputObject $os -MethodName Win32Shutdown -Arguments @{ Flags = $flags[$Operation] }
    } else {
        $r = Invoke-CimMethod -InputObject $os -MethodName Win32ShutdownTracker -Arguments @{
            Timeout = [uint32]$DelaySeconds; Comment = $Message; ReasonCode = [uint32]0; Flags = $flags[$Operation] }
    }
    if ($r.ReturnValue -ne 0) { throw "$Operation returned $($r.ReturnValue) (1191 = session in use / missing privilege)" }
    Write-EPLog "$Operation scheduled on $ComputerName (in $DelaySeconds s)." -Level ok
    "$Operation sent to $ComputerName."
}
