<#
.SYNOPSIS  Processes running on the endpoint.
.NOTES     Endpoint Portal Tool 1.1.0
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    $p = @(Get-CimInstance -CimSession $s -ClassName Win32_Process)
    Write-EPLog "$($p.Count) process(es)." -Level ok
    $p | Sort-Object WorkingSetSize -Descending | ForEach-Object {
        [pscustomobject]@{
            Name          = $_.Name
            PID           = $_.ProcessId
            'Memory MB'   = [Math]::Round($_.WorkingSetSize / 1MB, 1)
            Threads       = $_.ThreadCount
            Started       = Format-EPDate $_.CreationDate
            Path          = $_.ExecutablePath
            CommandLine   = if ($_.CommandLine -and $_.CommandLine.Length -gt 180) { $_.CommandLine.Substring(0, 180) + '...' } else { $_.CommandLine }
        }
    }
}
