<#
.SYNOPSIS  Starts, stops or restarts a service on the endpoint (via CIM, WinRM not required).
.NOTES     Endpoint Portal Tool 1.1.0
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][string]$Name,
    [Parameter(Mandatory)][ValidateSet('Start', 'Stop', 'Restart')][string]$State
)
$ErrorActionPreference = 'Stop'
if ($Name -notmatch '^[\w\.\-\$ ]+$') { throw 'Invalid service name.' }
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    $svc = Get-CimInstance -CimSession $s -ClassName Win32_Service -Filter "Name='$Name'"
    if (-not $svc) { throw "Service '$Name' does not exist on $ComputerName." }
    if ($State -in 'Stop', 'Restart' -and $svc.State -ne 'Stopped') {
        Write-EPProgress 25 "Stopping $Name"
        $r = Invoke-CimMethod -InputObject $svc -MethodName StopService
        if ($r.ReturnValue -notin 0, 5) { throw "StopService: $(Get-EPWin32Message $r.ReturnValue)" }
        if (-not (Wait-EPServiceState -CimSession $s -Name $Name -State 'Stopped')) { throw "$Name did not stop within the timeout." }
        Write-EPLog "$Name stopped." -Level ok
    }
    if ($State -in 'Start', 'Restart') {
        Write-EPProgress 65 "Starting $Name"
        $svc = Get-CimInstance -CimSession $s -ClassName Win32_Service -Filter "Name='$Name'"
        if ($svc.StartMode -eq 'Disabled') { throw "$Name is disabled." }
        $r = Invoke-CimMethod -InputObject $svc -MethodName StartService
        if ($r.ReturnValue -notin 0, 10) { throw "StartService: $(Get-EPWin32Message $r.ReturnValue)" }
        if (-not (Wait-EPServiceState -CimSession $s -Name $Name -State 'Running')) { throw "$Name did not start within the timeout." }
        Write-EPLog "$Name is running." -Level ok
    }
    Write-EPProgress 100
    "Service $Name ($State) completed on $ComputerName."
}
