<#
.SYNOPSIS  Terminates a process on the endpoint by PID.
.NOTES     Endpoint Portal Tool 1.1.0
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][int]$ProcessId
)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    $p = Get-CimInstance -CimSession $s -ClassName Win32_Process -Filter "ProcessId=$ProcessId"
    if (-not $p) { throw "PID $ProcessId no longer exists." }
    $r = Invoke-CimMethod -InputObject $p -MethodName Terminate
    if ($r.ReturnValue -ne 0) { throw "Terminate: $(Get-EPWin32Message $r.ReturnValue)" }
    Write-EPLog "$($p.Name) (PID $ProcessId) terminated." -Level ok
    "Process $($p.Name) terminated on $ComputerName."
}
