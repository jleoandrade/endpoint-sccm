<#
.SYNOPSIS  User sessions (console/RDP) on the endpoint.
.NOTES     Endpoint Portal Tool 1.1.0 - WinRM (quser); falls back to CIM
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
try {
    $lines = Invoke-EPRemote -ComputerName $ComputerName -ScriptBlock { quser.exe 2>$null }
    $rows = @($lines | Select-Object -Skip 1 | ForEach-Object {
        $t = ($_.Trim() -replace '^>', '') -split '\s{2,}'
        if ($t.Count -eq 6) { [pscustomobject]@{ User = $t[0]; Session = $t[1]; Id = $t[2]; State = $t[3]; Idle = $t[4]; LogonTime = $t[5] } }
        elseif ($t.Count -eq 5) { [pscustomobject]@{ User = $t[0]; Session = ''; Id = $t[1]; State = $t[2]; Idle = $t[3]; LogonTime = $t[4] } }
    })
} catch {
    Write-EPLog "quser unavailable ($($_.Exception.Message)); using CIM." -Level debug
    $rows = Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
        param($s)
        $u = (Get-CimInstance -CimSession $s -ClassName Win32_ComputerSystem).UserName
        if ($u) { [pscustomobject]@{ User = $u; Session = 'console'; Id = ''; State = 'Active'; Idle = ''; LogonTime = '' } }
    }
}
Write-EPLog "$(@($rows).Count) session(s)." -Level ok
if (-not $rows) { return 'No user logged on.' }
$rows
