<#
.SYNOPSIS  Checks every pending-reboot source (CBS, Windows Update, file rename operations, ConfigMgr).
.NOTES     Endpoint Portal Tool 1.1.0
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    $cbs = Test-EPRegKey -CimSession $s -Key 'SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'
    $wu  = Test-EPRegKey -CimSession $s -Key 'SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
    $pfr = Get-EPRegValue -CimSession $s -Key 'SYSTEM\CurrentControlSet\Control\Session Manager' -Name 'PendingFileRenameOperations' -Type MultiString
    $ccm = 'N/A'
    try {
        $r = Invoke-CimMethod -CimSession $s -Namespace 'root\ccm\ClientSDK' -ClassName CCM_ClientUtilities -MethodName DetermineIfRebootPending -ErrorAction Stop
        $ccm = if ($r.IsHardRebootPending) { 'Yes (hard)' } elseif ($r.RebootPending) { 'Yes' } else { 'No' }
    } catch {}
    $os = Get-CimInstance -CimSession $s -ClassName Win32_OperatingSystem
    $any = $cbs -or $wu -or [bool]$pfr -or $ccm -like 'Yes*'
    Write-EPLog $(if ($any) { 'Reboot PENDING.' } else { 'No reboot pending.' }) -Level $(if ($any) { 'warn' } else { 'ok' })
    [pscustomobject]@{
        'Reboot pending'              = if ($any) { 'YES' } else { 'No' }
        'Component Based Servicing'   = if ($cbs) { 'Yes' } else { 'No' }
        'Windows Update'              = if ($wu) { 'Yes' } else { 'No' }
        'Pending file renames'        = if ($pfr) { "Yes ($(@($pfr).Count) entries)" } else { 'No' }
        'ConfigMgr'                   = $ccm
        'Last boot'                   = Format-EPDate $os.LastBootUpTime
    }
}
