<#
.SYNOPSIS  Connects to the endpoint and collects the overview (the "Computer" panel).
.NOTES     Endpoint Portal Tool 1.2.0
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'

Write-EPProgress 5 'Opening CIM session'
$s = New-EPCimSession -ComputerName $ComputerName
try {
    Write-EPProgress 20 'Operating system'
    $os   = Get-CimInstance -CimSession $s -ClassName Win32_OperatingSystem
    $cs   = Get-CimInstance -CimSession $s -ClassName Win32_ComputerSystem
    $bios = Get-CimInstance -CimSession $s -ClassName Win32_BIOS
    $cpu  = Get-CimInstance -CimSession $s -ClassName Win32_Processor | Select-Object -First 1

    # Release (DisplayVersion: 22H2/23H2/24H2/25H2) and UBR read from the registry - more accurate than mapping by build
    $cvKey   = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion'
    $release = Get-EPRegValue -CimSession $s -Key $cvKey -Name 'DisplayVersion'
    if (-not $release) { $release = Get-EPRegValue -CimSession $s -Key $cvKey -Name 'ReleaseId' }
    $ubr     = Get-EPRegValue -CimSession $s -Key $cvKey -Name 'UBR' -Type DWORD
    $build   = if ($null -ne $ubr) { "$($os.Version).$ubr" } else { $os.Version }
    if (-not $release) {
        $map = @{ '19045' = '22H2'; '22621' = '22H2'; '22631' = '23H2'; '26100' = '24H2'; '26200' = '25H2' }
        $release = $map[[string]$os.BuildNumber]; if (-not $release) { $release = "Build $($os.BuildNumber)" }
    }

    Write-EPProgress 40 'Network'
    $nets = @(Get-CimInstance -CimSession $s -ClassName Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=True')
    $net  = $nets | Where-Object { $_.DefaultIPGateway } | Select-Object -First 1
    if (-not $net) { $net = $nets | Select-Object -First 1 }
    $ipv4 = if ($net) { $net.IPAddress | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' } | Select-Object -First 1 } else { '-' }

    Write-EPProgress 55 'Disks'
    $disks = @(Get-CimInstance -CimSession $s -ClassName Win32_LogicalDisk -Filter 'DriveType=3' | ForEach-Object {
        $total = [double]$_.Size; $free = [double]$_.FreeSpace
        [pscustomobject]@{
            Drive   = $_.DeviceID
            Label   = $_.VolumeName
            TotalGB = [Math]::Round($total / 1GB, 1)
            FreeGB  = [Math]::Round($free / 1GB, 1)
            UsedPct = if ($total -gt 0) { [int](100 * ($total - $free) / $total) } else { 0 }
        }
    })

    $boot   = $os.LastBootUpTime
    $uptime = (Get-Date) - $boot
    $user   = if ($cs.UserName) { $cs.UserName } else { $null }

    Write-EPProgress 65 'ConfigMgr agent'
    $ccm = [ordered]@{ ClientVersion = 'Not installed'; SiteCode = '-'; ManagementPoint = '-'; HwScan = '-'; SwScan = '-'; RebootPending = '-'
                       CcmExecState = 'Not installed'; LastMachinePolicy = '-'; CacheUsedMB = $null; CacheSizeMB = $null }
    $ccmSvc = Get-CimInstance -CimSession $s -ClassName Win32_Service -Filter "Name='CcmExec'" -ErrorAction SilentlyContinue
    if ($ccmSvc) { $ccm.CcmExecState = $ccmSvc.State }
    if (Test-EPCcmClient -CimSession $s) {
        try { $ccm.ClientVersion = (Get-CimInstance -CimSession $s -Namespace 'root\ccm' -ClassName SMS_Client).ClientVersion } catch {}
        try {
            $auth = Get-CimInstance -CimSession $s -Namespace 'root\ccm' -ClassName SMS_Authority | Select-Object -First 1
            if ($auth) { $ccm.SiteCode = ($auth.Name -replace '^SMS:', ''); $ccm.ManagementPoint = $auth.CurrentManagementPoint }
        } catch {}
        try {
            $inv = Get-CimInstance -CimSession $s -Namespace 'root\ccm\invagt' -ClassName InventoryActionStatus
            $hw = $inv | Where-Object { $_.InventoryActionID -eq '{00000000-0000-0000-0000-000000000001}' }
            $sw = $inv | Where-Object { $_.InventoryActionID -eq '{00000000-0000-0000-0000-000000000002}' }
            if ($hw) { $ccm.HwScan = Format-EPDate $(if ($hw.LastReportDate) { $hw.LastReportDate } else { $hw.LastCycleStartedDate }) }
            if ($sw) { $ccm.SwScan = Format-EPDate $(if ($sw.LastReportDate) { $sw.LastReportDate } else { $sw.LastCycleStartedDate }) }
        } catch {}
        try {
            $hist = Get-CimInstance -CimSession $s -Namespace 'root\ccm\Scheduler' -ClassName CCM_Scheduler_History `
                -Filter "ScheduleID='{00000000-0000-0000-0000-000000000021}' AND UserSID='Machine'" | Select-Object -First 1
            if ($hist) { $ccm.LastMachinePolicy = Format-EPDate $hist.LastTriggerTime }
        } catch {}
        try {
            $cfg = Get-CimInstance -CimSession $s -Namespace 'root\ccm\SoftMgmtAgent' -ClassName CacheConfig | Select-Object -First 1
            $used = (Get-CimInstance -CimSession $s -Namespace 'root\ccm\SoftMgmtAgent' -ClassName CacheInfoEx | Measure-Object ContentSize -Sum).Sum
            if ($cfg) { $ccm.CacheSizeMB = [int]$cfg.Size; $ccm.CacheUsedMB = [int]([double]$used / 1024) }
        } catch {}
        try {
            $rb = Invoke-CimMethod -CimSession $s -Namespace 'root\ccm\ClientSDK' -ClassName CCM_ClientUtilities -MethodName DetermineIfRebootPending
            $ccm.RebootPending = if ($rb.RebootPending -or $rb.IsHardRebootPending) { 'Yes' } else { 'No' }
        } catch {}
    }

    $adSite = Get-EPRegValue -CimSession $s -Key 'SYSTEM\CurrentControlSet\Services\Netlogon\Parameters' -Name 'DynamicSiteName'

    # Full name, e-mail and manager via Global Catalog (multi-domain), same as the desktop version
    $fullName = if ($user) { $user } else { 'No user logged on' }
    $email = '-'; $manager = '-'
    if ($user -and $user -match '\\') {
        Write-EPProgress 85 'Active Directory'
        try {
            $sam    = $user.Split('\')[-1]
            $forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
            $search = New-Object System.DirectoryServices.DirectorySearcher(New-Object System.DirectoryServices.DirectoryEntry("GC://$($forest.Name)"))
            $search.Filter = "(&(objectCategory=person)(sAMAccountName=$sam))"
            [void]$search.PropertiesToLoad.Add('displayname'); [void]$search.PropertiesToLoad.Add('mail'); [void]$search.PropertiesToLoad.Add('manager')
            $ad = $search.FindOne()
            if ($ad) {
                if ($ad.Properties['displayname'].Count) { $fullName = "$($ad.Properties['displayname'][0]) ($user)" }
                if ($ad.Properties['mail'].Count) { $email = [string]$ad.Properties['mail'][0] }
                if ($ad.Properties['manager'].Count) {
                    $mgrDn = [string]$ad.Properties['manager'][0]
                    $manager = ($mgrDn -replace '^CN=((?:[^,\\]|\\.)+),.*$', '$1') -replace '\\,', ','
                    try {
                        $m = New-Object System.DirectoryServices.DirectoryEntry("GC://$($forest.Name)/$mgrDn")
                        if ($m.Properties['displayName'].Count) { $manager = [string]$m.Properties['displayName'][0] }
                    } catch {}
                }
            }
        } catch { Write-EPLog "Active Directory lookup unavailable: $($_.Exception.Message)" -Level debug }
    }

    Write-EPProgress 100 'Done'
    Write-EPLog "Connected to $($cs.Name) ($($s.Protocol))" -Level ok

    [pscustomobject]@{
        ComputerName    = $cs.Name
        FullName        = $fullName
        Email           = $email
        Manager         = $manager
        OS              = $os.Caption
        Release         = $release
        Build           = $build
        FQDN            = if ($cs.Domain) { "$($cs.Name).$($cs.Domain)".ToLower() } else { $cs.Name }
        IPAddress       = $ipv4
        MACAddress      = if ($net) { $net.MACAddress } else { '-' }
        Uptime          = '{0}d {1}h {2}m' -f [int][Math]::Floor($uptime.TotalDays), $uptime.Hours, $uptime.Minutes
        LastBoot        = Format-EPDate $boot
        HwScan          = $ccm.HwScan
        SwScan          = $ccm.SwScan
        Manufacturer    = $cs.Manufacturer
        Model           = $cs.Model
        SerialNumber    = $bios.SerialNumber
        CPU             = ($cpu.Name -replace '\s+', ' ').Trim()
        MemoryGB        = [Math]::Round($cs.TotalPhysicalMemory / 1GB, 1)
        ClientVersion   = $ccm.ClientVersion
        SiteCode        = $ccm.SiteCode
        ManagementPoint = $ccm.ManagementPoint
        RebootPending   = $ccm.RebootPending
        CcmExecState    = $ccm.CcmExecState
        LastMachinePolicy = $ccm.LastMachinePolicy
        CacheUsedMB     = $ccm.CacheUsedMB
        CacheSizeMB     = $ccm.CacheSizeMB
        ADSite          = if ($adSite) { $adSite } else { '-' }
        Protocol        = [string]$s.Protocol
        Disks           = $disks
    }
}
finally { Remove-CimSession $s -ErrorAction SilentlyContinue }
