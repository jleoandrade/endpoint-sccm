<#
.SYNOPSIS  Clears the agent message queue (ServiceData\Messaging) and restarts CcmExec.
.NOTES     Endpoint Portal Tool 1.1.0 - requires WinRM
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
Write-EPProgress 20 'Stopping CcmExec'
$r = Invoke-EPRemote -ComputerName $ComputerName -ScriptBlock {
    Stop-Service CcmExec -Force -ErrorAction Stop
    (Get-Service CcmExec).WaitForStatus('Stopped', [TimeSpan]::FromSeconds(60))
    $q = Join-Path $env:windir 'CCM\ServiceData\Messaging\EndpointQueues'
    $n = 0
    if (Test-Path $q) { $files = Get-ChildItem $q -Recurse -File -ErrorAction SilentlyContinue; $n = @($files).Count; $files | Remove-Item -Force -ErrorAction SilentlyContinue }
    Start-Service CcmExec
    $n
}
Write-EPProgress 100
Write-EPLog "$r message(s) removed from the queue; CcmExec restarted." -Level ok
"Message queue cleared on $ComputerName."
