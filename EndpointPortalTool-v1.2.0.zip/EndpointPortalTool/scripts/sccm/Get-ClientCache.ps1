<#
.SYNOPSIS  Lists the contents of the agent cache (ccmcache).
.NOTES     Endpoint Portal Tool 1.1.0
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    $cfg = Get-CimInstance -CimSession $s -Namespace 'root\ccm\SoftMgmtAgent' -ClassName CacheConfig
    $items = @(Get-CimInstance -CimSession $s -Namespace 'root\ccm\SoftMgmtAgent' -ClassName CacheInfoEx)
    $usedMB = [Math]::Round((($items | Measure-Object ContentSize -Sum).Sum) / 1024, 0)
    Write-EPLog "Cache: $($cfg.Location) - $usedMB MB used of $($cfg.Size) MB, $($items.Count) item(s)." -Level ok
    $items | Sort-Object LastReferenced -Descending | ForEach-Object {
        [pscustomobject]@{
            ContentId    = $_.ContentId
            Version      = $_.ContentVer
            'Size MB'    = [Math]::Round($_.ContentSize / 1024, 1)
            'Last Used'  = Format-EPDate $_.LastReferenced
            Persistent   = [bool]$_.PersistInCache
            Location     = $_.Location
            CacheId      = $_.CacheId
        }
    }
}
