<#
.SYNOPSIS  Changes the maximum size of the agent cache (MB).
.NOTES     Endpoint Portal Tool 1.1.0 - requires WinRM
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][int]$SizeMB
)
$ErrorActionPreference = 'Stop'
if ($SizeMB -lt 1024 -or $SizeMB -gt 512000) { throw 'Enter a size between 1024 and 512000 MB.' }
$old = Invoke-EPRemote -ComputerName $ComputerName -ArgumentList $SizeMB -ScriptBlock {
    param($size)
    $mgr = New-Object -ComObject UIResource.UIResourceMgr
    $c = $mgr.GetCacheInfo(); $prev = $c.TotalSize; $c.TotalSize = $size; $prev
}
Write-EPLog "Cache changed from $old MB to $SizeMB MB." -Level ok
"Cache size on ${ComputerName}: $SizeMB MB."
