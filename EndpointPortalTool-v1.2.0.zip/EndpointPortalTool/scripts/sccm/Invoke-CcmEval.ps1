<#
.SYNOPSIS  Runs the agent health evaluation (CcmEval.exe) and shows the ccmeval report.
.NOTES     Endpoint Portal Tool 1.1.0 - requires WinRM
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
Write-EPProgress 10 'Running CcmEval.exe (may take up to 1 minute)'
$rows = Invoke-EPRemote -ComputerName $ComputerName -ScriptBlock {
    $exe = Join-Path $env:windir 'CCM\CcmEval.exe'
    if (-not (Test-Path $exe)) { throw 'CcmEval.exe not found (agent missing?).' }
    $p = Start-Process -FilePath $exe -PassThru -WindowStyle Hidden
    if (-not $p.WaitForExit(120000)) { throw 'CcmEval took longer than 2 minutes.' }
    $xmlPath = Join-Path $env:windir 'CCM\CcmEvalReport.xml'
    if (-not (Test-Path $xmlPath)) { throw 'CcmEvalReport.xml was not generated.' }
    [xml]$x = Get-Content $xmlPath
    foreach ($h in $x.ClientHealthReport.HealthChecks.HealthCheck) {
        [pscustomobject]@{ Check = $h.Description; Result = $h.InnerText; Code = $h.ResultCode; Detail = $h.ResultDetail }
    }
}
Write-EPProgress 100
$fail = @($rows | Where-Object { $_.Result -notmatch 'Passed|Not Applicable' }).Count
Write-EPLog ("CcmEval finished: {0} checks, {1} failed." -f @($rows).Count, $fail) -Level $(if ($fail) { 'warn' } else { 'ok' })
$rows | Select-Object Check, Result, Code, Detail
