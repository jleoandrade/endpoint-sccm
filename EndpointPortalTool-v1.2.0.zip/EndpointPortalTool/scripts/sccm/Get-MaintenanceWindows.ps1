<#
.SYNOPSIS  Maintenance windows (service windows) applied to the endpoint.
.NOTES     Endpoint Portal Tool 1.1.0
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
$types = @{ 1 = 'All deployments'; 2 = 'Programs'; 3 = 'Reboot required'; 4 = 'Software updates'; 5 = 'Task sequences'; 6 = 'Corporate (user defined)' }
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    $w = @(Get-CimInstance -CimSession $s -Namespace 'root\ccm\ClientSDK' -ClassName CCM_ServiceWindow)
    if (-not $w.Count) { Write-EPLog 'No maintenance windows: deployments can run at any time.' -Level info; return }
    Write-EPLog "$($w.Count) window(s) found." -Level ok
    $w | Sort-Object StartTime | ForEach-Object {
        [pscustomobject]@{
            Start          = Format-EPDate $_.StartTime
            End            = Format-EPDate $_.EndTime
            'Duration (h)' = [Math]::Round($_.Duration / 3600, 1)
            Type           = $types[[int]$_.Type]
            Id             = $_.ID
        }
    }
}
