<#
.SYNOPSIS  Takes the agent out of provisioning mode (common after a failed OSD).
.NOTES     Endpoint Portal Tool 1.1.0
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    $prov = Get-EPRegValue -CimSession $s -Key 'SOFTWARE\Microsoft\CCM\CcmExec' -Name 'ProvisioningMode'
    Write-EPLog "Current ProvisioningMode: $(if ($prov) { $prov } else { 'not set' })" -Level info
    Invoke-CimMethod -CimSession $s -Namespace 'root\ccm' -ClassName SMS_Client -MethodName SetClientProvisioningMode -Arguments @{ bEnable = $false } | Out-Null
    Write-EPLog 'Provisioning mode disabled.' -Level ok
    "Provisioning mode disabled on $ComputerName."
}
