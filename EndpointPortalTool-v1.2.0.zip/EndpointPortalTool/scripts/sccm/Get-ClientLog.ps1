<#
.SYNOPSIS  Reads the last lines of an agent log (CMTrace format) through the admin$ share.
.NOTES     Endpoint Portal Tool 1.1.0 - uses SMB (\\computer\admin$); falls back to WinRM when needed
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][string]$LogName,
    [int]$Lines = 200,
    [string]$Filter = ''
)
$ErrorActionPreference = 'Stop'
if ($LogName -notmatch '^[\w\.\-]+\.log$') { throw 'Invalid log name (e.g. PolicyAgent.log).' }
$Lines = [Math]::Min([Math]::Max($Lines, 10), 2000)

Write-EPProgress 20 "Reading $LogName"
$unc = "\\$ComputerName\admin$\CCM\Logs\$LogName"
$raw = $null
try {
    if (Test-Path -LiteralPath $unc) { $raw = Get-Content -LiteralPath $unc -Tail ($Lines * 4) }
    else { throw 'not reachable over SMB' }
} catch {
    Write-EPLog "admin$ unavailable ($($_.Exception.Message)); trying WinRM" -Level debug
    $raw = Invoke-EPRemote -ComputerName $ComputerName -ArgumentList $LogName, ($Lines * 4) -ScriptBlock {
        param($n, $t)
        $p = Join-Path $env:windir "CCM\Logs\$n"
        if (-not (Test-Path $p)) { throw "Log $n does not exist on the endpoint." }
        Get-Content $p -Tail $t
    }
}
Write-EPProgress 70 'Parsing'
$text = ($raw -join "`n")
$rx = [regex]'<!\[LOG\[(?<msg>[\s\S]*?)\]LOG\]!><time="(?<time>[^"+\-]+)[^"]*" date="(?<date>[^"]+)" component="(?<comp>[^"]*)"[^>]*?type="(?<type>\d)"'
$types = @{ '1' = 'Info'; '2' = 'Warning'; '3' = 'Error' }
$rows = foreach ($m in $rx.Matches($text)) {
    [pscustomobject]@{
        Time      = "$($m.Groups['date'].Value) $($m.Groups['time'].Value.Split('.')[0])"
        Type      = $types[$m.Groups['type'].Value]
        Component = $m.Groups['comp'].Value
        Message   = $m.Groups['msg'].Value.Trim()
    }
}
if (-not $rows) {
    # Plain-text log (e.g. older ccmsetup, WindowsUpdate)
    $rows = $raw | Select-Object -Last $Lines | ForEach-Object { [pscustomobject]@{ Time = ''; Type = ''; Component = ''; Message = $_ } }
}
if ($Filter) { $rows = $rows | Where-Object { $_.Message -like "*$Filter*" -or $_.Component -like "*$Filter*" } }
$rows = @($rows | Select-Object -Last $Lines)
[array]::Reverse($rows)
Write-EPProgress 100
$err = @($rows | Where-Object { $_.Type -eq 'Error' }).Count
Write-EPLog "$LogName : $($rows.Count) lines (newest first), $err error(s)." -Level $(if ($err) { 'warn' } else { 'ok' })
$rows
