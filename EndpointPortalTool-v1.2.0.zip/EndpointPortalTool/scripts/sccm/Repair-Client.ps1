<#
.SYNOPSIS  Repairs the ConfigMgr agent (SMS_Client.RepairClient -> ccmrepair).
.NOTES     Endpoint Portal Tool 1.1.0
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    Write-EPProgress 40 'Starting agent repair'
    Invoke-CimMethod -CimSession $s -Namespace 'root\ccm' -ClassName SMS_Client -MethodName RepairClient | Out-Null
    Write-EPLog 'Repair started. The CcmExec service will be restarted by the agent itself.' -Level ok
    Write-EPProgress 100
    "Agent repair started on $ComputerName. Follow C:\Windows\CCM\Logs\ccmrepair.log / ccmsetup.log."
}
