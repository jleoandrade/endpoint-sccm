<#
.SYNOPSIS  ConfigMgr agent details: version, site, MP, cache, provisioning mode, components.
.NOTES     Endpoint Portal Tool 1.1.0
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    Write-EPProgress 20 'Reading agent'
    $cli  = Get-CimInstance -CimSession $s -Namespace 'root\ccm' -ClassName SMS_Client
    $id   = Get-CimInstance -CimSession $s -Namespace 'root\ccm' -ClassName CCM_Client -ErrorAction SilentlyContinue
    $auth = Get-CimInstance -CimSession $s -Namespace 'root\ccm' -ClassName SMS_Authority -ErrorAction SilentlyContinue | Select-Object -First 1
    $cache = Get-CimInstance -CimSession $s -Namespace 'root\ccm\SoftMgmtAgent' -ClassName CacheConfig -ErrorAction SilentlyContinue
    $svc  = Get-CimInstance -CimSession $s -ClassName Win32_Service -Filter "Name='CcmExec'"
    $prov = Get-EPRegValue -CimSession $s -Key 'SOFTWARE\Microsoft\CCM\CcmExec' -Name 'ProvisioningMode'
    Write-EPProgress 60 'Components'
    $comps = Get-CimInstance -CimSession $s -Namespace 'root\ccm' -ClassName CCM_InstalledComponent -ErrorAction SilentlyContinue
    Write-EPProgress 100
    [pscustomobject]@{
        'Agent version'      = $cli.ClientVersion
        'Site'               = if ($auth) { $auth.Name -replace '^SMS:', '' } else { '-' }
        'Management Point'   = if ($auth) { $auth.CurrentManagementPoint } else { '-' }
        'Client ID (GUID)'   = if ($id) { $id.ClientId } else { '-' }
        'CcmExec service'    = "$($svc.State) / $($svc.StartMode)"
        'Provisioning mode'  = if ($prov -eq 'true') { 'ACTIVE (agent blocked)' } else { 'Off' }
        'Cache folder'       = if ($cache) { $cache.Location } else { '-' }
        'Cache size (MB)'    = if ($cache) { $cache.Size } else { '-' }
        'Components'         = (@($comps | Sort-Object Name | ForEach-Object { "$($_.Name) $($_.Version)" }) -join '; ')
    }
}
