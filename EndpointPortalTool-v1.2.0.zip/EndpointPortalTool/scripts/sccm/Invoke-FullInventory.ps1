<#
.SYNOPSIS  FULL hardware or software inventory: removes the last cycle status and triggers it again.
.NOTES     Endpoint Portal Tool 1.1.0
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][ValidateSet('Hardware', 'Software', 'Discovery')][string]$Type
)
$ErrorActionPreference = 'Stop'
$ids = @{ Hardware = '{00000000-0000-0000-0000-000000000001}'; Software = '{00000000-0000-0000-0000-000000000002}'; Discovery = '{00000000-0000-0000-0000-000000000003}' }
$id = $ids[$Type]

Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    Write-EPProgress 30 "Removing last $Type inventory status"
    $st = Get-CimInstance -CimSession $s -Namespace 'root\ccm\invagt' -ClassName InventoryActionStatus -Filter "InventoryActionID='$id'"
    if ($st) { $st | Remove-CimInstance; Write-EPLog 'Previous status removed (the next report will be a full one).' -Level info }
    else { Write-EPLog 'No previous status found.' -Level debug }
    Write-EPProgress 70 'Triggering cycle'
    Invoke-EPSchedule -CimSession $s -ScheduleId $id
    Write-EPLog "Full $Type inventory triggered." -Level ok
    Write-EPProgress 100
    "Full $Type inventory triggered on $ComputerName. See InventoryAgent.log."
}
