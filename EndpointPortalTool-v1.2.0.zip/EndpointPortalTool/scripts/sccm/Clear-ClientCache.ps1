<#
.SYNOPSIS  Clears the agent cache through the supported API (UIResource.UIResourceMgr) without corrupting its index.
.PARAMETER IncludePersistent  'Yes' also removes items marked as persistent.
.PARAMETER CacheId            Optional: removes a single item only.
.NOTES     Endpoint Portal Tool 1.1.0 - requires WinRM
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [ValidateSet('No', 'Yes')][string]$IncludePersistent = 'No',
    [string]$CacheId = ''
)
$ErrorActionPreference = 'Stop'
Write-EPProgress 20 'Clearing agent cache'
$r = Invoke-EPRemote -ComputerName $ComputerName -ArgumentList ($IncludePersistent -eq 'Yes'), $CacheId -ScriptBlock {
    param($persist, $only)
    $mgr = New-Object -ComObject UIResource.UIResourceMgr
    $cache = $mgr.GetCacheInfo()
    $removed = 0; $freed = 0; $skipped = 0
    foreach ($e in @($cache.GetCacheElements())) {
        if ($only -and $e.CacheElementID -ne $only) { continue }
        try {
            if ($persist) { $cache.DeleteCacheElementEx($e.CacheElementID, $true) } else { $cache.DeleteCacheElement($e.CacheElementID) }
            $removed++; $freed += $e.ContentSize
        } catch { $skipped++ }
    }
    [pscustomobject]@{ Removed = $removed; FreedMB = [Math]::Round($freed / 1024, 1); Skipped = $skipped }
}
Write-EPProgress 100
Write-EPLog "Cache: $($r.Removed) item(s) removed, $($r.FreedMB) MB freed, $($r.Skipped) skipped (in use/persistent)." -Level ok
"Cache cleared on $ComputerName - $($r.FreedMB) MB freed."
