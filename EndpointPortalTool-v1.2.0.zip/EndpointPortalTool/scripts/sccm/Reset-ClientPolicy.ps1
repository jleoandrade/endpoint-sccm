<#
.SYNOPSIS  Resets agent policies (SMS_Client.ResetPolicy) and requests Machine Policy again.
.PARAMETER Mode  Soft = re-applies policies; Hard = purges all policies and downloads them again.
.NOTES     Endpoint Portal Tool 1.1.0
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [ValidateSet('Soft', 'Hard')][string]$Mode = 'Hard'
)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    Write-EPProgress 30 "Policy reset ($Mode)"
    $flag = if ($Mode -eq 'Hard') { [uint32]1 } else { [uint32]0 }
    Invoke-CimMethod -CimSession $s -Namespace 'root\ccm' -ClassName SMS_Client -MethodName ResetPolicy -Arguments @{ uFlags = $flag } | Out-Null
    Write-EPLog "ResetPolicy($flag) executed." -Level ok
    Start-Sleep -Seconds 3
    Write-EPProgress 70 'Requesting Machine Policy'
    Invoke-EPSchedule -CimSession $s -ScheduleId '{00000000-0000-0000-0000-000000000021}'
    Write-EPLog 'Machine Policy Retrieval triggered.' -Level ok
    Write-EPProgress 100
    "Policies reset ($Mode) on $ComputerName. Follow PolicyAgent.log."
}
