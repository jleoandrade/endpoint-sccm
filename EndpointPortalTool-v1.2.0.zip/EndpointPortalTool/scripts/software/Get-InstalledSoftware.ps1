<#
.SYNOPSIS  Software installed on the endpoint (Programs and Features).
.NOTES     Endpoint Portal Tool 1.1.0 - uses ConfigMgr inventory; falls back to reading the registry over WinRM
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [string]$Filter = ''
)
$ErrorActionPreference = 'Stop'
$rows = $null
$s = New-EPCimSession -ComputerName $ComputerName
try {
    Write-EPProgress 30 'Querying SMS_InstalledSoftware'
    try {
        $rows = @(Get-CimInstance -CimSession $s -Namespace 'root\cimv2\sms' -ClassName SMS_InstalledSoftware -ErrorAction Stop | ForEach-Object {
            [pscustomobject]@{ Name = $_.ProductName; Version = $_.ProductVersion; Publisher = $_.Publisher
                InstallDate = Format-EPDate $_.InstallDate 'yyyy-MM-dd'; UninstallString = $_.UninstallString }
        })
    } catch { Write-EPLog 'SMS_InstalledSoftware inventory unavailable; reading the registry over WinRM.' -Level debug }
} finally { Remove-CimSession $s -ErrorAction SilentlyContinue }

if (-not $rows) {
    Write-EPProgress 50 'Reading registry'
    $rows = Invoke-EPRemote -ComputerName $ComputerName -ScriptBlock {
        $keys = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
        Get-ItemProperty $keys -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -and -not $_.SystemComponent } | ForEach-Object {
            [pscustomobject]@{ Name = $_.DisplayName; Version = $_.DisplayVersion; Publisher = $_.Publisher
                InstallDate = $_.InstallDate; UninstallString = $_.UninstallString }
        }
    } | Select-Object Name, Version, Publisher, InstallDate, UninstallString
}
if ($Filter) { $rows = @($rows | Where-Object { $_.Name -like "*$Filter*" -or $_.Publisher -like "*$Filter*" }) }
$rows = @($rows | Sort-Object Name -Unique)
Write-EPProgress 100
Write-EPLog "$($rows.Count) installed program(s)." -Level ok
$rows
