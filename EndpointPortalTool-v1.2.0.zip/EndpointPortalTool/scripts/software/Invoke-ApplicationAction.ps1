<#
.SYNOPSIS  Installs, uninstalls or repairs a ConfigMgr application on the endpoint.
.NOTES     Endpoint Portal Tool 1.1.0
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][ValidateSet('Install', 'Uninstall', 'Repair')][string]$Operation,
    [Parameter(Mandatory)][string]$Id,
    [Parameter(Mandatory)][string]$Revision,
    [string]$IsMachineTarget = 'True'
)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    $args2 = @{
        Id = $Id; Revision = $Revision; IsMachineTarget = [bool]::Parse([string]$IsMachineTarget)
        EnforcePreference = [uint32]0; Priority = 'High'; IsRebootIfNeeded = $false
    }
    Write-EPProgress 40 "$Operation submitted"
    $r = Invoke-CimMethod -CimSession $s -Namespace 'root\ccm\ClientSDK' -ClassName CCM_Application -MethodName $Operation -Arguments $args2
    if ($r.ReturnValue -ne 0) { throw "$Operation returned $($r.ReturnValue)" }
    Write-EPLog "$Operation accepted by the agent (Job $($r.JobId))." -Level ok
    Write-EPProgress 100
    "$Operation requested on $ComputerName. Follow AppEnforce.log."
}
