<#
.SYNOPSIS  Installs assigned updates (all, only mandatory ones, or a single one).
.PARAMETER Scope     All | Mandatory | Single
.PARAMETER UpdateID  Used with Scope=Single
.NOTES     Endpoint Portal Tool 1.1.0
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [ValidateSet('All', 'Mandatory', 'Single')][string]$Scope = 'All',
    [string]$UpdateID = ''
)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    # Only "available/failed/waiting" states can be submitted for installation
    $u = @(Get-CimInstance -CimSession $s -Namespace 'root\ccm\ClientSDK' -ClassName CCM_SoftwareUpdate |
        Where-Object { $_.EvaluationState -in 0, 1, 13, 14, 21 })
    if ($Scope -eq 'Mandatory') { $u = @($u | Where-Object { $_.Deadline }) }
    if ($Scope -eq 'Single')    { $u = @($u | Where-Object { $_.UpdateID -eq $UpdateID }) }
    if (-not $u.Count) { Write-EPLog 'No update is eligible for installation right now.' -Level warn; return 'Nothing to install.' }
    Write-EPProgress 40 "Submitting $($u.Count) update(s)"
    $r = Invoke-CimMethod -CimSession $s -Namespace 'root\ccm\ClientSDK' -ClassName CCM_SoftwareUpdatesManager -MethodName InstallUpdates -Arguments @{ CCMUpdates = [ciminstance[]]$u }
    if ($r.ReturnValue -ne 0) { throw "InstallUpdates returned $($r.ReturnValue)" }
    foreach ($x in $u) { Write-EPLog "Submitted: KB$($x.ArticleID) $($x.Name)" -Level ok }
    Write-EPProgress 100
    "$($u.Count) update(s) submitted for installation on $ComputerName. Use 'Refresh' to follow progress."
}
