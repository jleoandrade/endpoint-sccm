<#
.SYNOPSIS  Updates assigned to the endpoint by ConfigMgr (Software Center > Updates).
.NOTES     Endpoint Portal Tool 1.1.0
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
$states = @{ 0='None';1='Available';2='Submitted';3='Detecting';4='PreDownload';5='Downloading';6='Waiting to install';7='Installing';
  8='Pending soft reboot';9='Pending hard reboot';10='Waiting for reboot';11='Verifying';12='Installed';13='Error';
  14='Waiting for maintenance window';15='Waiting for user logon';16='Waiting for user logoff';17='Waiting for job user logon';18='Waiting for user reconnect';
  19='Pending user logoff';20='Pending update';21='Waiting to retry';22='Waiting for presentation mode off';23='Waiting for orchestration' }
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    $u = @(Get-CimInstance -CimSession $s -Namespace 'root\ccm\ClientSDK' -ClassName CCM_SoftwareUpdate)
    $err = @($u | Where-Object { $_.EvaluationState -eq 13 }).Count
    Write-EPLog "$($u.Count) assigned update(s); $err in error." -Level $(if ($err) { 'warn' } else { 'ok' })
    $u | Sort-Object EvaluationState, ArticleID | ForEach-Object {
        [pscustomobject]@{
            KB        = "KB$($_.ArticleID)"
            Name      = $_.Name
            State     = $states[[int]$_.EvaluationState]
            '%'       = $_.PercentComplete
            Deadline  = Format-EPDate $_.Deadline
            Error     = if ($_.ErrorCode) { '0x{0:X8}' -f $_.ErrorCode } else { '' }
            UpdateID  = $_.UpdateID
        }
    }
}
