<#
.SYNOPSIS  Applications made available by ConfigMgr (Software Center > Applications).
.NOTES     Endpoint Portal Tool 1.1.0
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    Write-EPProgress 30 'Querying CCM_Application'
    $apps = @(Get-CimInstance -CimSession $s -Namespace 'root\ccm\ClientSDK' -ClassName CCM_Application)
    Write-EPLog "$($apps.Count) application(s) visible to the endpoint." -Level ok
    $apps | Sort-Object Name | ForEach-Object {
        [pscustomobject]@{
            Name            = $_.Name
            Version         = $_.SoftwareVersion
            Publisher       = $_.Publisher
            InstallState    = $_.InstallState
            Evaluation      = $_.EvaluationState
            Target          = if ($_.IsMachineTarget) { 'Device' } else { 'User' }
            Error           = if ($_.ErrorCode) { '0x{0:X8}' -f $_.ErrorCode } else { '' }
            Id              = $_.Id
            Revision        = $_.Revision
            IsMachineTarget = [bool]$_.IsMachineTarget
        }
    }
}
