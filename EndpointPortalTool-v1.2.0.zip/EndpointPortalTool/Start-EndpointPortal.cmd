@echo off
REM Endpoint Portal Tool - starts the local web portal (no installation required)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-EndpointPortal.ps1" %*
