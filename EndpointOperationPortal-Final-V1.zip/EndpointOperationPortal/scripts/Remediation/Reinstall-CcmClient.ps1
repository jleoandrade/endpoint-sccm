# Uninstalls and reinstalls the ConfigMgr client. Run elevated. Provide your environment values.
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$ManagementPoint,
  [Parameter(Mandatory)][string]$SiteCode,
  [Parameter(Mandatory)][string]$SourcePath   # UNC path to the client source
)
Start-Process "$env:SystemRoot\ccmsetup\ccmsetup.exe" -ArgumentList '/uninstall' -Wait
Start-Sleep -Seconds 30
Remove-Item "$env:SystemRoot\CCM" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item "$env:SystemRoot\SMSCFG.ini" -Force -ErrorAction SilentlyContinue
Start-Process "$env:SystemRoot\ccmsetup\ccmsetup.exe" -ArgumentList "/service /forceinstall /mp:$ManagementPoint /source:`"$SourcePath`" SMSSITECODE=$SiteCode RESETKEYINFORMATION=TRUE"
"ccmsetup reinstall started for site $SiteCode"
