# Deletes all elements from the ConfigMgr client cache. Run elevated.
$mgr = New-Object -ComObject UIResource.UIResourceMgr
$cache = $mgr.GetCacheInfo()
$elements = $cache.GetCacheElements()
foreach ($e in $elements) { $cache.DeleteCacheElement($e.CacheElementID) }
[pscustomobject]@{ RemovedElements = @($elements).Count }
