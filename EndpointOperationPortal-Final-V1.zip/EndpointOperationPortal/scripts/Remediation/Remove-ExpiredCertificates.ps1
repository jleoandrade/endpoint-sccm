# Removes expired certificates from the LocalMachine store. Run elevated. Do not run on a CA.
Get-ChildItem Cert:\LocalMachine -Recurse | Where-Object { $_.NotAfter -and $_.NotAfter -lt (Get-Date) } | ForEach-Object {
  [pscustomobject]@{ Removed = $_.Subject; Expired = $_.NotAfter }
  Remove-Item $_.PSPath -Force -ErrorAction SilentlyContinue
}
