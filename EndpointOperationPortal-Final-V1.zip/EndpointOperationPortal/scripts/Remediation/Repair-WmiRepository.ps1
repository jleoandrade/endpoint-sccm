# Verifies and, if inconsistent, salvages the WMI repository. Run elevated.
$verify = & winmgmt /verifyrepository
if ($verify -match 'inconsistent') {
  Stop-Service ccmexec -Force -ErrorAction SilentlyContinue
  & winmgmt /salvagerepository
  Start-Service winmgmt -ErrorAction SilentlyContinue
  Start-Service ccmexec -ErrorAction SilentlyContinue
  'WMI repository salvaged'
} else { 'WMI repository consistent' }
