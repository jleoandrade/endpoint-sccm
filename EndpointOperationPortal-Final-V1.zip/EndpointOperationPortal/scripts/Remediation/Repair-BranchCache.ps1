# Resets and reconfigures BranchCache in distributed mode. Run elevated.
netsh branchcache reset | Out-Null
netsh branchcache set service mode=DISTRIBUTED | Out-Null
Set-Service PeerDistSvc -StartupType Automatic -ErrorAction SilentlyContinue
Start-Service PeerDistSvc -ErrorAction SilentlyContinue
'BranchCache reset to DISTRIBUTED mode'
