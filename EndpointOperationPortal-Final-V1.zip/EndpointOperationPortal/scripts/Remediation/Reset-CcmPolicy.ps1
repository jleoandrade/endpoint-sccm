# Performs a full ConfigMgr machine policy reset. Run elevated.
Invoke-CimMethod -Namespace 'root\ccm' -ClassName SMS_Client -MethodName ResetPolicy -Arguments @{ uFlags = [uint32]1 } | Out-Null
'Machine policy reset requested'
