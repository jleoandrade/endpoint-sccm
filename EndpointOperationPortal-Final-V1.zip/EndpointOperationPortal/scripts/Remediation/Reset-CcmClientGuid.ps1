# Resets the ConfigMgr client identity (GUID) by removing SMSCFG.ini. Run elevated.
Stop-Service ccmexec -Force
Remove-Item "$env:SystemRoot\SMSCFG.ini" -Force -ErrorAction SilentlyContinue
Start-Service ccmexec
'Client GUID reset; client will re-register'
