# Clears temp, crash dumps and WER for all user profiles. Run elevated.
$targets = 'AppData\Local\Temp\*','AppData\Local\CrashDumps\*','AppData\Local\Microsoft\Windows\WER\*'
foreach ($t in $targets) {
  Get-ChildItem "C:\Users\*\$t" -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}
'User temp data cleared'
