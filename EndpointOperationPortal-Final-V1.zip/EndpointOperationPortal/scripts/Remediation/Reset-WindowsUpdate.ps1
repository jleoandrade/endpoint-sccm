# Full Windows Update reset: stops services, clears SoftwareDistribution/catroot2, restarts. Run elevated.
$svc = 'bits','wuauserv','cryptsvc'
$svc | ForEach-Object { Stop-Service $_ -Force -ErrorAction SilentlyContinue }
Rename-Item "$env:SystemRoot\SoftwareDistribution" "SoftwareDistribution.old" -Force -ErrorAction SilentlyContinue
Rename-Item "$env:SystemRoot\System32\catroot2" "catroot2.old" -Force -ErrorAction SilentlyContinue
$svc | ForEach-Object { Start-Service $_ -ErrorAction SilentlyContinue }
'Windows Update components reset'
