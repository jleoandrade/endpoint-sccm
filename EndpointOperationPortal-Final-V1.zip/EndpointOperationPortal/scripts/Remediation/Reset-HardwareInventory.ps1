# Clears the hardware inventory history so the next cycle sends a full inventory. Run elevated.
Get-CimInstance -Namespace 'root\ccm\invagt' -ClassName InventoryActionStatus -Filter "InventoryActionID='{00000000-0000-0000-0000-000000000001}'" | Remove-CimInstance
Invoke-CimMethod -Namespace 'root\ccm' -ClassName SMS_Client -MethodName TriggerSchedule -Arguments @{ sScheduleID = '{00000000-0000-0000-0000-000000000001}' } | Out-Null
'Hardware inventory reset; full resync triggered'
