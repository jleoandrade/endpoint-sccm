# Runs the in-place ConfigMgr client repair (ccmrepair). Run elevated.
Start-Process "$env:SystemRoot\CCM\ccmrepair.exe"
'ccmrepair started'
