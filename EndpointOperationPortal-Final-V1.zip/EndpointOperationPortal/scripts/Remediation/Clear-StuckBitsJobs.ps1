# Removes BITS jobs stuck in error and resumes suspended ones. Run elevated.
Get-BitsTransfer -AllUsers -ErrorAction SilentlyContinue | Where-Object JobState -in 'Error','TransientError' | Remove-BitsTransfer
Get-BitsTransfer -AllUsers -ErrorAction SilentlyContinue | Where-Object JobState -eq 'Suspended' | Resume-BitsTransfer
'Stuck BITS jobs cleared'
