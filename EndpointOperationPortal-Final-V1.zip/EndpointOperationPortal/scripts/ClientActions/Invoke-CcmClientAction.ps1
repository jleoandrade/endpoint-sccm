# Triggers one or more ConfigMgr client action cycles by friendly name.
# Example: .\Invoke-CcmClientAction.ps1 -Action MachinePolicyRetrieval,SoftwareUpdateScan
[CmdletBinding()]
param(
  [Parameter(Mandatory)]
  [ValidateSet(
    'MachinePolicyRetrieval','MachinePolicyEvaluation',
    'UserPolicyRetrieval','UserPolicyEvaluation',
    'HardwareInventory','SoftwareInventory','DiscoveryData',
    'FileCollection','WindowsInstallerSourceListUpdate',
    'SoftwareUpdateScan','SoftwareUpdateDeploymentEvaluation',
    'ApplicationDeploymentEvaluation','SoftwareMeteringUsageReport'
  )]
  [string[]]$Action
)
# Documented ConfigMgr trigger schedule GUIDs.
$map = @{
  MachinePolicyRetrieval              = '{00000000-0000-0000-0000-000000000021}'
  MachinePolicyEvaluation             = '{00000000-0000-0000-0000-000000000022}'
  UserPolicyRetrieval                 = '{00000000-0000-0000-0000-000000000026}'
  UserPolicyEvaluation                = '{00000000-0000-0000-0000-000000000027}'
  HardwareInventory                   = '{00000000-0000-0000-0000-000000000001}'
  SoftwareInventory                   = '{00000000-0000-0000-0000-000000000002}'
  DiscoveryData                       = '{00000000-0000-0000-0000-000000000003}'
  FileCollection                      = '{00000000-0000-0000-0000-000000000010}'
  WindowsInstallerSourceListUpdate    = '{00000000-0000-0000-0000-000000000032}'
  SoftwareUpdateScan                  = '{00000000-0000-0000-0000-000000000113}'
  SoftwareUpdateDeploymentEvaluation  = '{00000000-0000-0000-0000-000000000108}'
  ApplicationDeploymentEvaluation     = '{00000000-0000-0000-0000-000000000121}'
  SoftwareMeteringUsageReport         = '{00000000-0000-0000-0000-000000000031}'
}
foreach ($a in $Action) {
  Invoke-CimMethod -Namespace 'root\ccm' -ClassName SMS_Client -MethodName TriggerSchedule -Arguments @{ sScheduleID = $map[$a] } | Out-Null
  [pscustomobject]@{ Action = $a; Triggered = $true }
}
