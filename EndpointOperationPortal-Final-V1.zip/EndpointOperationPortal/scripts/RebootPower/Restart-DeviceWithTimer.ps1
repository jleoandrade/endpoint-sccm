# Triggers a ConfigMgr-style reboot using the client's configured countdown/notification. Run elevated.
$key = 'HKLM:\SOFTWARE\Microsoft\SMS\Mobile Client\Reboot Management\RebootData'
New-Item $key -Force -ErrorAction SilentlyContinue | Out-Null
$now = [DateTimeOffset]::Now.ToUnixTimeSeconds()
New-ItemProperty $key -Name 'RebootBy' -Value $now -PropertyType QWord -Force | Out-Null
New-ItemProperty $key -Name 'RebootValueInUTC' -Value 1 -PropertyType DWord -Force | Out-Null
New-ItemProperty $key -Name 'NotifyUI' -Value 1 -PropertyType DWord -Force | Out-Null
Restart-Service ccmexec -Force
'Reboot with client timer requested'
