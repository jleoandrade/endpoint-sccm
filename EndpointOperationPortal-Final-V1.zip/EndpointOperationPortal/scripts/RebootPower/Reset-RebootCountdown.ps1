# Resets the ConfigMgr reboot countdown timer to start again from now. Run elevated.
$key = 'HKLM:\SOFTWARE\Microsoft\SMS\Mobile Client\Reboot Management\RebootData'
Set-ItemProperty $key -Name 'RebootBy' -Value ([DateTimeOffset]::Now.ToUnixTimeSeconds()) -ErrorAction SilentlyContinue
Restart-Service ccmexec -Force
'Reboot countdown reset'
