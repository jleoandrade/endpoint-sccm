# Restarts the device immediately. Run elevated.
Restart-Computer -Force
