# Enables Wake-on-LAN on network adapters. Run elevated.
Get-CimInstance -Namespace root\wmi -ClassName MSPower_DeviceWakeEnable -ErrorAction SilentlyContinue |
  ForEach-Object { Set-CimInstance -InputObject $_ -Property @{ Enable = $true } }
'Wake-on-LAN enabled where supported'
