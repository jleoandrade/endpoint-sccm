# Cancels a pending ConfigMgr reboot. Run elevated.
Remove-Item 'HKLM:\SOFTWARE\Microsoft\SMS\Mobile Client\Reboot Management\RebootData' -Recurse -Force -ErrorAction SilentlyContinue
Remove-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired' -Name * -ErrorAction SilentlyContinue
'Pending reboot cancelled'
