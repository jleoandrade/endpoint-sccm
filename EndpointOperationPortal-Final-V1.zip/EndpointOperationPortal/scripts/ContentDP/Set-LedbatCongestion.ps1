# Enables the LEDBAT congestion provider for DP traffic (InternetCustom template). Run elevated.
$current = (Get-NetTCPSetting -SettingName InternetCustom).CongestionProvider
if ($current -ne 'LEDBAT') { Set-NetTCPSetting -SettingName InternetCustom -CongestionProvider LEDBAT }
[pscustomobject]@{ CongestionProvider = (Get-NetTCPSetting -SettingName InternetCustom).CongestionProvider }
