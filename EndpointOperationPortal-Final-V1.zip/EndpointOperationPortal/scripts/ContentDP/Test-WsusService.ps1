# Ensures the WSUS service is running. Run on the WSUS/SUP server, elevated.
$svc = Get-Service WsusService -ErrorAction SilentlyContinue
if ($svc -and $svc.Status -ne 'Running') { Start-Service WsusService }
(Get-Service WsusService -ErrorAction SilentlyContinue) | Select-Object Name, Status
