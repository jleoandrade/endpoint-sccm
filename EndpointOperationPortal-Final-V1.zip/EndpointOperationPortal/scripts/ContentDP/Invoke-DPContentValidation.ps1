# Starts the Distribution Point content validation scheduled task. Run on the DP, elevated.
Start-ScheduledTask -TaskPath '\Microsoft\Configuration Manager\' -TaskName 'Content Validation'
'Content validation started'
