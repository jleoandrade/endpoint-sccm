# Restarts a Windows service by name. Run elevated.
[CmdletBinding()]
param([Parameter(Mandatory)][string]$Name)
Restart-Service -Name $Name -Force
(Get-Service $Name) | Select-Object Name, Status, StartType
