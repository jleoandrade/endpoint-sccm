# Returns the status of the main ConfigMgr/Windows servicing services.
'CcmExec','BITS','wuauserv','Winmgmt','CmRcService','PeerDistSvc','WinRM' | ForEach-Object {
  $s = Get-Service $_ -ErrorAction SilentlyContinue
  [pscustomobject]@{ Service = $_; Status = $s.Status; StartType = $s.StartType }
}
