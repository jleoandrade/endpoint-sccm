# Stops all processes matching a name. Run elevated if the process runs as another user.
[CmdletBinding()]
param([Parameter(Mandatory)][string]$Name)
$procs = Get-Process -Name ($Name -replace '\.exe$','') -ErrorAction SilentlyContinue
$procs | Stop-Process -Force
[pscustomobject]@{ Name = $Name; Stopped = @($procs).Count }
