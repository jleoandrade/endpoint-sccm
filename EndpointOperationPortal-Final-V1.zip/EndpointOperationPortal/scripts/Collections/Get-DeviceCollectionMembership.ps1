# Lists the collections a device belongs to. Run on/for the site server.
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$SiteCode,
  [Parameter(Mandatory)][string]$DeviceName
)
Import-Module (Join-Path (Split-Path $env:SMS_ADMIN_UI_PATH) 'ConfigurationManager.psd1')
Push-Location "$SiteCode`:"
$rid = (Get-CMDevice -Name $DeviceName).ResourceID
Get-CMCollection | Where-Object { (Get-CMCollectionMember -CollectionId $_.CollectionID -ResourceId $rid -ErrorAction SilentlyContinue) } | Select-Object Name, CollectionID
Pop-Location
