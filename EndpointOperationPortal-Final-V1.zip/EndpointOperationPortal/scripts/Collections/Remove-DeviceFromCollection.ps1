# Removes a device's direct membership rule from a collection. Run on/for the site server.
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$SiteCode,
  [Parameter(Mandatory)][string]$CollectionName,
  [Parameter(Mandatory)][string]$DeviceName
)
Import-Module (Join-Path (Split-Path $env:SMS_ADMIN_UI_PATH) 'ConfigurationManager.psd1')
Push-Location "$SiteCode`:"
Remove-CMDeviceCollectionDirectMembershipRule -CollectionName $CollectionName -ResourceName $DeviceName -Force
Pop-Location
"$DeviceName removed from $CollectionName"
