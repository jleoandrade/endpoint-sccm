# Adds a device to a collection via a direct membership rule. Run on/for the site server.
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$SiteCode,
  [Parameter(Mandatory)][string]$SiteServer,
  [Parameter(Mandatory)][string]$CollectionName,
  [Parameter(Mandatory)][string]$DeviceName
)
Import-Module (Join-Path (Split-Path $env:SMS_ADMIN_UI_PATH) 'ConfigurationManager.psd1')
Push-Location "$SiteCode`:"
Add-CMDeviceCollectionDirectMembershipRule -CollectionName $CollectionName -ResourceId (Get-CMDevice -Name $DeviceName).ResourceID
Pop-Location
"$DeviceName added to $CollectionName"
