# Installs, uninstalls, repairs or evaluates a ConfigMgr application by name. Run elevated.
# Example: .\Invoke-CcmApplication.ps1 -Name '7-Zip' -Action Install
[CmdletBinding()]
param(
  [Parameter(Mandatory)][string]$Name,
  [Parameter(Mandatory)][ValidateSet('Install','Uninstall','Repair','Evaluate')][string]$Action
)
$app = Get-CimInstance -Namespace 'root\ccm\clientSDK' -ClassName CCM_Application -Filter "Name='$Name'" | Select-Object -First 1
if (-not $app) { throw "Application '$Name' not found on this client." }
$args = @{
  Id              = $app.Id
  Revision        = $app.Revision
  IsMachineTarget = $app.IsMachineTarget
  EnforcePreference = [uint32]0
  Priority        = 'High'
  IsRebootIfNeeded = $false
}
$method = switch ($Action) { 'Evaluate' { 'EvaluateApplicability' } default { $Action } }
Invoke-CimMethod -Namespace 'root\ccm\clientSDK' -ClassName CCM_Application -MethodName $method -Arguments $args | Out-Null
[pscustomobject]@{ Application = $Name; Action = $Action; Triggered = $true }
