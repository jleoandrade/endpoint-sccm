# Lists required updates with their current state.
$state = @{ 0='Missing'; 1='Installed'; 2='NotApplicable'; 3='Unknown' }
Get-CimInstance -Namespace 'root\ccm\ClientSDK' -ClassName CCM_SoftwareUpdate -ErrorAction SilentlyContinue |
  Select-Object @{n='Article';e={$_.ArticleID}}, Name, @{n='State';e={$state[[int]$_.ComplianceState]}}
