# Installs all updates currently available/required on the client. Run elevated.
$updates = Get-CimInstance -Namespace 'root\ccm\ClientSDK' -ClassName CCM_SoftwareUpdate -Filter 'ComplianceState = 0'
if (-not $updates) { return 'No required updates found' }
$wmi = [wmiclass]'root\ccm\ClientSDK:CCM_SoftwareUpdatesManager'
$wmi.InstallUpdates([System.Management.ManagementObject[]] (Get-WmiObject -Namespace 'root\ccm\ClientSDK' -Query 'SELECT * FROM CCM_SoftwareUpdate WHERE ComplianceState = 0')) | Out-Null
[pscustomobject]@{ InstallTriggered = @($updates).Count }
