# Triggers a software update scan and deployment evaluation, and refreshes server compliance.
Invoke-CimMethod -Namespace 'root\ccm' -ClassName SMS_Client -MethodName TriggerSchedule -Arguments @{ sScheduleID = '{00000000-0000-0000-0000-000000000113}' } | Out-Null
Invoke-CimMethod -Namespace 'root\ccm' -ClassName SMS_Client -MethodName TriggerSchedule -Arguments @{ sScheduleID = '{00000000-0000-0000-0000-000000000108}' } | Out-Null
try { (New-Object -ComObject Microsoft.CCM.UpdatesStore).RefreshServerComplianceState() } catch {}
'Update scan and evaluation triggered'
