# Starts a Microsoft Defender scan. Run elevated.
[CmdletBinding()]
param([ValidateSet('QuickScan','FullScan')][string]$ScanType = 'QuickScan')
Start-MpScan -ScanType $ScanType
"$ScanType started"
