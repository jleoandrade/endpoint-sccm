# Updates Microsoft Defender signatures. Run elevated.
Update-MpSignature
(Get-MpComputerStatus) | Select-Object AMProductVersion, AntivirusSignatureVersion, AntivirusSignatureLastUpdated
