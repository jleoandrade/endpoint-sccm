# Retrieves the Windows LAPS managed local admin password from AD. Run with a delegated account.
# Requires the Windows LAPS module (Get-LapsADPassword). Every retrieval should be audited.
[CmdletBinding()]
param([Parameter(Mandatory)][string]$ComputerName)
Import-Module LAPS -ErrorAction Stop
Get-LapsADPassword -Identity $ComputerName -AsPlainText |
  Select-Object Account, Password, ExpirationTimestamp
