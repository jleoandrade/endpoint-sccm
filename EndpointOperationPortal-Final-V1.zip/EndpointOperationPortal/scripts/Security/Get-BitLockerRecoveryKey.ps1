# Returns the BitLocker recovery password(s) for a drive. Run elevated. Sensitive - audit retrieval.
[CmdletBinding()]
param([string]$MountPoint = 'C:')
(Get-BitLockerVolume -MountPoint $MountPoint).KeyProtector |
  Where-Object KeyProtectorType -eq 'RecoveryPassword' |
  Select-Object KeyProtectorId, RecoveryPassword
