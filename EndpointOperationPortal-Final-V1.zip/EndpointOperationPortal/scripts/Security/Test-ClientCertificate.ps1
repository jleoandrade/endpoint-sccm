# Checks LocalMachine\My for valid vs expiring client certificates.
Get-ChildItem Cert:\LocalMachine\My | ForEach-Object {
  [pscustomobject]@{
    Subject       = $_.Subject
    Issuer        = $_.Issuer
    NotAfter      = $_.NotAfter
    ExpiresInDays = [int]($_.NotAfter - (Get-Date)).TotalDays
  }
} | Sort-Object ExpiresInDays
