# Returns the interactively logged-on user (owner of explorer.exe).
$p = Get-CimInstance Win32_Process -Filter "Name='explorer.exe'" | Select-Object -First 1
$owner = if ($p) { Invoke-CimMethod -InputObject $p -MethodName GetOwner } else { $null }
[pscustomobject]@{ User = if ($owner) { "$($owner.Domain)\$($owner.User)" } else { $null } }
