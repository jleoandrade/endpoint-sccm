# Returns manufacturer and model (handles Lenovo friendly name).
$cs = Get-CimInstance Win32_ComputerSystem
$model = if ($cs.Manufacturer -eq 'Lenovo') { (Get-CimInstance Win32_ComputerSystemProduct).Version } else { $cs.Model }
[pscustomobject]@{ Manufacturer = $cs.Manufacturer; Model = $model; IsVirtual = ($cs.Model -match 'Virtual|VMware|Hyper-V|KVM') }
