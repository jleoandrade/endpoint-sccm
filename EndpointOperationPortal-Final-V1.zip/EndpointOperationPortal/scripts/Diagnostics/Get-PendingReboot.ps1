# Detects whether the device is pending a reboot (Windows Update, CBS, file rename, ConfigMgr).
$pending = $false
if (Get-Item 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired' -ErrorAction SilentlyContinue) { $pending = $true }
if (Get-Item 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending' -ErrorAction SilentlyContinue) { $pending = $true }
if (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue) { $pending = $true }
try { if (([wmiclass]'\\.\root\ccm\ClientSDK:CCM_ClientUtilities').DetermineIfRebootPending().RebootPending) { $pending = $true } } catch {}
[pscustomobject]@{ PendingReboot = $pending }
