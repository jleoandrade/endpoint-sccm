# Counts software updates the client still requires (ComplianceState = 0).
$updates = Get-CimInstance -Namespace 'ROOT\ccm\ClientSDK' -ClassName CCM_SoftwareUpdate -ErrorAction SilentlyContinue
[pscustomobject]@{ MissingUpdates = @($updates | Where-Object ComplianceState -eq 0).Count }
