# Returns ConfigMgr client cache size and used space.
$mgr = New-Object -ComObject UIResource.UIResourceMgr
$cache = $mgr.GetCacheInfo()
$usedMB = ($cache.GetCacheElements() | Measure-Object ContentSize -Sum).Sum / 1KB
[pscustomobject]@{ TotalCacheMB = $cache.TotalSize; UsedCacheMB = [math]::Round($usedMB,1) }
