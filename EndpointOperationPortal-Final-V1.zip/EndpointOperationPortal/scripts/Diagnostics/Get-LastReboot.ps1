# Returns last boot time and uptime.
$os = Get-CimInstance Win32_OperatingSystem
$boot = $os.LastBootUpTime
$up = (Get-Date) - $boot
[pscustomobject]@{ LastBootUpTime = $boot; UptimeDays = $up.Days; UptimeHours = $up.Hours }
