# Returns active IPv4 addresses.
Get-NetIPConfiguration | Where-Object { $_.IPv4Address } | ForEach-Object {
  [pscustomobject]@{ Interface = $_.InterfaceAlias; IPv4 = $_.IPv4Address.IPAddress }
}
