# Returns ConfigMgr client identity: version, site code, management point and client ID.
$ccm = Get-CimInstance -Namespace 'root\ccm' -ClassName SMS_Client -ErrorAction SilentlyContinue
$auth = Get-CimInstance -Namespace 'root\ccm' -ClassName CCM_Authority -ErrorAction SilentlyContinue | Select-Object -First 1
$id   = Get-CimInstance -Namespace 'root\ccm' -ClassName CCM_Client -ErrorAction SilentlyContinue
[pscustomobject]@{
  ClientVersion   = $ccm.ClientVersion
  AssignedSite    = $auth.Name -replace '^SMS:',''
  ManagementPoint = (Get-CimInstance -Namespace 'root\ccm\LocationServices' -ClassName SMS_MPInformation -ErrorAction SilentlyContinue | Select-Object -First 1).MP
  ClientId        = $id.ClientId
}
