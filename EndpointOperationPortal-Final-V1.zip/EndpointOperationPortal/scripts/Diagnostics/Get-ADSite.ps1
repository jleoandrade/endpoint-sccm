# Returns the Active Directory site the device belongs to.
[pscustomobject]@{ ADSite = (nltest /dsgetsite 2>$null | Select-Object -First 1) }
