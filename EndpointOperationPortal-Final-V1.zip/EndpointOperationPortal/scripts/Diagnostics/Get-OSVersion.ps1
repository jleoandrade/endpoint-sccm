# Returns the full Windows version (caption, build, UBR, display version, architecture).
$os  = Get-CimInstance Win32_OperatingSystem
$cur = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
[pscustomobject]@{
  Caption        = $os.Caption
  Version        = $os.Version
  UBR            = (Get-ItemProperty $cur -Name UBR -ErrorAction SilentlyContinue).UBR
  DisplayVersion = (Get-ItemProperty $cur -Name DisplayVersion -ErrorAction SilentlyContinue).DisplayVersion
  Architecture   = $os.OSArchitecture
}
