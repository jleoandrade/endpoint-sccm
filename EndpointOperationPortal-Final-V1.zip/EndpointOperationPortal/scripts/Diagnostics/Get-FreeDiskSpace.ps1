# Returns free space on the system drive (C:) in GB.
[CmdletBinding()]
param([string]$Drive = 'C:')
$disk = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$Drive'"
[pscustomobject]@{ Drive = $Drive; FreeGB = [math]::Round($disk.FreeSpace/1GB,2); SizeGB = [math]::Round($disk.Size/1GB,2) }
