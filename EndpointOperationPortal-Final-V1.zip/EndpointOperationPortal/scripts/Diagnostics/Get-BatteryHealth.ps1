# Reports battery design vs remaining capacity (degradation %). Laptops only.
$status = Get-CimInstance -Namespace root\wmi -ClassName BatteryStatus -ErrorAction SilentlyContinue | Select-Object -First 1
$full   = Get-CimInstance -Namespace root\wmi -ClassName BatteryFullChargedCapacity -ErrorAction SilentlyContinue | Select-Object -First 1
$design = Get-CimInstance -Namespace root\wmi -ClassName BatteryStaticData -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $design) { return [pscustomobject]@{ Battery = 'Not present' } }
[pscustomobject]@{
  DesignCapacity    = $design.DesignedCapacity
  FullChargeCapacity= $full.FullChargedCapacity
  HealthPercent     = if ($design.DesignedCapacity) { [math]::Round($full.FullChargedCapacity/$design.DesignedCapacity*100,1) } else { $null }
}
