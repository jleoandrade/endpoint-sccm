# Returns the last CCMEval (client health) result and timestamp.
$eval = Get-CimInstance -Namespace 'root\ccm' -ClassName CCM_EvaluationState -ErrorAction SilentlyContinue | Select-Object -First 1
$last = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\CCM\CcmEval' -Name LastEvalTime -ErrorAction SilentlyContinue).LastEvalTime
[pscustomobject]@{ LastEvalTime = $last; LastResult = $eval.Description }
