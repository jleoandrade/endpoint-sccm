using EndpointPortal.Api.Models;
using Microsoft.Data.SqlClient;

namespace EndpointPortal.Api.Services;

/// <summary>
/// Reads from the ConfigMgr site database (read-replica recommended). These queries use
/// standard ConfigMgr reporting views, but EXACT VIEW/COLUMN NAMES VARY BY VERSION —
/// validate each query against your site DB before production (see docs/IMPLEMENTATION).
/// The queries are TOP-N / paged and NEVER touch the clients.
/// </summary>
public sealed class SqlSccmReader(IConfiguration config) : ISccmReader
{
    private string ConnString =>
        config.GetConnectionString("SccmDb")
        ?? throw new InvalidOperationException("ConnectionStrings:SccmDb is not configured.");

    private async Task<SqlConnection> OpenAsync()
    {
        var cn = new SqlConnection(ConnString);
        await cn.OpenAsync();
        return cn;
    }

    // --- Attention queue -------------------------------------------------------
    // Starting point: unhealthy or inactive clients, worst (oldest contact) first.
    private const string AttentionSql = @"
SELECT sys.Name0                       AS Host,
       ch.ClientActiveStatus           AS ActiveStatus,
       ch.LastHealthEvaluationResult   AS HealthResult,
       ch.LastActiveTime               AS LastActive
FROM   v_R_System sys
JOIN   v_CH_ClientSummary ch ON ch.ResourceID = sys.ResourceID
WHERE  ch.ClientActiveStatus = 0
    OR ch.LastHealthEvaluationResult <> 1
ORDER  BY ch.LastActiveTime ASC
OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY;";

    public async Task<IReadOnlyList<AttentionDevice>> GetAttentionAsync(int offset, int limit)
    {
        var list = new List<AttentionDevice>();
        await using var cn = await OpenAsync();
        await using var cmd = new SqlCommand(AttentionSql, cn);
        cmd.Parameters.AddWithValue("@offset", offset);
        cmd.Parameters.AddWithValue("@limit", limit);
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
        {
            var host = r["Host"]?.ToString() ?? "";
            var active = r["ActiveStatus"] is int a && a == 1;
            var lastActive = r["LastActive"] as DateTime?;
            var staleDays = lastActive is null ? 999 : (int)(DateTime.UtcNow - lastActive.Value).TotalDays;
            var (issue, sev) = Classify(active, staleDays);
            var meta = lastActive is null ? "No recent contact" : $"Last contact {staleDays}d ago";
            list.Add(new AttentionDevice(host, issue, sev, meta));
        }
        return list;
    }

    private const string AttentionCountSql = @"
SELECT COUNT(*) FROM v_R_System sys
JOIN v_CH_ClientSummary ch ON ch.ResourceID = sys.ResourceID
WHERE ch.ClientActiveStatus = 0 OR ch.LastHealthEvaluationResult <> 1;";

    public async Task<int> GetAttentionCountAsync()
    {
        await using var cn = await OpenAsync();
        await using var cmd = new SqlCommand(AttentionCountSql, cn);
        return (int)(await cmd.ExecuteScalarAsync() ?? 0);
    }

    private static (string Issue, string Severity) Classify(bool active, int staleDays) =>
        !active || staleDays >= 7 ? ("Agent Offline", "critical")
        : staleDays >= 3 ? ("No recent policy", "serious")
        : ("Health Warning", "warning");

    // --- Search ----------------------------------------------------------------
    public async Task<IReadOnlyList<DeviceSearchResult>> SearchAsync(string query)
    {
        const string sql = @"
SELECT TOP 20 Name0, User_Name0
FROM v_R_System
WHERE Name0 LIKE @q OR User_Name0 LIKE @q
ORDER BY Name0;";
        var list = new List<DeviceSearchResult>();
        await using var cn = await OpenAsync();
        await using var cmd = new SqlCommand(sql, cn);
        cmd.Parameters.AddWithValue("@q", "%" + query + "%");
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
            list.Add(new DeviceSearchResult(r["Name0"]?.ToString() ?? "", r["User_Name0"]?.ToString() ?? "", ""));
        return list;
    }

    private async Task<int?> ResolveResourceIdAsync(SqlConnection cn, string host)
    {
        await using var cmd = new SqlCommand("SELECT TOP 1 ResourceID FROM v_R_System WHERE Name0 = @h", cn);
        cmd.Parameters.AddWithValue("@h", host);
        var o = await cmd.ExecuteScalarAsync();
        return o is int id ? id : null;
    }

    // --- Compliance ------------------------------------------------------------
    public async Task<ComplianceInfo> GetComplianceAsync(string host)
    {
        await using var cn = await OpenAsync();
        var rid = await ResolveResourceIdAsync(cn, host);
        if (rid is null) return new ComplianceInfo(Array.Empty<ComplianceBaseline>(), Array.Empty<MissingPatch>());

        // Configuration baselines (DCM). ComplianceState: 1 = Compliant, else non-compliant.
        var baselines = new List<ComplianceBaseline>();
        const string baseSql = @"
SELECT bs.DisplayName, cs.ComplianceState
FROM v_CIComplianceStatusComplete cs
JOIN v_ConfigurationItems ci ON ci.CI_ID = cs.CI_ID AND ci.CIType_ID = 2  -- baselines
JOIN v_LocalizedCIProperties bs ON bs.CI_ID = ci.CI_ID
WHERE cs.ResourceID = @rid;";
        await using (var cmd = new SqlCommand(baseSql, cn))
        {
            cmd.Parameters.AddWithValue("@rid", rid);
            await using var r = await cmd.ExecuteReaderAsync();
            while (await r.ReadAsync())
            {
                var compliant = r["ComplianceState"] is int c && c == 1;
                baselines.Add(new ComplianceBaseline(r["DisplayName"]?.ToString() ?? "", compliant ? "Compliant" : "Failed"));
            }
        }

        // Required (missing) updates. Status: 2 = Required.
        var patches = new List<MissingPatch>();
        const string patchSql = @"
SELECT ui.ArticleID, ui.Title, ui.Severity
FROM v_Update_ComplianceStatusAll cs
JOIN v_UpdateInfo ui ON ui.CI_ID = cs.CI_ID
WHERE cs.ResourceID = @rid AND cs.Status = 2;";
        await using (var cmd = new SqlCommand(patchSql, cn))
        {
            cmd.Parameters.AddWithValue("@rid", rid);
            await using var r = await cmd.ExecuteReaderAsync();
            while (await r.ReadAsync())
                patches.Add(new MissingPatch(
                    "KB" + r["ArticleID"], r["Title"]?.ToString() ?? "",
                    r["Severity"]?.ToString() ?? "", "Required by Device"));
        }

        return new ComplianceInfo(baselines, patches);
    }

    // --- Apps ------------------------------------------------------------------
    public async Task<IReadOnlyList<AppInfo>> GetAppsAsync(string host)
    {
        await using var cn = await OpenAsync();
        var rid = await ResolveResourceIdAsync(cn, host);
        if (rid is null) return Array.Empty<AppInfo>();
        const string sql = @"
SELECT AppName, EnforcementStateName
FROM v_AppDeploymentAssetDetails
WHERE MachineID = @rid;";
        var list = new List<AppInfo>();
        await using var cmd = new SqlCommand(sql, cn);
        cmd.Parameters.AddWithValue("@rid", rid);
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
            list.Add(new AppInfo(r["AppName"]?.ToString() ?? "", r["EnforcementStateName"]?.ToString() ?? ""));
        return list;
    }

    // --- Collections -----------------------------------------------------------
    public async Task<IReadOnlyList<CollectionInfo>> GetCollectionsAsync(string host)
    {
        await using var cn = await OpenAsync();
        var rid = await ResolveResourceIdAsync(cn, host);
        if (rid is null) return Array.Empty<CollectionInfo>();
        const string sql = @"
SELECT col.Name
FROM v_FullCollectionMembership fcm
JOIN v_Collection col ON col.CollectionID = fcm.CollectionID
WHERE fcm.ResourceID = @rid
ORDER BY col.Name;";
        var list = new List<CollectionInfo>();
        await using var cmd = new SqlCommand(sql, cn);
        cmd.Parameters.AddWithValue("@rid", rid);
        await using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
            list.Add(new CollectionInfo(r["Name"]?.ToString() ?? ""));
        return list;
    }
}
