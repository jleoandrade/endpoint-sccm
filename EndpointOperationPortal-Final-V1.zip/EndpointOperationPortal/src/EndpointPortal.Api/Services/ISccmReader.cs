using EndpointPortal.Api.Models;

namespace EndpointPortal.Api.Services;

/// <summary>
/// Reads from the ConfigMgr site database / Admin Service. These calls are cheap and
/// paginated (TOP N) — they must NEVER poll the clients themselves.
/// Replace <see cref="MockSccmReader"/> with a real implementation (see IMPLEMENTATION.docx).
/// </summary>
public interface ISccmReader
{
    Task<IReadOnlyList<AttentionDevice>> GetAttentionAsync(int offset, int limit);
    Task<int> GetAttentionCountAsync();
    Task<IReadOnlyList<DeviceSearchResult>> SearchAsync(string query);
    Task<ComplianceInfo> GetComplianceAsync(string host);
    Task<IReadOnlyList<AppInfo>> GetAppsAsync(string host);
    Task<IReadOnlyList<CollectionInfo>> GetCollectionsAsync(string host);
}

/// <summary>Sample data mirroring the portal prototype. Swap for a SQL/Admin Service reader.</summary>
public sealed class MockSccmReader : ISccmReader
{
    private static readonly AttentionDevice[] Queue =
    {
        new("BR-RJ-LPT4412","Agent Offline","critical","Last contact 4 days ago · missing security patch"),
        new("BR-SP-LPT9043","No Policy 7d","critical","No machine policy in 7 days · boundary mismatch"),
        new("BR-BH-LPT3391","Disk Full","critical","C: < 2 GB · SCCM cache stuck"),
        new("BR-RJ-DESK220","Health Fail","critical","CCMEval failed · WUAHandler errors"),
        new("BR-SP-LPT3312","Baseline Fail","serious","BitLocker not enforced · policy v2.4"),
        new("BR-SP-DESK109","WMI Corrupted","serious","Inventory not reporting · repository error"),
        new("BR-PA-LPT1180","Cache Stuck","warning","Content download stuck · 2 packages pending"),
        new("BR-SP-LPT7725","Patch Failed","warning","KB5034763 failed (0x80070643)"),
        new("BR-CE-DESK061","Reboot Pending","warning","Pending reboot 6 days · updates on hold"),
        new("BR-RS-LPT5567","Inventory Stale","warning","No hardware inventory in 14 days"),
    };

    public Task<IReadOnlyList<AttentionDevice>> GetAttentionAsync(int offset, int limit)
        => Task.FromResult<IReadOnlyList<AttentionDevice>>(Queue.Skip(offset).Take(limit).ToArray());

    public Task<int> GetAttentionCountAsync() => Task.FromResult(47);

    public Task<IReadOnlyList<DeviceSearchResult>> SearchAsync(string query)
    {
        var q = query.ToUpperInvariant();
        var hits = Queue.Where(d => d.Host.Contains(q))
                        .Select(d => new DeviceSearchResult(d.Host, "Full User Name", "AST-0001"))
                        .ToArray();
        if (hits.Length == 0) hits = new[] { new DeviceSearchResult(q, "Full User Name", "AST-0001") };
        return Task.FromResult<IReadOnlyList<DeviceSearchResult>>(hits);
    }

    public Task<ComplianceInfo> GetComplianceAsync(string host)
        => Task.FromResult(new ComplianceInfo(
            new ComplianceBaseline[]
            {
                new("Security - BitLocker Encryption", "Compliant"),
                new("Endpoint - Local Admin Restriction", "Failed"),
                new("Optimization - Cache Purge Policy", "Compliant"),
                new("Security - Defender Baseline", "Compliant"),
            },
            new MissingPatch[]
            {
                new("KB5034763", "Cumulative Update", "Critical", "Required by Device"),
                new("KB5035853", "Security Update .NET", "Important", "Cache Download Failed"),
            }));

    public Task<IReadOnlyList<AppInfo>> GetAppsAsync(string host)
        => Task.FromResult<IReadOnlyList<AppInfo>>(new AppInfo[]
        {
            new("Microsoft 365 Apps","Installed"),
            new("Google Chrome","Installed"),
            new("Company VPN Client","Failed"),
            new("Adobe Acrobat DC","Installed"),
            new("Zoom Workplace","Pending"),
        });

    public Task<IReadOnlyList<CollectionInfo>> GetCollectionsAsync(string host)
        => Task.FromResult<IReadOnlyList<CollectionInfo>>(new CollectionInfo[]
        {
            new("All-Workstations-BR"),
            new("Security-Compliance-Baseline"),
        });
}
