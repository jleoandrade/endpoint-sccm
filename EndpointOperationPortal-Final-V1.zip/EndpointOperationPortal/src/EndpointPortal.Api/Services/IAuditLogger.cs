using System.Text.Json;

namespace EndpointPortal.Api.Services;

/// <summary>Records every action with who, what, when and on which device.</summary>
public interface IAuditLogger
{
    Task WriteAsync(string actor, int level, string action, string target, object? details = null);
}

/// <summary>
/// Appends one JSON line per action to an audit file. In production, forward these
/// to a SIEM / append-only store instead of (or in addition to) a local file.
/// </summary>
public sealed class FileAuditLogger : IAuditLogger
{
    private readonly string _path;
    private readonly ILogger<FileAuditLogger> _log;
    private static readonly SemaphoreSlim Gate = new(1, 1);

    public FileAuditLogger(IConfiguration config, ILogger<FileAuditLogger> log)
    {
        _log = log;
        var dir = config["Audit:Directory"] ?? "logs";
        Directory.CreateDirectory(dir);
        _path = Path.Combine(dir, $"audit-{DateTime.UtcNow:yyyyMMdd}.jsonl");
    }

    public async Task WriteAsync(string actor, int level, string action, string target, object? details = null)
    {
        var entry = new
        {
            ts = DateTimeOffset.UtcNow,
            actor,
            level = $"L{level}",
            action,
            target,
            details
        };
        var line = JsonSerializer.Serialize(entry) + Environment.NewLine;
        await Gate.WaitAsync();
        try { await File.AppendAllTextAsync(_path, line); }
        catch (Exception ex) { _log.LogError(ex, "Failed to write audit entry"); }
        finally { Gate.Release(); }
    }
}
