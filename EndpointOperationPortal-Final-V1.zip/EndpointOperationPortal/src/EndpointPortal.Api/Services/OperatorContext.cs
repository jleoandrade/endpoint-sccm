using EndpointPortal.Api.Models;

namespace EndpointPortal.Api.Services;

/// <summary>
/// Scaffold RBAC: reads the operator's level and name from request headers
/// (X-Operator-Level: 1|2|3, X-Operator: name). In production this comes from the
/// authenticated principal (Entra ID / OIDC) and group-to-level mapping — NOT headers.
/// </summary>
public sealed class OperatorContext
{
    public OperatorLevel Level { get; }
    public string Actor { get; }

    public OperatorContext(IHttpContextAccessor http)
    {
        var ctx = http.HttpContext;
        var raw = ctx?.Request.Headers["X-Operator-Level"].FirstOrDefault();
        Level = int.TryParse(raw, out var n) && n is >= 1 and <= 3 ? (OperatorLevel)n : OperatorLevel.L1;
        Actor = ctx?.Request.Headers["X-Operator"].FirstOrDefault() ?? "unknown";
    }
}

/// <summary>Endpoint filter enforcing a minimum operator level.</summary>
public sealed class RequireLevelFilter(OperatorLevel minimum) : IEndpointFilter
{
    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        var op = context.HttpContext.RequestServices.GetRequiredService<OperatorContext>();
        if (op.Level < minimum)
            return Results.Problem(
                title: "Insufficient operator level",
                detail: $"This action requires {minimum} or higher; current level is {op.Level}.",
                statusCode: StatusCodes.Status403Forbidden);
        return await next(context);
    }
}

public static class RouteBuilderExtensions
{
    public static TBuilder RequireLevel<TBuilder>(this TBuilder builder, OperatorLevel minimum)
        where TBuilder : IEndpointConventionBuilder
    {
        builder.AddEndpointFilter(new RequireLevelFilter(minimum));
        return builder;
    }
}
