using EndpointPortal.Api.Models;

namespace EndpointPortal.Api.Services;

/// <summary>
/// Indexes the PowerShell library on disk (the /scripts folder). Category is the
/// subfolder mapped to the GET/FIX/DO/DP convention from the catalog.
/// </summary>
public sealed class ScriptCatalog
{
    private readonly Dictionary<string, (string Path, ScriptInfo Info)> _byName = new(StringComparer.OrdinalIgnoreCase);

    private static readonly Dictionary<string, string> FolderToCategory = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Diagnostics"] = "GET",
        ["Remediation"] = "FIX",
        ["ClientActions"] = "DO",
        ["Updates"] = "DO",
        ["ServicesProcesses"] = "DO",
        ["RebootPower"] = "DO",
        ["Security"] = "DO",
        ["Applications"] = "DO",
        ["Collections"] = "DO",
        ["ContentDP"] = "DP",
    };

    public ScriptCatalog(IConfiguration config, ILogger<ScriptCatalog> log)
    {
        var root = config["Scripts:Directory"] ?? "scripts";
        if (!Directory.Exists(root))
        {
            log.LogWarning("Scripts directory '{Root}' not found; the catalog is empty.", root);
            return;
        }

        foreach (var file in Directory.EnumerateFiles(root, "*.ps1", SearchOption.AllDirectories))
        {
            var name = Path.GetFileNameWithoutExtension(file);
            var folder = Path.GetFileName(Path.GetDirectoryName(file)!);
            var category = FolderToCategory.GetValueOrDefault(folder, "DO");
            var description = FirstCommentLine(file);
            _byName[name] = (file, new ScriptInfo(name, description, category));
        }
        log.LogInformation("Indexed {Count} PowerShell scripts.", _byName.Count);
    }

    public IReadOnlyList<ScriptInfo> List(string? category) =>
        _byName.Values
            .Select(v => v.Info)
            .Where(s => category is null || s.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
            .OrderBy(s => s.Category).ThenBy(s => s.Name)
            .ToArray();

    public bool TryGetPath(string name, out string path)
    {
        if (_byName.TryGetValue(name, out var v)) { path = v.Path; return true; }
        path = string.Empty;
        return false;
    }

    private static string FirstCommentLine(string file)
    {
        foreach (var line in File.ReadLines(file))
        {
            var t = line.TrimStart();
            if (t.StartsWith('#')) return t.TrimStart('#').Trim();
            if (t.Length > 0) break;
        }
        return "";
    }
}
