using EndpointPortal.Api.Models;

namespace EndpointPortal.Api.Services;

/// <summary>
/// Acts on a single client ON DEMAND via WinRM/PowerShell. Opened only when an operator
/// selects a device — never for the whole fleet. Replace <see cref="MockRemoteRunner"/>
/// with <c>PowerShellRemoteRunner</c> (see IMPLEMENTATION.docx).
/// </summary>
public interface IRemoteRunner
{
    Task<DeviceInfo> ConnectAsync(string host);
    Task<ActionResult> RunClientActionAsync(string host, string cycle);
    Task<IReadOnlyList<ServiceInfo>> GetServicesAsync(string host);
    Task<ActionResult> ControlServiceAsync(string host, string name, string op); // start|stop|restart
    Task<IReadOnlyList<ProcessInfo>> GetProcessesAsync(string host);
    Task<ActionResult> RunScriptAsync(string host, string scriptName, IReadOnlyDictionary<string, string>? parameters = null);
    Task<SecretResult> GetLapsAsync(string host);
    Task<SecretResult> GetBitLockerKeyAsync(string host);
}

/// <summary>Returns sample data; no real machine is touched. For local demo and tests.</summary>
public sealed class MockRemoteRunner : IRemoteRunner
{
    public Task<DeviceInfo> ConnectAsync(string host)
    {
        var offline = host.Contains("LPT4412") || host.Contains("DESK220");
        var diags = new Diagnostic[]
        {
            new("CcmExec Service", offline ? "Stopped" : "Running", offline ? "crit" : "ok"),
            new("Agent Version", "5.00.9106.1000", "info"),
            new("Disk Space (C:)", host.Contains("3391") ? "1.8 GB Free" : "42.8 GB Free", host.Contains("3391") ? "warn" : "ok"),
            new("Last Machine Policy", "34 min ago", "ok"),
            new("Last HW Inventory", "6 h ago", "ok"),
            new("Client Cache", "2.1 / 5.0 GB", "info"),
            new("Pending Reboot", "None", "ok"),
            new("Site / MP", "PR1 / mp01", "info"),
            new("Boundary", "SP-HQ", "info"),
            new("OS", "Windows 11 23H2", "info"),
            new("Model", "Latitude 5440", "info"),
            new("Uptime", "3 days", "ok"),
        };
        return Task.FromResult(new DeviceInfo(host, "Full User Name", "user.name@company.com", "Manager Name", true, diags));
    }

    public Task<ActionResult> RunClientActionAsync(string host, string cycle)
        => Task.FromResult(new ActionResult(true, $"Client action '{cycle}' triggered on {host}."));

    public Task<IReadOnlyList<ServiceInfo>> GetServicesAsync(string host)
        => Task.FromResult<IReadOnlyList<ServiceInfo>>(new ServiceInfo[]
        {
            new("CcmExec","Running","Automatic"),
            new("BITS","Running","Manual"),
            new("wuauserv","Stopped","Manual"),
            new("Winmgmt","Running","Automatic"),
            new("WinRM","Running","Automatic"),
        });

    public Task<ActionResult> ControlServiceAsync(string host, string name, string op)
        => Task.FromResult(new ActionResult(true, $"Service '{name}' {op} on {host}."));

    public Task<IReadOnlyList<ProcessInfo>> GetProcessesAsync(string host)
        => Task.FromResult<IReadOnlyList<ProcessInfo>>(new ProcessInfo[]
        {
            new("CcmExec.exe","142 MB","SYSTEM"),
            new("explorer.exe","88 MB","user.name"),
            new("OUTLOOK.EXE","410 MB","user.name"),
        });

    public Task<ActionResult> RunScriptAsync(string host, string scriptName, IReadOnlyDictionary<string, string>? parameters = null)
        => Task.FromResult(new ActionResult(true, $"Script '{scriptName}' executed on {host}."));

    public Task<SecretResult> GetLapsAsync(string host)
        => Task.FromResult(new SecretResult("Administrator", "aZ4!kM9x#Lq2", DateTimeOffset.UtcNow.AddDays(7)));

    public Task<SecretResult> GetBitLockerKeyAsync(string host)
        => Task.FromResult(new SecretResult("C:", "481920-337156-905284-162073-558041-772319-640288-110574", null));
}
