using EndpointPortal.Api.Endpoints;
using EndpointPortal.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<OperatorContext>();

// --- Service selection by configuration ------------------------------------
// Both the Demo and Production profiles connect to SCCM (Sql + PowerShell).
// Set Sccm:Mode = "Mock" or Runner:Mode = "Mock" for a no-SCCM UI demo.
var sccmMode = builder.Configuration["Sccm:Mode"] ?? "Sql";
if (sccmMode.Equals("Mock", StringComparison.OrdinalIgnoreCase))
    builder.Services.AddSingleton<ISccmReader, MockSccmReader>();
else
    builder.Services.AddSingleton<ISccmReader, SqlSccmReader>();

var runnerMode = builder.Configuration["Runner:Mode"] ?? "PowerShell";
#if POWERSHELL
if (runnerMode.Equals("Mock", StringComparison.OrdinalIgnoreCase))
    builder.Services.AddSingleton<IRemoteRunner, MockRemoteRunner>();
else
    builder.Services.AddSingleton<IRemoteRunner, PowerShellRemoteRunner>();
#else
builder.Services.AddSingleton<IRemoteRunner, MockRemoteRunner>();
#endif

builder.Services.AddSingleton<ScriptCatalog>();
builder.Services.AddSingleton<IAuditLogger, FileAuditLogger>();

builder.Services.AddCors(o => o.AddDefaultPolicy(p =>
    p.WithOrigins(builder.Configuration.GetSection("Cors:Origins").Get<string[]>() ?? Array.Empty<string>())
     .AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

// Production hardening: force HTTPS when configured.
if (app.Configuration.GetValue<bool>("Https:Enforce"))
    app.UseHttpsRedirection();

app.UseCors();
app.UseDefaultFiles();
app.UseStaticFiles();

app.MapApi();

app.Logger.LogInformation("Started — SCCM reader: {Sccm}, remote runner: {Runner}", sccmMode, runnerMode);
app.Run();
