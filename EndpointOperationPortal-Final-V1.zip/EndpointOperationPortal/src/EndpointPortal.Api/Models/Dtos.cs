namespace EndpointPortal.Api.Models;

// Operator levels (RBAC). Higher includes lower.
public enum OperatorLevel { L1 = 1, L2 = 2, L3 = 3 }

// Attention queue row (read from the SCCM database — never by polling clients).
public record AttentionDevice(
    string Host,
    string Issue,
    string Severity,   // critical | serious | warning
    string Meta);

public record DeviceSearchResult(string Host, string User, string AssetTag);

// Live device diagnostics (resolved on connect via the remote runner).
public record Diagnostic(string Label, string Value, string Tone); // ok | info | warn | crit

public record DeviceInfo(
    string Host,
    string User,
    string Email,
    string Manager,
    bool Connected,
    IReadOnlyList<Diagnostic> Diagnostics);

public record ComplianceBaseline(string Name, string Status);        // Compliant | Failed
public record MissingPatch(string Article, string Title, string Severity, string Status);
public record ComplianceInfo(IReadOnlyList<ComplianceBaseline> Baselines, IReadOnlyList<MissingPatch> Patches);

public record AppInfo(string Name, string State);
public record ServiceInfo(string Name, string Status, string StartType);
public record ProcessInfo(string Name, string Memory, string User);
public record ScriptInfo(string Name, string Description, string Category); // GET | FIX | DO | DP
public record CollectionInfo(string Name);

// Result of any action (always audited).
public record ActionResult(bool Accepted, string Message, string? CorrelationId = null);

// Sensitive secrets (require elevated level + reinforced audit).
public record SecretResult(string Label, string Value, DateTimeOffset? ExpiresAt);
