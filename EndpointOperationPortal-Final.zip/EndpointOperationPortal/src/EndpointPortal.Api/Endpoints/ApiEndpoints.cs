using EndpointPortal.Api.Models;
using EndpointPortal.Api.Services;

namespace EndpointPortal.Api.Endpoints;

public static class ApiEndpoints
{
    public static void MapApi(this IEndpointRouteBuilder app)
    {
        var api = app.MapGroup("/api").WithOpenApi();

        // --- Fleet queue (read from SCCM DB — cheap, paginated) --------------------
        api.MapGet("/devices/attention", async (ISccmReader sccm, int offset = 0, int limit = 10) =>
        {
            var items = await sccm.GetAttentionAsync(offset, limit);
            var total = await sccm.GetAttentionCountAsync();
            return Results.Ok(new { total, offset, limit, items });
        }).WithSummary("Top-N attention queue from the SCCM database (never polls clients).");

        api.MapGet("/devices/search", async (ISccmReader sccm, string q) =>
            Results.Ok(await sccm.SearchAsync(q)))
            .WithSummary("Find a device by hostname, user or asset tag.");

        // --- Device (opens WinRM on-demand) ----------------------------------------
        api.MapPost("/devices/{host}/connect", async (string host, IRemoteRunner runner, IAuditLogger audit, OperatorContext op) =>
        {
            var info = await runner.ConnectAsync(host);
            await audit.WriteAsync(op.Actor, (int)op.Level, "connect", host);
            return Results.Ok(info);
        }).WithSummary("Resolve the device and return live diagnostics.");

        api.MapGet("/devices/{host}/compliance", async (string host, ISccmReader sccm) =>
            Results.Ok(await sccm.GetComplianceAsync(host)));

        api.MapGet("/devices/{host}/apps", async (string host, ISccmReader sccm) =>
            Results.Ok(await sccm.GetAppsAsync(host)));

        api.MapGet("/devices/{host}/services", async (string host, IRemoteRunner runner) =>
            Results.Ok(await runner.GetServicesAsync(host)));

        api.MapGet("/devices/{host}/processes", async (string host, IRemoteRunner runner) =>
            Results.Ok(await runner.GetProcessesAsync(host)));

        api.MapGet("/devices/{host}/collections", async (string host, ISccmReader sccm) =>
            Results.Ok(await sccm.GetCollectionsAsync(host)));

        // --- Actions (L1: safe client cycles) --------------------------------------
        api.MapPost("/devices/{host}/actions/{cycle}", async (string host, string cycle, IRemoteRunner runner, IAuditLogger audit, OperatorContext op) =>
        {
            await audit.WriteAsync(op.Actor, (int)op.Level, $"client-action:{cycle}", host);
            return Results.Ok(await runner.RunClientActionAsync(host, cycle));
        }).RequireLevel(OperatorLevel.L1)
          .WithSummary("Trigger a ConfigMgr client action cycle.");

        // --- Services / processes (L2) ---------------------------------------------
        api.MapPost("/devices/{host}/services/{name}/{op}", async (string host, string name, string op, IRemoteRunner runner, IAuditLogger audit, OperatorContext oc) =>
        {
            await audit.WriteAsync(oc.Actor, (int)oc.Level, $"service:{op}:{name}", host);
            return Results.Ok(await runner.ControlServiceAsync(host, name, op));
        }).RequireLevel(OperatorLevel.L2);

        // --- Scripts (L2) -----------------------------------------------------------
        api.MapGet("/scripts", (ScriptCatalog catalog, string? category) =>
            Results.Ok(catalog.List(category)))
            .WithSummary("List the PowerShell library, optionally by category (GET/FIX/DO/DP).");

        api.MapPost("/devices/{host}/scripts/{name}/run", async (string host, string name, IRemoteRunner runner, ScriptCatalog catalog, IAuditLogger audit, OperatorContext op) =>
        {
            if (!catalog.TryGetPath(name, out _)) return Results.NotFound(new { error = $"Script '{name}' not found." });
            await audit.WriteAsync(op.Actor, (int)op.Level, $"run-script:{name}", host);
            return Results.Ok(await runner.RunScriptAsync(host, name));
        }).RequireLevel(OperatorLevel.L2);

        // --- Security (L2, sensitive — reinforced audit) ---------------------------
        api.MapGet("/devices/{host}/laps", async (string host, IRemoteRunner runner, IAuditLogger audit, OperatorContext op) =>
        {
            await audit.WriteAsync(op.Actor, (int)op.Level, "reveal-laps", host, new { sensitive = true });
            return Results.Ok(await runner.GetLapsAsync(host));
        }).RequireLevel(OperatorLevel.L2)
          .WithSummary("Retrieve the LAPS local admin password (audited).");

        api.MapGet("/devices/{host}/bitlocker-key", async (string host, IRemoteRunner runner, IAuditLogger audit, OperatorContext op) =>
        {
            await audit.WriteAsync(op.Actor, (int)op.Level, "reveal-bitlocker", host, new { sensitive = true });
            return Results.Ok(await runner.GetBitLockerKeyAsync(host));
        }).RequireLevel(OperatorLevel.L2);

        // --- Advanced (L3) ----------------------------------------------------------
        api.MapPost("/devices/{host}/repair", async (string host, IRemoteRunner runner, IAuditLogger audit, OperatorContext op) =>
        {
            await audit.WriteAsync(op.Actor, (int)op.Level, "repair-client", host);
            return Results.Ok(await runner.RunScriptAsync(host, "Repair-CcmClient"));
        }).RequireLevel(OperatorLevel.L3)
          .WithSummary("Repair the ConfigMgr client (L3).");

        app.MapGet("/health", () => Results.Ok(new { status = "ok" }));
    }
}
