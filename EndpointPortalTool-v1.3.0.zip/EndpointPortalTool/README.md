# Endpoint Portal Tool

Local web portal for endpoint support (ConfigMgr/SCCM + Windows). Nothing to install:
a PowerShell script starts a server bound to `localhost` only, opens the browser, and every
button runs a `.ps1` file from the `scripts` folder.

## How to use

1. Extract the folder anywhere (e.g. `C:\Tools\EndpointPortalTool`).
2. Double-click **`Start-EndpointPortal.cmd`**.
3. The portal opens in Edge app mode (or your default browser). Type the computer name and click **Connect**.
4. To stop it: click **Shut down** in the portal or close the PowerShell window.

Run it with an account that is an **administrator on the endpoints** (for example: Shift + right-click
the `.cmd` > *Run as different user*).

## Requirements

| Item | Detail |
|---|---|
| Technician workstation | Windows 10/11 with Windows PowerShell 5.1 (built in) and a modern browser |
| Endpoint | Powered on and on the network; WMI reachable over **WinRM (5985)** or **DCOM/RPC (135)** |
| ConfigMgr | Agent installed, for the *Client Actions* and *ConfigMgr Agent* tabs and part of *Software* |
| WinRM | Required for: Full cleanup, Quick cleanup (Purge), CCMEval, cache, GPUpdate, events (with RPC fallback), Windows Update reset, WMI, network. Use **Repair > Enable remote WinRM** if it is turned off |

## LAPS

*Users & Power > Get LAPS password* reads the password from Active Directory, so the device does not
need to be online. Requirements on the technician's account/workstation:

- Read permission on the LAPS password attribute of the computer (delegated to your support group).
- For **encrypted Windows LAPS**: membership in the authorized decryptor group, and the built-in LAPS
  PowerShell module (Windows 11 22H2+, or Windows 10/Server 2019+ with the April 2023 update or later).
- *Rotate LAPS password* needs write permission on the LAPS expiration attribute.

Every retrieval is written to `logs/audit-YYYY-MM.csv`; the password itself is never logged.

## Layout

```
Start-EndpointPortal.cmd     launcher (ExecutionPolicy Bypass for this process only)
Start-EndpointPortal.ps1     local web server (HttpListener + runspace pool)
config.json                  port, concurrent jobs, browser mode, CIM timeout
VERSION                      current version
core/EndpointPortal.psm1     shared functions used by the scripts
scripts/manifest.json        button catalog: tabs, groups, scripts, parameters
scripts/<category>/*.ps1     one script per feature
web/                         interface (HTML/CSS/JS, no external dependencies)
logs/audit-YYYY-MM.csv       audit trail: date, operator, computer, action, result
```

## Adding a button

1. Create `scripts/<category>/My-Action.ps1` with `param([Parameter(Mandatory)][string]$ComputerName, ...)`.
   Use `Write-EPLog "message" -Level ok|info|warn|error`, `Write-EPProgress 50 'step'`, and return objects
   (`[pscustomobject]`) for a table/details view, or text for a message.
2. Register it in `scripts/manifest.json` under `actions`, and add its id to a group in `categories`:

```json
"my-action": {
  "label": "My action", "script": "system/My-Action.ps1", "view": "table",
  "inputs": [ { "name": "Filter", "label": "Filter", "type": "text" } ],
  "confirm": "Confirmation text (optional)", "danger": false
}
```

`view`: `table` · `kv` (details) · `text` · `none` · `dashboard`.
`rowActions` adds per-row buttons to a table (see `services` and `apps-list`).
No server restart needed: the manifest is re-read on every run (reload the page to see new buttons).

## Security

- Listens on `localhost` only and rejects any other `Host` header (DNS rebinding protection).
- The API requires a random token generated at every startup (protection against CSRF from other sites).
- Only scripts listed in the manifest can run; undeclared parameters are rejected and select-list
  values are validated.
- Everything runs with the credentials of whoever started the tool; every action is logged under `logs/`.
- If a GPO enforces `AllSigned`, sign the `.ps1` files with your organization's code-signing certificate.

## Versioning

The version lives in `VERSION` and `scripts/manifest.json`. History is in `CHANGELOG.md` (SemVer:
`MAJOR` changes the manifest/server contract, `MINOR` adds features, `PATCH` fixes bugs).
