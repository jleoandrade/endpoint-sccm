/* Endpoint Portal Tool - web interface
   Every button calls POST /api/run with the manifest action id; the server runs the matching
   .ps1 and this page follows its progress through GET /api/job. */
'use strict';

// ---------------------------------------------------------------- utilities
const $ = (s, r = document) => r.querySelector(s);
function el(tag, attrs = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v === true ? '' : v);
  }
  for (const c of kids.flat()) if (c != null && c !== false) n.append(c instanceof Node ? c : document.createTextNode(String(c)));
  return n;
}
const asArray = (x) => (Array.isArray(x) ? x : x == null ? [] : [x]);
const isObj = (x) => x && typeof x === 'object' && !Array.isArray(x);
const nowTime = () => new Date().toLocaleTimeString('en-GB', { hour12: false });
const TARGET_RX = /^[A-Za-z0-9][A-Za-z0-9.\-_]{0,253}$/;
const blank = (v) => v == null || v === '' || v === '-';

// "yyyy-MM-dd HH:mm:ss" (endpoint local time) -> Date
function parseStamp(s) {
  const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/.exec(String(s || ''));
  return m ? new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0)) : null;
}
function ageHours(s) { const d = parseStamp(s); return d ? (Date.now() - d.getTime()) / 36e5 : null; }
function agoHours(h) {
  if (h < 1) return `${Math.max(1, Math.round(h * 60))} min ago`;
  if (h < 48) return `${Math.round(h)} h ago`;
  return `${Math.round(h / 24)} days ago`;
}
function ago(s) {
  const h = ageHours(s);
  return h == null ? (blank(s) ? '—' : String(s)) : agoHours(h);
}

// ---------------------------------------------------------------- session with the local server
(function captureToken() {
  const m = location.hash.match(/t=([a-f0-9]{16,})/i);
  if (m) { sessionStorage.setItem('ep.token', m[1]); history.replaceState(null, '', location.pathname); }
})();
const token = () => sessionStorage.getItem('ep.token') || '';

async function api(path, { method = 'GET', body } = {}) {
  const r = await fetch(path, {
    method, headers: { 'X-EP-Token': token(), 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null;
  try { data = await r.json(); } catch { /* no body */ }
  if (!r.ok) throw new Error((data && data.error) || `HTTP ${r.status}`);
  return data;
}

// ---------------------------------------------------------------- state
const S = {
  manifest: null, target: '', connected: false, machine: null, tab: null,
  jobs: new Map(), view: null, sort: null, filter: '', focusJob: null,
};
const actionsOf = () => S.manifest.actions;

// ---------------------------------------------------------------- activity log and toast
const termEl = $('#terminal');
function term(target, label, level, msg, t) {
  const atBottom = termEl.scrollHeight - termEl.scrollTop - termEl.clientHeight < 30;
  termEl.append(el('div', { class: 'ln' },
    el('span', { class: 't', text: `[${t || nowTime()}] ` }),
    target ? el('span', { class: 'h', text: `${target} · ${label} ` }) : null,
    el('span', { class: level, text: (level === 'error' ? '[ERROR] ' : level === 'warn' ? '[WARNING] ' : '') + msg })));
  while (termEl.childElementCount > 2000) termEl.firstElementChild.remove();
  if (atBottom) termEl.scrollTop = termEl.scrollHeight;
}
let toastTimer;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2800);
}
async function writeClipboard(v) {
  try { await navigator.clipboard.writeText(v); }
  catch { const ta = el('textarea'); ta.value = v; document.body.append(ta); ta.select(); document.execCommand('copy'); ta.remove(); }
}
async function copyText(v) {
  if (blank(v) || v === '—') return;
  await writeClipboard(v);
  toast(`Copied: ${v.length > 40 ? v.slice(0, 40) + '…' : v}`);
}

// ---------------------------------------------------------------- dialog (inputs + confirmation)
function openDialog({ title, text, inputs = [], okLabel = 'Run', danger = false, values = {} }) {
  const dlg = $('#dlg');
  $('#dlgTitle').textContent = title;
  $('#dlgText').textContent = text || '';
  $('#dlgText').hidden = !text;
  const box = $('#dlgFields'); box.replaceChildren();
  for (const f of inputs) {
    const val = values[f.name] ?? f.default ?? '';
    let ctl;
    if (f.type === 'select') {
      ctl = el('select', { name: f.name, required: f.required });
      for (const o of asArray(f.options)) {
        const v = isObj(o) ? o.value : o, l = isObj(o) ? o.label : o;
        ctl.append(el('option', { value: v, text: l, selected: String(v) === String(val) }));
      }
    } else if (f.type === 'textarea') {
      ctl = el('textarea', { name: f.name, required: f.required, maxlength: 2000, placeholder: f.placeholder });
      ctl.value = val;
    } else {
      ctl = el('input', { name: f.name, type: f.type === 'number' ? 'number' : 'text', required: f.required, maxlength: 2000, placeholder: f.placeholder });
      ctl.value = val;
    }
    box.append(el('label', {}, f.label + (f.required ? ' *' : ''), ctl));
  }
  box.hidden = inputs.length === 0;
  const ok = $('#dlgOk'); ok.textContent = okLabel; ok.className = `btn ${danger ? 'btn-danger' : 'btn-primary'}`;
  return new Promise((resolve) => {
    dlg.onclose = () => {
      if (dlg.returnValue !== 'ok') return resolve(null);
      const out = {};
      for (const f of inputs) {
        const v = box.querySelector(`[name="${f.name}"]`).value.trim();
        if (v !== '') out[f.name] = f.type === 'number' ? Number(v) : v;
      }
      resolve(out);
    };
    dlg.returnValue = '';
    dlg.showModal();
    const first = box.querySelector('input,select,textarea'); if (first) first.focus();
  });
}

// ---------------------------------------------------------------- running actions
async function runAction(id, inputs = {}, opts = {}) {
  const a = actionsOf()[id];
  const target = opts.target || S.target;
  if (!target) { toast('Enter a device first.'); return null; }
  let jobId;
  try {
    ({ jobId } = await api('/api/run', { method: 'POST', body: { action: id, target, inputs } }));
  } catch (e) {
    term(target, a.label, 'error', e.message);
    if (!opts.quiet) showNotice(a.label, target, 'err', [e.message]);
    return null;
  }
  const job = { id: jobId, action: id, label: a.label, target, inputs, from: 0, state: 'Running', percent: -1, status: '', logs: [], opts, started: Date.now() };
  S.jobs.set(jobId, job);
  if (opts.claimFocus) S.focusJob = jobId;
  markRunning(id, true); renderActivity();
  term(target, a.label, 'debug', 'started');
  return new Promise((resolve) => { job.resolve = resolve; setTimeout(() => poll(job), 250); });
}

async function poll(job) {
  let s;
  try { s = await api(`/api/job?id=${job.id}&from=${job.from}`); }
  catch (e) { s = { state: 'Failed', logs: [{ level: 'error', msg: `Local server did not respond: ${e.message}` }], next: job.from }; }
  job.from = s.next; job.percent = s.percent; job.status = s.status || ''; job.state = s.state;
  for (const l of asArray(s.logs)) { job.logs.push(l); term(job.target, job.label, l.level || 'info', l.msg, l.t); }
  renderActivity();
  if (s.state === 'Running') { setTimeout(() => poll(job), 450); return; }
  finishJob(job, asArray(s.result && s.result.items));
}

function finishJob(job, items) {
  job.items = items; job.ended = Date.now();
  if (![...S.jobs.values()].some((j) => j.action === job.action && j.state === 'Running')) markRunning(job.action, false);
  const secs = ((job.ended - job.started) / 1000).toFixed(1);
  const label = { Completed: 'completed', Failed: 'failed', Cancelled: 'cancelled' }[job.state] || job.state;
  term(job.target, job.label, job.state === 'Completed' ? 'ok' : 'error', `${label} in ${secs}s`);
  renderActivity();
  setTimeout(() => { S.jobs.delete(job.id); renderActivity(); }, job.state === 'Completed' ? 8000 : 20000);

  if (job.opts.onDone) job.opts.onDone(job);
  else if (!job.opts.quiet) showJobResult(job);
  if (job.state === 'Completed' && job.opts.refresh) runAction(job.opts.refresh.action, job.opts.refresh.inputs, { target: job.opts.refresh.target || job.target, claimFocus: true });
  job.resolve(job);
}

function markRunning(id, on) {
  document.querySelectorAll(`.ach[data-id="${id}"]`).forEach((b) => b.classList.toggle('running', on));
}

function renderActivity() {
  const box = $('#activity'); box.replaceChildren();
  for (const j of S.jobs.values()) {
    const run = j.state === 'Running';
    const cls = run ? '' : j.state === 'Completed' ? 'done' : 'fail';
    box.append(el('div', { class: `job ${cls}`, title: `${j.target} · ${j.label}${j.status ? ' · ' + j.status : ''}` },
      el('span', { class: 'job-name', text: j.label }),
      el('span', { class: `bar ${run && j.percent < 0 ? 'indet' : ''}` }, el('span', { style: `width:${run ? Math.max(0, j.percent) : 100}%` })),
      el('span', { class: 'pct', text: run ? (j.percent >= 0 ? `${j.percent}%` : '') : (j.state === 'Completed' ? 'done' : 'failed') }),
      run
        ? el('button', { class: 'x', title: 'Cancel', text: '✕', onclick: () => api(`/api/job/cancel?id=${j.id}`, { method: 'POST' }).catch(() => {}) })
        : el('button', { class: 'x', title: 'View result', text: '↗', onclick: () => showJobResult(j, true) })));
  }
}

// ---------------------------------------------------------------- button clicks
async function onAction(id, presetInputs = {}, forcedTarget = null) {
  const a = actionsOf()[id];
  let target = S.target;
  if (forcedTarget) target = forcedTarget;
  else if (a.noConnection) {
    const typed = $('#target').value.trim();
    if (typed) target = typed;
  }
  if (!target || !TARGET_RX.test(target)) { toast('Enter a valid hostname in Find Device.'); $('#target').focus(); return; }
  if (!a.noConnection && !S.connected) { toast('Connect to the device first.'); return; }

  let inputs = { ...presetInputs };
  const pending = asArray(a.inputs).filter((f) => !(f.name in inputs));
  if (pending.length || a.confirm) {
    const v = await openDialog({ title: a.label, text: a.confirm ? `${a.confirm}  (Device: ${target})` : `Device: ${target}`, inputs: pending, values: targetDefaults(pending, target), danger: !!a.danger });
    if (!v) return;
    inputs = { ...inputs, ...v };
  }
  if (a.view !== 'none') showLoading(a.label, target);
  runAction(id, inputs, { target, claimFocus: a.view !== 'none' });
}

// Inputs whose default is "{target}" are pre-filled with the device the action runs for
function targetDefaults(inputs, target) {
  const out = {};
  for (const f of asArray(inputs)) if (f.default === '{target}') out[f.name] = target || '';
  return out;
}
function resultSummary(items) {
  const parts = asArray(items).map((x) => (typeof x === 'string' ? x : isObj(x) && x.Result ? `${x.Computer || ''}${x.Computer ? ': ' : ''}${x.Result}` : null)).filter(Boolean);
  return parts.length ? parts.join(' · ') : 'Completed';
}

async function onRowAction(ra, row, parent) {
  const t = actionsOf()[ra.action];
  const target = parent.target || S.target;
  const inputs = { ...(ra.set || {}) };
  for (const [param, col] of Object.entries(ra.map || {})) inputs[param] = row[col];
  const ident = row.Name || row.KB || row.ContentId || '';
  const pending = asArray(t.inputs).filter((f) => !(f.name in inputs));
  if (ra.confirm || pending.length) {
    const v = await openDialog({ title: `${ra.label}${ident ? ': ' + ident : ''}`, text: ra.confirm ? `${ra.confirm}  (Device: ${target})` : `Device: ${target}`,
      inputs: pending, values: targetDefaults(pending, target), okLabel: ra.label, danger: !!ra.danger });
    if (!v) return;
    Object.assign(inputs, v);
  }
  // Row actions that return a table (e.g. collection changes) show their own result
  if (t.view === 'table' && !ra.refresh) {
    showLoading(`${ra.label}${ident ? ': ' + ident : ''}`, target);
    runAction(ra.action, inputs, { target, claimFocus: true });
    return;
  }
  toast(`${ra.label}: sent to ${target}`);
  runAction(ra.action, inputs, { target, quiet: true, refresh: ra.refresh ? { action: parent.action, inputs: parent.inputs, target } : null })
    .then((j) => { if (!j) return; if (j.state !== 'Completed') showJobResult(j, true); else toast(resultSummary(j.items)); });
}

// ---------------------------------------------------------------- result section
function setResultHead(title, meta, tools = false) {
  $('#result').hidden = false;
  $('#rTitle').textContent = title; $('#rMeta').textContent = meta;
  $('#rFilter').hidden = !tools; $('#rCsv').hidden = !tools;
  $('#rRefresh').hidden = !S.view || !S.view.action;
}
function showLoading(label, target) {
  S.view = null; setResultHead(label, `${target} · running…`);
  $('#rBody').replaceChildren(el('div', { class: 'notice' }, el('p', { text: 'Running on the device. Follow the progress in the Activity Log.' })));
}
function showNotice(label, target, kind, lines, extra) {
  S.view = null; setResultHead(label, target);
  $('#rBody').replaceChildren(el('div', { class: `notice ${kind}` }, lines.map((l) => el('p', { text: l })), extra || null));
}

function showJobResult(job, force = false) {
  const a = actionsOf()[job.action];
  if (!force && job.id !== S.focusJob) {
    toast(`${job.label}: ${job.state === 'Completed' ? 'completed' : 'failed'} (click ↗ in the Activity Log to view)`);
    return;
  }
  S.focusJob = job.id;
  const items = asArray(job.items);
  const texts = items.filter((x) => typeof x === 'string');
  const objs = items.filter(isObj);
  const meta = `${job.target} · ${new Date(job.ended || Date.now()).toLocaleTimeString('en-GB')}`;

  if (job.state !== 'Completed') {
    const errs = job.logs.filter((l) => l.level === 'error').map((l) => l.msg);
    showNotice(job.label, meta, 'err', errs.length ? errs : ['The job did not complete.'],
      job.action !== 'connectivity' ? el('p', {}, el('button', { class: 'mini', text: 'Test connectivity', onclick: () => onAction('connectivity') })) : null);
    return;
  }
  if (a.view === 'none') { toast(texts.join(' ') || 'Completed'); return; }
  if (a.view === 'secret') {
    // Secrets are shown once and then dropped from memory
    if (job.consumed || !objs.length) { toast('For security the password is not kept. Run the action again to read it.'); return; }
    S.view = { action: job.action, inputs: job.inputs, target: job.target, label: job.label, rows: [], texts: [], kind: 'secret' };
    setResultHead(job.label, `${meta} · audited`);
    renderSecret(objs[0], a.secretField || 'Password', job.target);
    job.items = null; job.consumed = true;
    return;
  }

  S.view = { action: job.action, inputs: job.inputs, target: job.target, label: job.label, rows: objs, texts, kind: a.view };
  S.sort = null; S.filter = ''; $('#rFilter').value = '';
  if (a.view === 'table' && objs.length) { setResultHead(job.label, `${meta} · ${objs.length} row(s)`, true); renderTable(); return; }
  if ((a.view === 'kv' || a.view === 'dashboard') && objs.length) { setResultHead(job.label, meta); renderKv(objs[0], texts); return; }
  setResultHead(job.label, meta);
  $('#rBody').replaceChildren(el('div', { class: 'notice ok' },
    (texts.length ? texts : objs.length ? [] : ['Completed with no data to show.']).map((t) => el('p', { text: t })),
    objs.length ? el('pre', { class: 'small-note', text: JSON.stringify(objs, null, 2) }) : null));
}

const fmtCell = (v) => (v == null ? '' : typeof v === 'boolean' ? (v ? 'Yes' : 'No') : typeof v === 'object' ? JSON.stringify(v) : String(v));
const BAD = /^(FAIL|CLOSED|Error|Failed|YES|Stopped|ACTIVE.*|Not found.*)$/, GOOD = /^(OK|OPEN|Passed|Installed|Running|No|Added .*|Removed .*)$/, WARN = /^(WARNING|Warning|Already .*)$/;
const toneClass = (v) => (BAD.test(v) ? 'c-bad' : GOOD.test(v) ? 'c-good' : WARN.test(v) ? 'c-warn' : null);

function visibleColumns() {
  const a = actionsOf()[S.view.action];
  const hide = new Set([...asArray(a.hideColumns), 'PSComputerName', 'RunspaceId', 'PSShowComputerName']);
  const cols = [];
  for (const r of S.view.rows.slice(0, 100)) for (const k of Object.keys(r)) if (!hide.has(k) && !cols.includes(k)) cols.push(k);
  return cols;
}
function filteredRows() {
  let rows = S.view.rows;
  const f = S.filter.toLowerCase();
  if (f) rows = rows.filter((r) => Object.values(r).some((v) => fmtCell(v).toLowerCase().includes(f)));
  if (S.sort) {
    const { col, dir } = S.sort;
    rows = [...rows].sort((x, y) => {
      const a = x[col], b = y[col];
      const c = typeof a === 'number' && typeof b === 'number' ? a - b : fmtCell(a).localeCompare(fmtCell(b), 'en', { numeric: true });
      return dir * c;
    });
  }
  return rows;
}
function renderTable() {
  const a = actionsOf()[S.view.action];
  const cols = visibleColumns();
  const rowActs = asArray(a.rowActions);
  const thead = el('thead', {}, el('tr', {}, cols.map((c) => el('th', {
    class: S.sort && S.sort.col === c ? `sorted ${S.sort.dir < 0 ? 'desc' : ''}` : null, text: c,
    onclick: () => { S.sort = S.sort && S.sort.col === c ? { col: c, dir: -S.sort.dir } : { col: c, dir: 1 }; renderTable(); },
  })), rowActs.length ? el('th', { text: '' }) : null));
  const tbody = el('tbody');
  const rows = filteredRows();
  for (const r of rows.slice(0, 3000)) {
    tbody.append(el('tr', {}, cols.map((c) => {
      const v = fmtCell(r[c]);
      return el('td', { title: v.length > 40 ? v : null, class: toneClass(v), text: v });
    }), rowActs.length ? el('td', { class: 'acts' }, rowActs.map((ra) => el('button', {
      class: `mini ${ra.danger ? 'danger' : ''}`, text: ra.label, onclick: () => onRowAction(ra, r, S.view),
    }))) : null));
  }
  const parts = [];
  if (S.view.texts.length) parts.push(el('div', { class: 'notice ok' }, S.view.texts.map((t) => el('p', { text: t }))));
  parts.push(el('div', { class: 'tablebox' }, el('table', { class: 'tbl' }, thead, tbody)));
  if (rows.length > 3000) parts.push(el('p', { class: 'small-note', text: `Showing 3000 of ${rows.length}. Use the filter or export to CSV.` }));
  $('#rBody').replaceChildren(...parts);
}
function kvRow(k, v) {
  const s = blank(v) ? '—' : fmtCell(v);
  return el('button', { class: 'kvrow', title: s === '—' ? null : `${s} (click to copy)`, onclick: () => copyText(s) },
    el('span', { class: 'k', text: k }), el('span', { class: `v ${toneClass(s) || ''}`, text: s }));
}
function renderKv(obj, texts = []) {
  const flat = Object.entries(obj).filter(([, v]) => !Array.isArray(v));
  $('#rBody').replaceChildren(
    ...(texts.length ? [el('div', { class: 'notice ok' }, texts.map((t) => el('p', { text: t })))] : []),
    el('div', { class: 'rows' }, flat.map(([k, v]) => kvRow(k, v))));
}
// ---------------------------------------------------------------- secret view (LAPS)
const MASK = '••••••••••••';
let secretTimer = null;
function renderSecret(obj, field, target) {
  let secret = String(obj[field] ?? '');
  let shown = false, hideTimer = null;
  const input = el('input', { class: 'secret-input', readonly: true, type: 'text', autocomplete: 'off', spellcheck: 'false', 'aria-label': 'Password' });
  input.value = MASK;
  const reveal = el('button', { class: 'btn btn-primary btn-sm', type: 'button', text: 'Reveal' });
  const hide = () => { shown = false; input.value = MASK; reveal.textContent = 'Reveal'; clearTimeout(hideTimer); };
  reveal.addEventListener('click', () => {
    if (!secret) return;
    if (shown) { hide(); return; }
    shown = true; input.value = secret; reveal.textContent = 'Hide';
    hideTimer = setTimeout(hide, 30000);
  });
  const copy = el('button', { class: 'btn btn-outline btn-sm', type: 'button', text: 'Copy',
    onclick: async () => { if (!secret) return; await writeClipboard(secret); toast('Password copied to clipboard.'); } });
  const box = el('div', { class: 'secret-box' },
    el('div', { class: 'secret-head' },
      el('label', { class: 'field-label', text: `${obj.Account || 'Local administrator'} · ${obj.Computer || target}` }),
      el('span', { class: 'pill pill-warn', text: 'Sensitive · Audited' })),
    el('div', { class: 'secret-row' }, input, reveal, copy),
    el('p', { class: 'hint', text: 'Every retrieval is logged with operator, device and time. The password hides itself after 30 seconds and is cleared from this page after 5 minutes, when you close this result or switch device. Rotate it when you are done.' }));
  const rotate = actionsOf()['laps-rotate']
    ? el('div', { class: 'secret-actions' }, el('button', { class: 'btn btn-outline btn-sm', type: 'button', text: 'Rotate password now', onclick: () => onAction('laps-rotate', {}, target) }))
    : null;
  const details = Object.entries(obj).filter(([k]) => k !== field);
  $('#rBody').replaceChildren(box, el('div', { class: 'rows' }, details.map(([k, v]) => kvRow(k, v))), rotate);
  clearTimeout(secretTimer);
  secretTimer = setTimeout(() => {
    secret = ''; hide();
    if (box.isConnected) $('#rBody').replaceChildren(el('div', { class: 'notice' }, el('p', { text: 'The password was cleared from this page after 5 minutes. Run Get LAPS password again if you still need it.' })));
  }, 300000);
}

function exportCsv() {
  if (!S.view || !S.view.rows.length) return;
  const cols = visibleColumns();
  const esc = (v) => `"${fmtCell(v).replace(/"/g, '""')}"`;
  const lines = [cols.map(esc).join(';'), ...filteredRows().map((r) => cols.map((c) => esc(r[c])).join(';'))];
  const blob = new Blob(['\ufeff' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
  const a = el('a', { href: URL.createObjectURL(blob), download: `${S.view.target}_${S.view.action}_${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-')}.csv` });
  document.body.append(a); a.click(); a.remove();
}

// ---------------------------------------------------------------- selected device: header, health, diagnostics
const sysDisk = (m) => asArray(m && m.Disks).find((d) => /^C:/i.test(d.Drive)) || asArray(m && m.Disks)[0];
const osShort = (os) => String(os || '').replace(/^Microsoft\s+/i, '').replace(/\s+(Enterprise|Pro|Education|Home)\b.*$/i, '');
const hostShort = (h) => (blank(h) ? '—' : String(h).split('.')[0]);
const gb = (mb) => (mb / 1024).toFixed(1);

// [label, value(m), tone(m)] - tone: ok | info | warn | crit
const DIAG = [
  ['CcmExec Service', (m) => m.CcmExecState, (m) => (m.CcmExecState === 'Running' ? 'ok' : m.CcmExecState === 'Not installed' ? 'warn' : 'crit')],
  ['Agent Version', (m) => m.ClientVersion, (m) => (m.ClientVersion === 'Not installed' ? 'warn' : 'info')],
  ['Disk Space (C:)', (m) => { const d = sysDisk(m); return d ? `${d.FreeGB} GB Free` : '—'; },
    (m) => { const d = sysDisk(m); return !d ? 'info' : d.UsedPct >= 95 ? 'crit' : d.UsedPct >= 85 ? 'warn' : 'ok'; }],
  ['Last Machine Policy', (m) => ago(m.LastMachinePolicy), (m) => { const h = ageHours(m.LastMachinePolicy); return h == null ? 'info' : h > 168 ? 'crit' : h > 24 ? 'warn' : 'ok'; }],
  ['Last HW Inventory', (m) => ago(m.HwScan), (m) => { const h = ageHours(m.HwScan); return h == null ? 'info' : h > 336 ? 'crit' : h > 168 ? 'warn' : 'ok'; }],
  ['Client Cache', (m) => (m.CacheSizeMB ? `${gb(m.CacheUsedMB || 0)} / ${gb(m.CacheSizeMB)} GB` : '—'),
    (m) => (m.CacheSizeMB && m.CacheUsedMB / m.CacheSizeMB > 0.9 ? 'warn' : 'info')],
  ['Pending Reboot', (m) => (m.RebootPending === 'Yes' ? 'Yes' : m.RebootPending === 'No' ? 'None' : '—'), (m) => (m.RebootPending === 'Yes' ? 'warn' : m.RebootPending === 'No' ? 'ok' : 'info')],
  ['Site / MP', (m) => (blank(m.SiteCode) ? '—' : `${m.SiteCode} / ${hostShort(m.ManagementPoint)}`), () => 'info'],
  ['AD Site', (m) => m.ADSite, () => 'info'],
  ['OS', (m) => `${osShort(m.OS)} ${m.Release || ''}`.trim(), () => 'info'],
  ['Model', (m) => m.Model, () => 'info'],
  ['Uptime', (m) => m.Uptime, (m) => { const d = parseInt(m.Uptime, 10); return d > 30 ? 'warn' : 'ok'; }],
];
const TONE_TXT = { ok: 'OK', info: '·', warn: '!', crit: '!', none: '·' };

function renderDiag(m) {
  const g = $('#diagGrid'); g.replaceChildren();
  for (const [label, val, tone] of DIAG) {
    const v = m ? val(m) : null;
    const s = blank(v) ? '—' : String(v);
    const t = m ? tone(m) : 'none';
    g.append(el('button', { class: 'tile', title: s === '—' ? label : `${label}: ${s} (click to copy)`, onclick: () => copyText(s) },
      el('span', { class: 'tile-label', text: label }),
      el('div', { class: 'tile-row' }, el('span', { class: `tile-val ${t === 'crit' ? 'crit' : ''}`, text: s }), el('span', { class: `tone tone-${t}`, text: TONE_TXT[t] }))));
  }
}

function renderHealth(m, state) {
  const title = $('#healthTitle'), text = $('#healthText'), badge = $('#healthBadge');
  title.textContent = 'Device Health';
  if (!m) {
    const map = {
      connecting: ['Connecting…', 'badge-warn', `Establishing a session with ${S.target}…`],
      failed: ['Unreachable', 'badge-crit', `Could not connect to ${S.target}. Try Remote & Tools > Test connectivity.`],
    };
    const [b, cls, t] = map[state] || ['No device', 'badge-muted', 'Connect to a device to see its health summary.'];
    text.textContent = t; badge.textContent = b; badge.className = `badge ${cls}`;
    return;
  }
  const issues = DIAG.map(([label, val, tone]) => ({ label, v: val(m), t: tone(m) })).filter((x) => x.t === 'warn' || x.t === 'crit');
  title.textContent = `Device Health · ${m.ComputerName}`;
  if (!issues.length) {
    text.textContent = 'All diagnostic checks passed for this device.';
    badge.textContent = 'Healthy'; badge.className = 'badge badge-ok';
  } else {
    text.textContent = issues.map((i) => `${i.label}: ${blank(i.v) ? '—' : i.v}`).join(' · ');
    const crit = issues.some((i) => i.t === 'crit');
    badge.textContent = `${issues.length} issue${issues.length > 1 ? 's' : ''}`;
    badge.className = `badge ${crit ? 'badge-crit' : 'badge-warn'}`;
  }
}

function setDevState(kind, text) {
  $('#devState').className = `state state-${kind}`;
  $('#devStateText').textContent = text;
}
function renderDeviceHead(m) {
  $('#devName').textContent = m ? m.ComputerName : (S.target ? S.target.toUpperCase() : 'No device selected');
  const u = $('#devUser'); u.replaceChildren();
  if (!m) { u.textContent = S.target ? 'Waiting for connection…' : 'Type a hostname in Find Device and click Connect.'; return; }
  const parts = [['User', m.FullName], ['Email', m.Email], ['Manager', m.Manager]].filter(([, v]) => !blank(v));
  parts.forEach(([k, v], i) => { if (i) u.append(' · '); u.append(`${k}: `, el('b', { text: v })); });
}

// ---------------------------------------------------------------- section panels
// Tiles already show agent, MP, model, OS release and uptime; this list adds the rest
const HW_ROWS = [
  ['Build', (m) => m.Build], ['Manufacturer', (m) => m.Manufacturer], ['Serial number', (m) => m.SerialNumber],
  ['CPU', (m) => m.CPU], ['Memory', (m) => (blank(m.MemoryGB) ? null : `${m.MemoryGB} GB`)], ['FQDN', (m) => m.FQDN],
  ['IP address', (m) => m.IPAddress], ['MAC address', (m) => m.MACAddress], ['Last boot', (m) => m.LastBoot],
  ['SW inventory', (m) => m.SwScan], ['Connection', (m) => m.Protocol],
];

function secTitle(text, note) {
  return el('h4', { class: 'sec-title' }, text, note ? el('span', { class: 'sec-note', text: note }) : null);
}
function chip(id) {
  const a = actionsOf()[id];
  const running = [...S.jobs.values()].some((j) => j.action === id && j.state === 'Running');
  const asks = asArray(a.inputs).length || a.confirm;
  return el('button', {
    class: `ach ${a.danger ? 'danger' : ''} ${running ? 'running' : ''}`, 'data-id': id,
    title: a.description || a.label, disabled: !a.noConnection && !S.connected, onclick: () => onAction(id),
  }, el('span', { text: a.label }), asks ? el('span', { class: 'more', text: '…' }) : null, a.local ? el('span', { class: 'loc', text: 'local' }) : null);
}
function renderPanel() {
  const cat = S.manifest.categories.find((c) => c.id === S.tab);
  const box = $('#panels'); box.replaceChildren();
  for (const g of cat.groups) {
    const note = g.actions.some((id) => actionsOf()[id].danger) ? 'Some actions ask for confirmation' : null;
    box.append(el('div', { class: 'sec' }, secTitle(g.label, note), el('div', { class: 'chips' }, g.actions.map(chip))));
  }
  if (cat.overview) {
    const m = S.machine;
    const hw = el('div', {}, secTitle('Hardware & agent'), m
      ? el('div', { class: 'rows' }, HW_ROWS.map(([k, f]) => kvRow(k, f(m))))
      : el('p', { class: 'small-note', text: 'Connect to a device to see its details.' }));
    const disks = asArray(m && m.Disks);
    const st = el('div', {}, secTitle('Storage', disks.length ? `${disks.length} local disk(s)` : null), disks.length
      ? el('div', { class: 'rows' }, disks.map((d) => el('div', { class: 'disk' },
          el('div', { class: 'disk-top' }, el('b', { text: `${d.Drive}${d.Label ? ' ' + d.Label : ''}` }),
            el('span', { text: `${Math.round((d.TotalGB - d.FreeGB) * 10) / 10} / ${d.TotalGB} GB (${d.UsedPct}%) · ${d.FreeGB} GB free` })),
          el('div', { class: `bar ${d.UsedPct >= 95 ? 'crit' : d.UsedPct >= 85 ? 'high' : ''}` }, el('span', { style: `width:${d.UsedPct}%` })))))
      : el('p', { class: 'small-note', text: m ? 'No local disk found.' : 'Connect to a device to see its disks.' }));
    box.append(el('div', { class: 'two' }, hw, st));
  }
}
function renderNav() {
  const nav = $('#tabNav'); nav.replaceChildren();
  for (const c of S.manifest.categories) {
    nav.append(el('button', { class: `navbtn ${S.tab === c.id ? 'active' : ''}`, text: c.label, onclick: () => { S.tab = c.id; renderNav(); renderPanel(); } }));
  }
}

// ---------------------------------------------------------------- recent devices
function recents() {
  try {
    return JSON.parse(localStorage.getItem('ep.recent') || '[]')
      .map((r) => (typeof r === 'string' ? { name: r } : r)).filter((r) => r && r.name);
  } catch { return []; }
}
function saveRecents(list) { try { localStorage.setItem('ep.recent', JSON.stringify(list.slice(0, 12))); } catch { /* no storage */ } }
function pushRecent(m, target) {
  const issues = DIAG.filter(([, , tone]) => ['warn', 'crit'].includes(tone(m))).length;
  const crit = DIAG.some(([, , tone]) => tone(m) === 'crit');
  const entry = { name: target, host: m.ComputerName, user: m.FullName, os: `${osShort(m.OS)} ${m.Release || ''}`.trim(), when: Date.now(), issues, crit };
  saveRecents([entry, ...recents().filter((r) => r.name.toLowerCase() !== target.toLowerCase())]);
  renderRecents();
}
function renderRecents() {
  const list = recents();
  $('#recentOptions').replaceChildren(...list.map((r) => el('option', { value: r.name })));
  const box = $('#recentList'); box.replaceChildren();
  if (!list.length) box.append(el('p', { class: 'empty-note', text: 'Devices you connect to will appear here.' }));
  list.forEach((r, i) => {
    const pill = r.issues == null ? null
      : r.issues ? el('span', { class: `pill ${r.crit ? 'pill-crit' : 'pill-warn'}`, text: `${r.issues} issue${r.issues > 1 ? 's' : ''}` })
      : el('span', { class: 'pill pill-ok', text: 'Healthy' });
    const sub = [r.user && !/^No user/.test(r.user) ? r.user : null, r.os, r.when ? agoHours((Date.now() - r.when) / 36e5) : null];
    box.append(el('button', { class: 'rec', onclick: () => { $('#target').value = r.name; connect(r.name); } },
      el('div', { class: 'rec-top' }, el('span', { class: 'rec-name' }, el('span', { class: 'n', text: `${i + 1}.` }), (r.host || r.name).toUpperCase()), pill),
      el('div', { class: 'rec-sub', text: sub.filter(Boolean).join(' · ') || 'Not connected yet' })));
  });
  $('#recentCount').textContent = list.length ? `${list.length} recent device${list.length > 1 ? 's' : ''} · stored on this workstation` : 'No recent devices';
}

// ---------------------------------------------------------------- connection
async function connect(target) {
  if (!TARGET_RX.test(target)) { toast('Invalid hostname.'); return; }
  S.target = target; S.connected = false; S.machine = null;
  renderDeviceHead(null); renderDiag(null); renderHealth(null, 'connecting'); renderPanel();
  setDevState('wait', 'Connecting');
  $('#btnConnect').disabled = true;
  showLoading('Connect', target);
  const job = await runAction(S.manifest.connectAction, {}, {
    target, claimFocus: true,
    onDone: (j) => {
      const m = asArray(j.items).find(isObj);
      if (j.state === 'Completed' && m) {
        S.connected = true; S.machine = m;
        renderDeviceHead(m); renderDiag(m); renderHealth(m); pushRecent(m, target);
        setDevState('on', `Connected · ${m.Protocol || 'CIM'}`);
        $('#result').hidden = true; S.view = null;
        toast(`Connected to ${m.ComputerName} — site, MP and cache read from the device.`);
      } else {
        setDevState('err', 'Unreachable'); renderHealth(null, 'failed'); renderDeviceHead(null);
        showJobResult(j, true);
      }
      renderPanel();
    },
  });
  $('#btnConnect').disabled = false;
  if (!job) { setDevState('err', 'Unreachable'); renderHealth(null, 'failed'); }
}

// ---------------------------------------------------------------- startup
async function init() {
  renderDiag(null); renderRecents();
  if (!token()) {
    showNotice('Session not found', '', 'err', ['Open the portal through Start-EndpointPortal.cmd to start a secure session.']);
    $('#btnConnect').disabled = true; return;
  }
  try {
    const info = await api('/api/info');
    $('#version').textContent = `v${info.version}`;
    $('#operator').textContent = info.operator;
    $('#navStatus').textContent = `Local server on ${info.station} · no installation`;
    document.title = `Endpoint Portal Tool v${info.version}`;
    S.manifest = await api('/api/manifest');
  } catch (e) {
    showNotice('Local server unavailable', '', 'err', [e.message, 'Start it again with Start-EndpointPortal.cmd.']);
    return;
  }
  S.tab = S.manifest.categories[0].id;
  renderNav(); renderPanel();
  term('', '', 'debug', `Endpoint Portal Tool ready. ${Object.keys(S.manifest.actions).length} actions loaded from scripts\\manifest.json.`);
  $('#target').focus();
}

$('#connectForm').addEventListener('submit', (e) => { e.preventDefault(); const t = $('#target').value.trim(); if (t) connect(t); });
$('#rFilter').addEventListener('input', (e) => { S.filter = e.target.value; if (S.view && S.view.kind === 'table') renderTable(); });
$('#rCsv').addEventListener('click', exportCsv);
$('#rRefresh').addEventListener('click', () => { if (S.view && S.view.action) { const v = S.view; showLoading(v.label, v.target); runAction(v.action, v.inputs, { target: v.target, claimFocus: true }); } });
$('#rClose').addEventListener('click', () => { $('#result').hidden = true; $('#rBody').replaceChildren(); S.view = null; S.focusJob = null; });
$('#btnClear').addEventListener('click', () => termEl.replaceChildren());
$('#btnClearRecent').addEventListener('click', () => { saveRecents([]); renderRecents(); });
$('#btnShutdown').addEventListener('click', async () => {
  const ok = await openDialog({ title: 'Shut down Endpoint Portal Tool?', text: 'The local server will stop. Running jobs will be cancelled.', okLabel: 'Shut down', danger: true });
  if (!ok) return;
  try { await api('/api/shutdown', { method: 'POST' }); } catch { /* already stopped */ }
  document.body.replaceChildren(el('div', { style: 'margin:15vh auto;text-align:center;font-family:inherit' },
    el('p', {}, el('strong', { text: 'Endpoint Portal Tool has stopped.' })), el('p', { style: 'color:#6C757D', text: 'You can close this window.' })));
});

init();
