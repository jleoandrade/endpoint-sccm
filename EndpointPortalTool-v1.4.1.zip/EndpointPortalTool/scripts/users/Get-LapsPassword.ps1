<#
.SYNOPSIS  Reads the device's local administrator password from Active Directory (LAPS).
.DESCRIPTION
    Supports Windows LAPS (clear-text or encrypted, via the built-in LAPS module) and legacy
    Microsoft LAPS (ms-Mcs-AdmPwd). Works even when the device is offline: only Active Directory
    is queried. The password is never written to the log or the audit file.
.NOTES     Endpoint Portal Tool 1.3.0 - requires read permission on the LAPS attributes
           (encrypted Windows LAPS also requires membership in the authorized decryptor group)
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'

Write-EPProgress 15 'Locating computer in Active Directory'
$ad = Resolve-EPADComputer -ComputerName $ComputerName
Write-EPLog "Computer object: $($ad.DistinguishedName)" -Level debug

$result = $null

# 1) Windows LAPS module (handles clear-text, encrypted and legacy-emulation passwords)
Write-EPProgress 40 'Querying Windows LAPS'
Import-Module LAPS -ErrorAction SilentlyContinue
if (Get-Command Get-LapsADPassword -ErrorAction SilentlyContinue) {
    try {
        $r = Get-LapsADPassword -Identity $ad.DistinguishedName -Domain $ad.Domain -AsPlainText -ErrorAction Stop | Select-Object -First 1
        if ($r -and [string]$r.DecryptionStatus -eq 'Unauthorized') {
            throw "The LAPS password is encrypted and your account is not an authorized decryptor (authorized: $($r.AuthorizedDecryptor))."
        }
        if ($r -and $r.Password) {
            $source = switch -Wildcard ([string]$r.Source) {
                'Encrypted*'       { 'Windows LAPS (encrypted)' }
                'LegacyLaps*'      { 'Legacy LAPS (ms-Mcs-AdmPwd)' }
                default            { 'Windows LAPS (clear-text)' }
            }
            $result = [ordered]@{
                Account = [string]$r.Account; Password = [string]$r.Password; Source = $source
                Updated = $r.PasswordUpdateTime; Expires = $r.ExpirationTimestamp
            }
        }
    } catch {
        if ($_.Exception.Message -like 'The LAPS password is encrypted*') { throw }
        Write-EPLog "Get-LapsADPassword: $($_.Exception.Message)" -Level debug
    }
} else {
    Write-EPLog 'LAPS PowerShell module not found on this workstation; reading the attributes directly.' -Level debug
}

# 2) Direct LDAP read (legacy LAPS and clear-text Windows LAPS) - no module required
if (-not $result) {
    Write-EPProgress 70 'Reading LAPS attributes'
    $path  = "LDAP://$($ad.Domain)/$($ad.DistinguishedName -replace '/', '\/')"
    $attrs = [string[]]@('ms-Mcs-AdmPwd', 'ms-Mcs-AdmPwdExpirationTime', 'msLAPS-Password', 'msLAPS-PasswordExpirationTime', 'msLAPS-EncryptedPassword')
    $searcher = New-Object System.DirectoryServices.DirectorySearcher((New-Object System.DirectoryServices.DirectoryEntry($path)), '(objectClass=computer)', $attrs, [System.DirectoryServices.SearchScope]::Base)
    $p = $searcher.FindOne().Properties
    $first = { param($n) if ($p[$n] -and $p[$n].Count) { $p[$n][0] } else { $null } }
    $fromFileTime = { param($v) if ($v -and [int64]$v -gt 0) { [DateTime]::FromFileTime([int64]$v) } else { $null } }

    $winLaps = & $first 'mslaps-password'
    $legacy  = & $first 'ms-mcs-admpwd'
    if ($winLaps) {
        $j = [string]$winLaps | ConvertFrom-Json
        $updated = $null
        try { $updated = [DateTime]::FromFileTimeUtc([Convert]::ToInt64([string]$j.t, 16)).ToLocalTime() } catch {}
        $result = [ordered]@{ Account = [string]$j.n; Password = [string]$j.p; Source = 'Windows LAPS (clear-text)'
            Updated = $updated; Expires = & $fromFileTime (& $first 'mslaps-passwordexpirationtime') }
    } elseif ($legacy) {
        $result = [ordered]@{ Account = ''; Password = [string]$legacy; Source = 'Legacy LAPS (ms-Mcs-AdmPwd)'
            Updated = $null; Expires = & $fromFileTime (& $first 'ms-mcs-admpwdexpirationtime') }
    } elseif (& $first 'mslaps-encryptedpassword') {
        throw 'This device uses encrypted Windows LAPS. Decrypting needs the LAPS PowerShell module on this workstation (Windows 11 22H2+, or Windows 10/Server 2019+ with the April 2023 update or later).'
    }
}

if (-not $result -or -not $result.Password) {
    throw "No LAPS password was returned for $($ad.Name). Either LAPS is not applied to this device yet, or your account does not have permission to read it."
}

Write-EPProgress 100 'Done'
Write-EPLog "LAPS password retrieved for $($ad.Name) ($($result.Source)). This retrieval is recorded in the audit log." -Level ok

[pscustomobject]@{
    Password             = $result.Password
    Account              = if ($result.Account) { $result.Account } else { 'Managed local administrator' }
    Computer             = $ad.Name
    Source               = $result.Source
    'Password updated'   = Format-EPDate $result.Updated
    'Expires'            = Format-EPDate $result.Expires
    'Domain'             = $ad.Domain
    'Distinguished name' = $ad.DistinguishedName
}
