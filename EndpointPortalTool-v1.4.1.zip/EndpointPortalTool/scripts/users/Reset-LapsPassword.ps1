<#
.SYNOPSIS  Expires the current LAPS password so the device sets a new one (rotation after use).
.DESCRIPTION
    Sets the LAPS expiration time to now in Active Directory (Windows LAPS and/or legacy LAPS),
    then, if the device is online and WinRM responds, triggers LAPS policy processing so the
    rotation happens right away. Otherwise the device rotates at its next LAPS policy cycle.
.NOTES     Endpoint Portal Tool 1.3.0 - requires write permission on the LAPS expiration attribute
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'

Write-EPProgress 15 'Locating computer in Active Directory'
$ad = Resolve-EPADComputer -ComputerName $ComputerName

Write-EPProgress 35 'Reading LAPS state'
$path  = "LDAP://$($ad.Domain)/$($ad.DistinguishedName -replace '/', '\/')"
$attrs = [string[]]@('ms-Mcs-AdmPwdExpirationTime', 'msLAPS-PasswordExpirationTime')
$searcher = New-Object System.DirectoryServices.DirectorySearcher((New-Object System.DirectoryServices.DirectoryEntry($path)), '(objectClass=computer)', $attrs, [System.DirectoryServices.SearchScope]::Base)
$p = $searcher.FindOne().Properties
$hasWin    = [bool]($p['mslaps-passwordexpirationtime'] -and $p['mslaps-passwordexpirationtime'].Count)
$hasLegacy = [bool]($p['ms-mcs-admpwdexpirationtime'] -and $p['ms-mcs-admpwdexpirationtime'].Count)
if (-not $hasWin -and -not $hasLegacy) { throw "No LAPS password is set on $($ad.Name) (or you cannot read its expiration time). Nothing to rotate." }

Write-EPProgress 55 'Expiring the current password'
$now = [DateTime]::UtcNow.ToFileTimeUtc().ToString()
$done = @()
if ($hasWin) {
    Import-Module LAPS -ErrorAction SilentlyContinue
    if (Get-Command Set-LapsADPasswordExpirationTime -ErrorAction SilentlyContinue) {
        $null = Set-LapsADPasswordExpirationTime -Identity $ad.DistinguishedName -Domain $ad.Domain -ErrorAction Stop
        $done += 'Windows LAPS'
    }
}
$direct = @()
if ($hasWin -and $done -notcontains 'Windows LAPS') { $direct += 'msLAPS-PasswordExpirationTime' }
if ($hasLegacy) { $direct += 'ms-Mcs-AdmPwdExpirationTime' }
if ($direct) {
    Add-Type -AssemblyName System.DirectoryServices.Protocols
    $conn = New-Object System.DirectoryServices.Protocols.LdapConnection($ad.Domain)
    $conn.SessionOptions.Signing = $true; $conn.SessionOptions.Sealing = $true
    try {
        foreach ($attr in $direct) {
            $req = New-Object System.DirectoryServices.Protocols.ModifyRequest($ad.DistinguishedName, [System.DirectoryServices.Protocols.DirectoryAttributeOperation]::Replace, $attr, $now)
            $null = $conn.SendRequest($req)
            $done += $(if ($attr -like 'msLAPS*') { 'Windows LAPS' } else { 'Legacy LAPS' })
        }
    } catch [System.DirectoryServices.Protocols.DirectoryOperationException] {
        throw "Active Directory refused the change ($($_.Exception.Message)). Your account needs write permission on the LAPS expiration attribute."
    } finally { $conn.Dispose() }
}
Write-EPLog "Password expired in Active Directory ($($done -join ', '))." -Level ok

# Ask the device to process LAPS now (best effort)
Write-EPProgress 80 'Triggering rotation on the device'
$rotatedNow = $false
try {
    $msg = Invoke-EPRemote -ComputerName $ComputerName -ScriptBlock {
        if (Get-Command Invoke-LapsPolicyProcessing -ErrorAction SilentlyContinue) { Invoke-LapsPolicyProcessing; 'Windows LAPS policy processing triggered.' }
        else { gpupdate.exe /target:computer /force /wait:60 | Out-Null; 'Group Policy refreshed (legacy LAPS rotates during GP processing).' }
    }
    Write-EPLog $msg -Level ok
    $rotatedNow = $true
} catch {
    Write-EPLog "The device could not be reached now ($($_.Exception.Message.Split([Environment]::NewLine)[0]))." -Level warn
}
Write-EPProgress 100 'Done'
if ($rotatedNow) { "LAPS password for $($ad.Name) was expired and the device was asked to rotate it now. Use 'Get LAPS password' in a minute to read the new one." }
else      { "LAPS password for $($ad.Name) was expired. The device will set a new one at its next LAPS policy cycle (when it is online)." }
