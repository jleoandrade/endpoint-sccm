<#
.SYNOPSIS  Adds or removes computers in ConfigMgr device collections (one or many of each).
.DESCRIPTION
    Unified version of the team's five "SCCM Collection Manager" scripts.
    - Collections that list computers in a query rule (... Name in ("PC01","PC02")) get the computer
      added to / removed from that list. Only the IN (...) list is changed; the rest of the query is kept.
    - Other collections use direct membership rules.
    - The new query rule is validated and added BEFORE the old one is deleted, so a failure never
      leaves the collection without its rule.
    - Collection membership is refreshed and, on add, a Machine Policy request is sent to the devices
      through the client notification channel.
    Talks to the SMS Provider over WMI/CIM: the ConfigMgr console and module are NOT required.
.PARAMETER Operation    Add | Remove
.PARAMETER Collections  Collection IDs or exact names, separated by commas or new lines.
.PARAMETER Computers    Computer names separated by commas, spaces or new lines. Empty = the selected device.
.NOTES     Endpoint Portal Tool 1.4.1 - requires ConfigMgr rights to modify the collections
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][ValidateSet('Add', 'Remove')][string]$Operation,
    [Parameter(Mandatory)][string]$Collections,
    [string]$Computers = ''
)
$ErrorActionPreference = 'Stop'

# ---- Parse input
if (-not $Computers.Trim()) { $Computers = $ComputerName }
$names = @($Computers -split '[,;\s]+' | ForEach-Object { $_.Trim().Split('.')[0].ToUpper() } | Where-Object { $_ } | Select-Object -Unique)
foreach ($n in $names) { if ($n -notmatch '^[A-Z0-9][A-Z0-9\-_]{0,62}$') { throw "Invalid computer name: $n" } }
$collInput = @($Collections -split '[,;\r\n]+' | ForEach-Object { $_.Trim() } | Where-Object { $_ } | Select-Object -Unique)
if (-not $names.Count) { throw 'Enter at least one computer name.' }
if (-not $collInput.Count) { throw 'Enter at least one collection name or ID.' }
if ($names.Count -gt 200) { throw 'Up to 200 computers per run.' }

Write-EPProgress 5 'Connecting to the SMS Provider'
$sms = Connect-EPSmsProvider
$s = $sms.Session; $ns = $sms.Namespace
$wql = { param($v) $v.Replace('\', '\\').Replace("'", "\'") }

try {
    # ---- Resolve collections (ID or exact name; device collections only)
    Write-EPProgress 15 'Resolving collections'
    # @() keeps $targets a list even with ONE collection (in Windows PowerShell 5.1 a single CIM object has no .Count)
    $targets = @(foreach ($c in $collInput) {
        $f = if ($c -match '^[A-Za-z0-9]{3}[0-9A-Fa-f]{5}$') { "CollectionID='$($c.ToUpper())'" } else { "Name='$(& $wql $c)'" }
        $col = @(Get-CimInstance -CimSession $s -Namespace $ns -ClassName SMS_Collection -Filter "$f AND CollectionType=2")
        if (-not $col.Count) { throw "Device collection '$c' not found. Use 'Find collections' to get the exact name or ID." }
        if ($col.Count -gt 1) { throw "More than one collection is named '$c'. Use its Collection ID instead." }
        $col[0]
    })

    # ---- Resolve devices
    Write-EPProgress 25 'Resolving devices in ConfigMgr'
    $devices = @{}
    foreach ($n in $names) {
        $d = @(Get-CimInstance -CimSession $s -Namespace $ns -ClassName SMS_R_System -Filter "Name='$n'" -Property ResourceId, Name, Client, Obsolete)
        $d = @($d | Where-Object { $_.Obsolete -ne 1 } | Sort-Object { -[int]$_.Client })
        if ($d.Count) { $devices[$n] = $d[0] }
        elseif ($Operation -eq 'Add') { Write-EPLog "$n was not found in ConfigMgr; it will be skipped." -Level warn }
    }

    $classQuery  = Get-CimClass -CimSession $s -Namespace $ns -ClassName SMS_CollectionRuleQuery
    $classDirect = Get-CimClass -CimSession $s -Namespace $ns -ClassName SMS_CollectionRuleDirect
    $rows = New-Object System.Collections.Generic.List[object]
    $addRow = { param($col, $n, $res) $rows.Add([pscustomobject]@{ Collection = $col.Name; CollectionID = $col.CollectionID; Computer = $n; Result = $res }) }

    $i = 0
    foreach ($col in $targets) {
        $i++
        Write-EPProgress (25 + [int](65 * ($i - 1) / $targets.Count)) "$($Operation): $($col.Name)"
        $col = Get-CimInstance -CimSession $s -InputObject $col          # loads the lazy CollectionRules property
        $rules = @($col.CollectionRules)
        $listRule = $rules | Where-Object { $_.CimSystemProperties.ClassName -eq 'SMS_CollectionRuleQuery' -and (Test-EPQueryNameList $_.QueryExpression) } | Select-Object -First 1
        $directRules = @($rules | Where-Object { $_.CimSystemProperties.ClassName -eq 'SMS_CollectionRuleDirect' })
        $changed = $false

        $listNames = @(if ($listRule) { Get-EPQueryNameList $listRule.QueryExpression })
        $newList = [System.Collections.Generic.List[string]]::new(); foreach ($x in $listNames) { $newList.Add($x) }

        foreach ($n in $names) {
            $dev = $devices[$n]
            $direct = @($directRules | Where-Object { ($dev -and $_.ResourceID -eq $dev.ResourceId) -or $_.RuleName -eq $n })
            if ($Operation -eq 'Add') {
                if (-not $dev) { & $addRow $col $n 'Not found in ConfigMgr'; continue }
                if ($listRule) {
                    if ($newList -contains $n) { & $addRow $col $n 'Already in query list' }
                    else { $newList.Add($n); & $addRow $col $n 'Added (query list)' }
                } elseif ($direct.Count) {
                    & $addRow $col $n 'Already a direct member'
                } else {
                    $rule = New-CimInstance -CimClass $classDirect -ClientOnly -Property @{
                        ResourceClassName = 'SMS_R_System'; ResourceID = [uint32]$dev.ResourceId; RuleName = $n }
                    $null = Invoke-CimMethod -InputObject $col -MethodName AddMembershipRule -Arguments @{ collectionRule = [ciminstance]$rule }
                    & $addRow $col $n 'Added (direct rule)'; $changed = $true
                }
            } else {
                $done = @()
                if ($listRule -and $newList.Remove($n)) { $done += 'query list' }
                foreach ($r in $direct) {
                    $null = Invoke-CimMethod -InputObject $col -MethodName DeleteMembershipRule -Arguments @{ collectionRule = [ciminstance]$r }
                    if ($done -notcontains 'direct rule') { $done += 'direct rule' }
                    $changed = $true
                }
                & $addRow $col $n $(if ($done) { "Removed ($($done -join ' + '))" } else { 'Not a list or direct member (no change)' })
            }
        }

        # Apply the new name list: validate, add the new rule, then delete the old one
        if ($listRule -and (($listNames -join ',') -ne (@($newList) -join ','))) {
            $newQuery = Set-EPQueryNameList -Query $listRule.QueryExpression -Names @($newList)
            $ok = Invoke-CimMethod -CimSession $s -Namespace $ns -ClassName SMS_CollectionRuleQuery -MethodName ValidateQuery -Arguments @{ WQLQuery = $newQuery }
            if (-not $ok.ReturnValue) { throw "The updated query for '$($col.Name)' did not validate; nothing was changed in this collection." }
            $newRule = New-CimInstance -CimClass $classQuery -ClientOnly -Property @{ RuleName = $listRule.RuleName; QueryExpression = $newQuery }
            $null = Invoke-CimMethod -InputObject $col -MethodName AddMembershipRule -Arguments @{ collectionRule = [ciminstance]$newRule }
            $null = Invoke-CimMethod -InputObject $col -MethodName DeleteMembershipRule -Arguments @{ collectionRule = [ciminstance]$listRule }
            Write-EPLog "$($col.Name): query rule '$($listRule.RuleName)' updated ($($newList.Count) computer(s) in the list)." -Level ok
            $changed = $true
        }

        if ($changed) {
            $null = Invoke-CimMethod -InputObject $col -MethodName RequestRefresh -Arguments @{ IncludeSubCollections = $false }
            Write-EPLog "$($col.Name): membership update requested." -Level ok
        } else {
            Write-EPLog "$($col.Name): nothing to change." -Level info
        }
    }

    # ---- On add: ask the clients to download policy now (fast channel, best effort)
    if ($Operation -eq 'Add') {
        $ids = @($rows | Where-Object { $_.Result -like 'Added*' } | ForEach-Object { $devices[$_.Computer].ResourceId } | Select-Object -Unique)
        if ($ids.Count) {
            Write-EPProgress 95 'Requesting Machine Policy on the devices'
            try {
                $null = Invoke-CimMethod -CimSession $s -Namespace $ns -ClassName SMS_ClientOperation -MethodName InitiateClientOperation -Arguments @{
                    Type = [uint32]8; TargetCollectionID = 'SMS00001'; RandomizationWindow = [uint32]0; TargetResourceIDs = [uint32[]]$ids }
                Write-EPLog "Machine Policy request sent to $($ids.Count) device(s). Online clients pick it up within a minute; give the collection a few minutes to update." -Level ok
            } catch {
                Write-EPLog "Could not send the Machine Policy request ($($_.Exception.Message)). Run 'Machine Policy Retrieval' on the device later." -Level warn
            }
        }
    }

    Write-EPProgress 100 'Done'
    $rows
}
finally { Remove-CimSession $s -ErrorAction SilentlyContinue }
