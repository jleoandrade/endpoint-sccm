<#
.SYNOPSIS  Searches ConfigMgr device collections by name (server-side filter) and shows how membership is defined.
.NOTES     Endpoint Portal Tool 1.4.0 - console not required
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][string]$Search
)
$ErrorActionPreference = 'Stop'
$Search = $Search.Trim()
if ($Search.Length -lt 2 -or $Search.Length -gt 100) { throw 'Type 2 to 100 characters of the collection name.' }

Write-EPProgress 10 'Connecting to the SMS Provider'
$sms = Connect-EPSmsProvider
try {
    Write-EPProgress 40 "Searching '$Search'"
    $like = $Search.Replace('\', '\\').Replace("'", "\'").Replace('[', '[[]').Replace('_', '[_]').Replace('*', '%')
    $found = @(Get-CimInstance -CimSession $sms.Session -Namespace $sms.Namespace -ClassName SMS_Collection `
        -Filter "CollectionType=2 AND Name LIKE '%$like%'" | Sort-Object Name)
    $max = 100
    if ($found.Count -gt $max) { Write-EPLog "$($found.Count) collections match; showing the first $max. Refine the search." -Level warn }
    $i = 0
    $rows = foreach ($c in ($found | Select-Object -First $max)) {
        $i++; Write-EPProgress (40 + [int](55 * $i / [Math]::Min($found.Count, $max))) 'Reading membership rules'
        $full  = Get-CimInstance -CimSession $sms.Session -InputObject $c
        $rules = @($full.CollectionRules)
        $list  = @($rules | Where-Object { $_.CimSystemProperties.ClassName -eq 'SMS_CollectionRuleQuery' -and (Test-EPQueryNameList $_.QueryExpression) })
        $dyn   = @($rules | Where-Object { $_.CimSystemProperties.ClassName -eq 'SMS_CollectionRuleQuery' }).Count - $list.Count
        $dir   = @($rules | Where-Object { $_.CimSystemProperties.ClassName -eq 'SMS_CollectionRuleDirect' }).Count
        $parts = @()
        if ($list.Count) { $parts += "Query list ($(@(Get-EPQueryNameList $list[0].QueryExpression).Count) names)" }
        if ($dir)        { $parts += "Direct ($dir)" }
        if ($dyn -gt 0)  { $parts += "Dynamic query ($dyn)" }
        [pscustomobject]@{
            Name         = $c.Name
            CollectionID = $c.CollectionID
            Members      = $c.MemberCount
            Membership   = if ($parts) { $parts -join ' + ' } else { 'No rules' }
            'Add method' = if ($list.Count) { 'Query list' } else { 'Direct rule' }
            Limiting     = $c.LimitToCollectionName
        }
    }
    Write-EPProgress 100 'Done'
    Write-EPLog "$($found.Count) device collection(s) match '$Search' on site $($sms.SiteCode)." -Level ok
    if (-not $rows) { return "No device collection matches '$Search'." }
    $rows
}
finally { Remove-CimSession $sms.Session -ErrorAction SilentlyContinue }
