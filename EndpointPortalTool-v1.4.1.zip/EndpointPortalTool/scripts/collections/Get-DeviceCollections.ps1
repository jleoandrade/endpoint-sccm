<#
.SYNOPSIS  Lists the ConfigMgr device collections the device is a member of.
.NOTES     Endpoint Portal Tool 1.4.0 - console not required
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
$name = $ComputerName.Split('.')[0].ToUpper()
if ($name -notmatch '^[A-Z0-9][A-Z0-9\-_]{0,62}$') { throw "Invalid computer name: $name" }

Write-EPProgress 10 'Connecting to the SMS Provider'
$sms = Connect-EPSmsProvider
try {
    Write-EPProgress 35 "Finding $name in ConfigMgr"
    $dev = @(Get-CimInstance -CimSession $sms.Session -Namespace $sms.Namespace -ClassName SMS_R_System -Filter "Name='$name'" -Property ResourceId, Name, Client, Obsolete |
        Where-Object { $_.Obsolete -ne 1 } | Sort-Object { -[int]$_.Client }) | Select-Object -First 1
    if (-not $dev) { throw "$name was not found in ConfigMgr (site $($sms.SiteCode))." }

    Write-EPProgress 60 'Reading collection membership'
    $members = @(Get-CimInstance -CimSession $sms.Session -Namespace $sms.Namespace -ClassName SMS_FullCollectionMembership -Filter "ResourceID=$($dev.ResourceId)")
    $byId = @{}
    foreach ($m in $members) { $byId[$m.CollectionID] = $m }
    $rows = foreach ($id in $byId.Keys) {
        $c = Get-CimInstance -CimSession $sms.Session -Namespace $sms.Namespace -ClassName SMS_Collection -Filter "CollectionID='$id'"
        if (-not $c) { continue }
        [pscustomobject]@{
            Name         = $c.Name
            CollectionID = $id
            Member       = if ($byId[$id].IsDirect) { 'Direct rule' } else { 'Query / include rule' }
            Members      = $c.MemberCount
            BuiltIn      = $id -like 'SMS*'
            Computer     = $name
        }
    }
    Write-EPProgress 100 'Done'
    Write-EPLog "$name (ResourceID $($dev.ResourceId)) is in $(@($rows).Count) collection(s)." -Level ok
    $rows | Sort-Object BuiltIn, Name | Select-Object Name, CollectionID, Member, Members, Computer
}
finally { Remove-CimSession $sms.Session -ErrorAction SilentlyContinue }
