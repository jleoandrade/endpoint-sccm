<#
.SYNOPSIS  Full (deep) machine cleanup, based on the team's full cleanup script.
.DESCRIPTION
    Temp folders (Windows, user profiles, system), Prefetch, Windows Update and CBS logs, .tmp files,
    print spooler, ConfigMgr cache and folders, Windows Error Reporting, full Windows Update reset
    (SoftwareDistribution and catroot2), WinSxS component cleanup (DISM) and a Windows Update health check.

    Differences from the original script:
    - Folders that must keep their NTFS permissions (Windows\Temp, Prefetch, spool\PRINTERS, profile Temp)
      are emptied instead of deleted and recreated.
    - The ConfigMgr cache is cleared through the agent API first, so the client cache index stays valid.
    - Each step runs separately so the portal shows real progress; a failed step is reported and the
      cleanup continues.
.NOTES     Endpoint Portal Tool 1.3.0 - requires WinRM
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [ValidateSet('Yes', 'No')][string]$DeleteAgentLogs = 'Yes',
    [ValidateSet('Yes', 'No')][string]$RunDism = 'Yes'
)
$ErrorActionPreference = 'Stop'

# ---- Connectivity check
Write-EPProgress 1 'Testing connectivity'
$ping = $false
try { $ping = Test-Connection -ComputerName $ComputerName -Count 2 -Quiet -ErrorAction Stop } catch {}
if ($ping) { Write-EPLog 'Ping OK.' -Level debug }
else { Write-EPLog 'No ping reply (ICMP may be blocked by a firewall); checking WinRM.' -Level warn }
try { $null = Test-WSMan -ComputerName $ComputerName -ErrorAction Stop }
catch { throw "WinRM is not reachable on $ComputerName. Use 'Repair > Enable remote WinRM' and try again." }

try { $ps = New-PSSession -ComputerName $ComputerName -ErrorAction Stop }
catch { throw "Could not open a remote session on $ComputerName. Detail: $($_.Exception.Message)" }
Write-EPLog 'Connectivity OK.' -Level ok

# ---- Helpers defined once inside the remote session
Invoke-Command -Session $ps -ScriptBlock {
    function global:Remove-Tree([string]$Path) {
        if (Test-Path -LiteralPath $Path) { cmd.exe /c "rmdir /s /q `"$Path`"" 2>$null }
    }
    function global:Clear-Folder([string]$Path) {
        if (-not (Test-Path -LiteralPath $Path)) { return }
        Get-ChildItem -LiteralPath $Path -Force -Directory -ErrorAction SilentlyContinue |
            ForEach-Object { cmd.exe /c "rmdir /s /q `"$($_.FullName)`"" 2>$null }
        cmd.exe /c "del /f /q /a `"$Path\*`"" 2>$null
    }
    function global:Get-ProfileDirs { Get-ChildItem "$env:SystemDrive\Users" -Directory -Force -ErrorAction SilentlyContinue }
}

$free = { (Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$env:SystemDrive'").FreeSpace }

# ---- Steps: progress %, name, remote script block (return a short detail string or nothing)
$steps = [System.Collections.Generic.List[object]]::new()
$steps.Add(@{ P = 5;  N = 'Windows Temp'; S = { Clear-Folder "$env:windir\Temp" } })
$steps.Add(@{ P = 10; N = 'User TEMP folders'; S = {
    $n = 0; foreach ($u in Get-ProfileDirs) { $t = Join-Path $u.FullName 'AppData\Local\Temp'; if (Test-Path $t) { Clear-Folder $t; $n++ } }
    "$n profile(s)" } })
$steps.Add(@{ P = 14; N = 'SYSTEM TEMP'; S = {
    foreach ($t in "$env:windir\SystemTemp", $env:TEMP) { if ($t) { Clear-Folder $t } } } })
$steps.Add(@{ P = 18; N = 'Prefetch'; S = { Clear-Folder "$env:windir\Prefetch" } })
$steps.Add(@{ P = 21; N = 'Windows Update logs'; S = {
    Remove-Item "$env:windir\WindowsUpdate.log", "$env:windir\SoftwareDistribution\ReportingEvents.log" -Force -ErrorAction SilentlyContinue } })
$steps.Add(@{ P = 24; N = 'CBS logs'; S = {
    Remove-Item "$env:windir\Logs\CBS\*.log", "$env:windir\Logs\CBS\*.cab" -Force -ErrorAction SilentlyContinue } })
$steps.Add(@{ P = 30; N = '.TMP files (safe locations only)'; S = {
    $paths = @("$env:windir\Temp", "$env:ProgramData\Temp", "$env:windir\CCM\Temp", "$env:windir\ccmcache")
    foreach ($u in Get-ProfileDirs) { $paths += Join-Path $u.FullName 'AppData\Local\Temp' }
    $n = 0
    foreach ($p in $paths) {
        if (Test-Path $p) {
            Get-ChildItem -Path $p -Recurse -Force -Include *.tmp -File -ErrorAction SilentlyContinue |
                ForEach-Object { try { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction Stop; $n++ } catch {} }
        }
    }
    "$n file(s)" } })
$steps.Add(@{ P = 36; N = 'Print Spooler'; S = {
    Stop-Service Spooler -Force -ErrorAction SilentlyContinue
    Clear-Folder "$env:windir\System32\spool\PRINTERS"
    Start-Service Spooler -ErrorAction SilentlyContinue
    "Spooler $((Get-Service Spooler).Status)" } })
$steps.Add(@{ P = 44; N = 'SCCM cache and folders'; A = @($DeleteAgentLogs -eq 'Yes'); S = {
    param($deleteLogs)
    $removed = 0; $location = "$env:windir\ccmcache"
    try {
        $cache = (New-Object -ComObject UIResource.UIResourceMgr).GetCacheInfo()
        if ($cache.Location) { $location = $cache.Location }
        foreach ($e in @($cache.GetCacheElements())) { try { $cache.DeleteCacheElementEx($e.CacheElementID, $true); $removed++ } catch {} }
    } catch {}
    Clear-Folder $location
    if ($location -ne "$env:windir\ccmcache") { Clear-Folder "$env:windir\ccmcache" }
    Clear-Folder "$env:windir\CCM\Temp"
    Clear-Folder "$env:windir\CCM\Cache"
    Remove-Item "$env:windir\CCM\*.tmp" -Force -ErrorAction SilentlyContinue
    if ($deleteLogs) {
        Remove-Item "$env:windir\CCM\Logs\*.log", "$env:windir\CCMSetup\*.log", "$env:windir\CCMSetup\Logs\*.log" -Force -ErrorAction SilentlyContinue
    }
    "$removed cache item(s) removed through the agent API" + $(if ($deleteLogs) { '; agent logs deleted' } else { '' }) } })
$steps.Add(@{ P = 50; N = 'Windows Error Reporting (WER)'; S = {
    foreach ($d in 'ReportQueue', 'ReportArchive', 'Temp') { Remove-Tree "$env:ProgramData\Microsoft\Windows\WER\$d" }
    foreach ($u in Get-ProfileDirs) { Remove-Tree (Join-Path $u.FullName 'AppData\Local\Microsoft\Windows\WER') } } })
$steps.Add(@{ P = 58; N = 'Windows Update reset (SoftwareDistribution, catroot2)'; S = {
    $svcs = 'wuauserv', 'bits', 'cryptsvc', 'msiserver'
    foreach ($s in $svcs) { Stop-Service $s -Force -ErrorAction SilentlyContinue }
    Remove-Tree "$env:windir\SoftwareDistribution"
    Remove-Tree "$env:windir\System32\catroot2"
    foreach ($s in $svcs) { Start-Service $s -ErrorAction SilentlyContinue }
    Start-Sleep -Seconds 3
    $left = @("$env:windir\SoftwareDistribution\Download", "$env:windir\System32\catroot2\edb.log") | Where-Object { Test-Path $_ }
    (@($svcs | ForEach-Object { "$_ $((Get-Service $_ -ErrorAction SilentlyContinue).Status)" }) -join ', ') +
        $(if ($left) { ' (some files were in use and could not be removed)' } else { '' }) } })
if ($RunDism -eq 'Yes') {
    $steps.Add(@{ P = 66; N = 'WinSxS component cleanup (DISM) - can take 10+ minutes'; Key = 'dism'; S = {
        $null = & Dism.exe /Online /Cleanup-Image /StartComponentCleanup /NoRestart
        "exit code $LASTEXITCODE" } })
}
$steps.Add(@{ P = 94; N = 'Verifying Windows Update (can take a few minutes)'; Key = 'verify'; S = {
    $sd = Test-Path "$env:windir\SoftwareDistribution"
    $job = Start-Job -ScriptBlock {
        $session = New-Object -ComObject Microsoft.Update.Session
        $null = $session.CreateUpdateSearcher().Search('IsInstalled=0')
        'OK'
    }
    $wu = if (Wait-Job $job -Timeout 300) { try { Receive-Job $job -ErrorAction Stop } catch { "FAIL: $($_.Exception.Message)" } } else { Stop-Job $job; 'TIMEOUT' }
    Remove-Job $job -Force -ErrorAction SilentlyContinue
    [pscustomobject]@{ SoftwareDistribution = $sd; WindowsUpdate = [string]$wu } } })

# ---- Run
$warnings = 0; $dism = 'Skipped'; $verify = $null
try {
    $remoteName = Invoke-Command -Session $ps -ScriptBlock { $env:COMPUTERNAME }
    $before = Invoke-Command -Session $ps -ScriptBlock $free
    foreach ($st in $steps) {
        Write-EPProgress $st.P $st.N
        try {
            $out = Invoke-Command -Session $ps -ScriptBlock $st.S -ArgumentList @($st.A) -ErrorAction Stop
            $level = 'ok'
            if ($st.Key -eq 'dism') {
                $dism = "Completed ($out)"
                if ("$out" -ne 'exit code 0') { $warnings++; $level = 'warn' }
            }
            if ($st.Key -eq 'verify') { $verify = $out }
            else {
                $detail = if ($out -is [string] -and $out) { ": $out" } else { '' }
                Write-EPLog "$($st.N)$detail" -Level $level
            }
        } catch {
            $warnings++
            if ($st.Key -eq 'dism') { $dism = "Failed: $($_.Exception.Message)" }
            Write-EPLog "$($st.N): $($_.Exception.Message)" -Level warn
        }
    }
    $after = Invoke-Command -Session $ps -ScriptBlock $free

    $sdOk = $verify -and $verify.SoftwareDistribution
    $wuOk = $verify -and $verify.WindowsUpdate -eq 'OK'
    Write-EPLog ("SoftwareDistribution recreated: {0} - Windows Update healthy: {1}" -f $(if ($sdOk) { 'yes' } else { 'no' }), $(if ($wuOk) { 'yes' } else { "no ($($verify.WindowsUpdate))" })) -Level $(if ($sdOk -and $wuOk) { 'ok' } else { 'warn' })
    Write-EPProgress 100 'Done'
    Write-EPLog ("Full cleanup finished. Free space: {0} -> {1} (+{2})" -f (Format-EPSize $before), (Format-EPSize $after), (Format-EPSize ([Math]::Max(0, $after - $before)))) -Level ok

    [pscustomobject]@{
        'Computer'                       = $remoteName
        'Result'                         = if ($warnings) { "Completed with $warnings warning(s) - see Activity Log" } else { 'Completed' }
        'SoftwareDistribution recreated' = if ($sdOk) { 'Recreated' } else { 'Missing' }
        'Windows Update health'          = if ($wuOk) { 'Healthy (update search OK)' } elseif ($verify) { "Not healthy ($($verify.WindowsUpdate))" } else { 'Not checked' }
        'DISM component cleanup'         = $dism
        'Agent logs deleted'             = $DeleteAgentLogs
        'Free before'                    = Format-EPSize $before
        'Free after'                     = Format-EPSize $after
        'Space gained'                   = Format-EPSize ([Math]::Max(0, $after - $before))
    }
}
finally { Remove-PSSession $ps -ErrorAction SilentlyContinue }
