<#
.SYNOPSIS
    Endpoint Portal Tool - local web server.

.DESCRIPTION
    Starts an HTTP server bound to localhost only (nothing to install), opens the browser
    and runs every button of the interface as a .ps1 file from the .\scripts folder.
    Only scripts registered in scripts\manifest.json can be executed.

.PARAMETER Port
    Local HTTP port. Default: value from config.json (8790).

.PARAMETER NoBrowser
    Do not open the browser automatically.

.EXAMPLE
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Start-EndpointPortal.ps1
#>
[CmdletBinding()]
param(
    [int]$Port = 0,
    [switch]$NoBrowser
)

$ErrorActionPreference = 'Stop'
$Root      = $PSScriptRoot
$WebRoot   = Join-Path $Root 'web'
$ScriptDir = Join-Path $Root 'scripts'
$LogDir    = Join-Path $Root 'logs'
$Version   = (Get-Content (Join-Path $Root 'VERSION') -Raw).Trim()
$Config    = Get-Content (Join-Path $Root 'config.json') -Raw | ConvertFrom-Json
if (-not $Port) { $Port = [int]$Config.Port }
$IsWin     = [Environment]::OSVersion.Platform -eq 'Win32NT'

if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Path $LogDir | Out-Null }

# Files downloaded from the internet are tagged (Zone.Identifier): unblock the tool folder.
if ($IsWin) {
    try { Get-ChildItem $Root -Recurse -File | Unblock-File -ErrorAction SilentlyContinue } catch {}
}

try { $Host.UI.RawUI.WindowTitle = "Endpoint Portal Tool v$Version" } catch {}
Write-Host ''
Write-Host "  Endpoint Portal Tool v$Version" -ForegroundColor Magenta
Write-Host "  Operator: $([Environment]::UserDomainName)\$([Environment]::UserName)" -ForegroundColor Gray

# -----------------------------------------------------------------------------------------
# Runspace pool: every button runs in parallel without blocking the server
# -----------------------------------------------------------------------------------------
$Iss = [System.Management.Automation.Runspaces.InitialSessionState]::CreateDefault()
if ($IsWin) {
    try { $Iss.ExecutionPolicy = [Microsoft.PowerShell.ExecutionPolicy]::Bypass } catch {}
}
$Iss.ImportPSModule(@((Join-Path (Join-Path $Root 'core') 'EndpointPortal.psm1')))
$MaxJobs = [Math]::Max(2, [int]$Config.MaxConcurrentJobs)
$Pool = [runspacefactory]::CreateRunspacePool($Iss)
[void]$Pool.SetMaxRunspaces($MaxJobs)
$Pool.Open()

$Jobs   = @{}
$Token  = [guid]::NewGuid().ToString('N')
$script:StopServer = $false
$TargetPattern = '^[A-Za-z0-9][A-Za-z0-9\.\-_]{0,253}$'

# -----------------------------------------------------------------------------------------
# HTTP helpers
# -----------------------------------------------------------------------------------------
function ConvertTo-EPJsonText($Object) {
    ConvertTo-Json -InputObject $Object -Depth 8 -Compress
}

function Send-Bytes($Ctx, [int]$Status, [byte[]]$Bytes, [string]$ContentType) {
    $r = $Ctx.Response
    $r.StatusCode = $Status
    $r.ContentType = $ContentType
    $r.AddHeader('Cache-Control', 'no-store')
    $r.AddHeader('X-Content-Type-Options', 'nosniff')
    $r.AddHeader('X-Frame-Options', 'DENY')
    $r.ContentLength64 = $Bytes.Length
    $r.OutputStream.Write($Bytes, 0, $Bytes.Length)
    $r.OutputStream.Close()
}

function Send-Json($Ctx, [int]$Status, $Object) {
    $bytes = [Text.Encoding]::UTF8.GetBytes((ConvertTo-EPJsonText $Object))
    Send-Bytes $Ctx $Status $bytes 'application/json; charset=utf-8'
}

function Read-Body($Ctx) {
    if ($Ctx.Request.ContentLength64 -gt 65536) { throw 'Request too large.' }
    $sr = New-Object IO.StreamReader($Ctx.Request.InputStream, [Text.Encoding]::UTF8)
    try { $text = $sr.ReadToEnd() } finally { $sr.Dispose() }
    if ([string]::IsNullOrWhiteSpace($text)) { return $null }
    return $text | ConvertFrom-Json
}

$MimeTypes = @{
    '.html' = 'text/html; charset=utf-8'; '.js' = 'application/javascript; charset=utf-8'
    '.css'  = 'text/css; charset=utf-8';  '.svg' = 'image/svg+xml'; '.png' = 'image/png'
    '.ico'  = 'image/x-icon';             '.json' = 'application/json; charset=utf-8'
}

function Send-Static($Ctx, [string]$UrlPath) {
    if ($UrlPath -eq '/' -or $UrlPath -eq '') { $UrlPath = '/index.html' }
    $rel  = $UrlPath.TrimStart('/') -replace '/', [IO.Path]::DirectorySeparatorChar
    $full = [IO.Path]::GetFullPath((Join-Path $WebRoot $rel))
    $base = [IO.Path]::GetFullPath($WebRoot)
    if (-not $full.StartsWith($base, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path $full -PathType Leaf)) {
        Send-Json $Ctx 404 @{ error = 'Not found' }; return
    }
    $ext  = [IO.Path]::GetExtension($full).ToLower()
    $type = $MimeTypes[$ext]; if (-not $type) { $type = 'application/octet-stream' }
    Send-Bytes $Ctx 200 ([IO.File]::ReadAllBytes($full)) $type
}

# -----------------------------------------------------------------------------------------
# Manifest and script execution
# -----------------------------------------------------------------------------------------
function Get-Manifest {
    Get-Content (Join-Path $ScriptDir 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Get-ManifestAction($Manifest, [string]$Id) {
    $p = $Manifest.actions.PSObject.Properties[$Id]
    if ($p) { return $p.Value }
    return $null
}

function Write-Audit([string]$Target, [string]$ActionId, [string]$State, [string]$Detail) {
    try {
        $file = Join-Path $LogDir ('audit-{0}.csv' -f (Get-Date -Format 'yyyy-MM'))
        $line = '"{0}","{1}\{2}","{3}","{4}","{5}","{6}"' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'),
            [Environment]::UserDomainName, [Environment]::UserName, $Target, $ActionId, $State, (($Detail -replace '"', "'") -replace '\s*[\r\n]+\s*', ' ')
        if (-not (Test-Path $file)) { Add-Content -Path $file -Value '"Date","Operator","Computer","Action","State","Detail"' -Encoding UTF8 }
        Add-Content -Path $file -Value $line -Encoding UTF8
    } catch {}
}

function Start-EPJob($Request) {
    $manifest = Get-Manifest
    $actionId = [string]$Request.action
    $action   = Get-ManifestAction $manifest $actionId
    if (-not $action) { throw "Unknown action: $actionId" }

    $target = ([string]$Request.target).Trim()
    if ($target -notmatch $TargetPattern) { throw 'Invalid computer name.' }

    $scriptPath = [IO.Path]::GetFullPath((Join-Path $ScriptDir ($action.script -replace '/', [IO.Path]::DirectorySeparatorChar)))
    if (-not $scriptPath.StartsWith([IO.Path]::GetFullPath($ScriptDir), [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path $scriptPath)) {
        throw "Script not found: $($action.script)"
    }

    # Parameters: ComputerName + inputs declared in the manifest + fixed args (args always win)
    $params = [ordered]@{ ComputerName = $target }
    $declared = @{}
    foreach ($inp in @($action.inputs)) { if ($inp) { $declared[$inp.name] = $inp } }
    if ($Request.inputs) {
        foreach ($p in $Request.inputs.PSObject.Properties) {
            $def = $declared[$p.Name]
            if (-not $def) { throw "Parameter not allowed: $($p.Name)" }
            $val = $p.Value
            if ($val -is [string] -and $val.Length -gt 2000) { throw "Value too long: $($p.Name)" }
            if ($def.type -eq 'select' -and @($def.options | ForEach-Object { if ($_.value) { $_.value } else { $_ } }) -notcontains $val) {
                throw "Invalid value for $($p.Name)"
            }
            if ($null -ne $val -and "$val" -ne '') { $params[$p.Name] = $val }
        }
    }
    foreach ($inp in $declared.Values) {
        if ($inp.required -and -not $params.Contains($inp.name)) { throw "Required field: $($inp.label)" }
    }
    if ($action.args) { foreach ($p in $action.args.PSObject.Properties) { $params[$p.Name] = $p.Value } }

    $ps = [powershell]::Create()
    $ps.RunspacePool = $Pool
    [void]$ps.AddCommand($scriptPath)
    foreach ($k in $params.Keys) { [void]$ps.AddParameter($k, $params[$k]) }

    $id = [guid]::NewGuid().ToString('N').Substring(0, 12)
    $job = @{
        Id = $id; Action = $actionId; Label = [string]$action.label; Target = $target; Sensitive = [bool]$action.sensitive
        PS = $ps; Handle = $ps.BeginInvoke(); Started = Get-Date; Finished = $null
        Log = New-Object System.Collections.Generic.List[object]
        Idx = @{ Information = 0; Warning = 0; Error = 0; Verbose = 0 }
        State = 'Running'; Result = $null; Percent = -1; Status = ''; Fetched = $null
    }
    $Jobs[$id] = $job
    Write-Host ("  [{0}] {1} -> {2}" -f (Get-Date -Format 'HH:mm:ss'), $actionId, $target) -ForegroundColor DarkGray
    return $job
}

function Add-JobLog($Job, [string]$Level, [string]$Message) {
    if ([string]::IsNullOrWhiteSpace($Message)) { return }
    $Job.Log.Add(@{ t = (Get-Date -Format 'HH:mm:ss'); level = $Level; msg = $Message })
}

function Sync-JobStreams($Job) {
    $s = $Job.PS.Streams
    while ($Job.Idx.Information -lt $s.Information.Count) {
        $rec = $s.Information[$Job.Idx.Information]; $Job.Idx.Information++
        $md = $rec.MessageData
        if ($md -is [hashtable] -or ($md -and $md.PSObject.Properties['level'] -and $md.PSObject.Properties['msg'])) {
            Add-JobLog $Job ([string]$md.level) ([string]$md.msg)
        } else { Add-JobLog $Job 'info' ([string]$md) }
    }
    while ($Job.Idx.Warning -lt $s.Warning.Count) {
        Add-JobLog $Job 'warn' $s.Warning[$Job.Idx.Warning].Message; $Job.Idx.Warning++
    }
    while ($Job.Idx.Verbose -lt $s.Verbose.Count) {
        Add-JobLog $Job 'debug' $s.Verbose[$Job.Idx.Verbose].Message; $Job.Idx.Verbose++
    }
    while ($Job.Idx.Error -lt $s.Error.Count) {
        Add-JobLog $Job 'error' $s.Error[$Job.Idx.Error].Exception.Message; $Job.Idx.Error++
    }
    if ($s.Progress.Count -gt 0) {
        $p = $s.Progress[$s.Progress.Count - 1]
        if ($p.PercentComplete -ge 0) { $Job.Percent = $p.PercentComplete }
        $Job.Status = if ($p.StatusDescription -and $p.StatusDescription -ne 'Processing') { $p.StatusDescription } else { $p.Activity }
        $s.Progress.Clear()
    }
}

function ConvertTo-PlainResult($Output) {
    $items = New-Object System.Collections.Generic.List[object]
    foreach ($o in $Output) {
        if ($null -eq $o) { continue }
        $b = $o
        if ($o -is [psobject]) { $b = $o.BaseObject }
        if ($b -is [string] -or $b -is [ValueType]) { $items.Add([string]$b) } else { $items.Add($o) }
    }
    return ,$items
}

function Complete-JobIfDone($Job) {
    if ($Job.State -ne 'Running' -or -not $Job.Handle.IsCompleted) { return }
    $failed = $false
    try {
        $out = $Job.PS.EndInvoke($Job.Handle)
        $Job.Result = ConvertTo-PlainResult $out
    } catch {
        $failed = $true
        $ex = $_.Exception
        while ($ex.InnerException) { $ex = $ex.InnerException }
        Sync-JobStreams $Job
        Add-JobLog $Job 'error' $ex.Message
    }
    Sync-JobStreams $Job
    if ($Job.PS.InvocationStateInfo.State -eq 'Stopped') { $Job.State = 'Cancelled' }
    elseif ($failed -or ($Job.PS.HadErrors -and $Job.Result.Count -eq 0)) { $Job.State = 'Failed' }
    else { $Job.State = 'Completed' }
    if ($Job.State -eq 'Completed') { $Job.Percent = 100 }
    $Job.Finished = Get-Date
    $last = ($Job.Log | Where-Object { $_.level -eq 'error' } | Select-Object -Last 1)
    $detail = if ($last) { $last.msg } elseif ($Job.Sensitive -and $Job.State -eq 'Completed') { 'Sensitive value retrieved (value not logged)' } else { '' }
    Write-Audit $Job.Target $Job.Action $Job.State $detail
    $Job.PS.Dispose()
}

function Get-JobSnapshot($Job, [int]$From) {
    if ($Job.State -eq 'Running') { Sync-JobStreams $Job; Complete-JobIfDone $Job }
    if ($From -lt 0) { $From = 0 }
    $logs = @()
    if ($From -lt $Job.Log.Count) { $logs = $Job.Log.GetRange($From, $Job.Log.Count - $From).ToArray() }
    $snap = @{
        id = $Job.Id; action = $Job.Action; label = $Job.Label; target = $Job.Target
        state = $Job.State; percent = $Job.Percent; status = $Job.Status
        logs = $logs; next = $Job.Log.Count
        elapsed = [int]((Get-Date) - $Job.Started).TotalSeconds
    }
    if ($Job.State -ne 'Running') {
        $snap.result = @{ items = $Job.Result }; $Job.Fetched = Get-Date
        # Secrets (e.g. LAPS) are handed over once and not kept in server memory
        if ($Job.Sensitive) { $Job.Result = $null }
    }
    return $snap
}

function Remove-OldJobs {
    foreach ($k in @($Jobs.Keys)) {
        $j = $Jobs[$k]
        if (-not $j.Finished) { continue }
        $limit = if ($j.Sensitive) { 5 } elseif ($j.Fetched) { 15 } else { 30 }
        if (((Get-Date) - $j.Finished).TotalMinutes -gt $limit) { $Jobs.Remove($k) }
    }
}

# -----------------------------------------------------------------------------------------
# Router
# -----------------------------------------------------------------------------------------
function Invoke-Route($Ctx) {
    $req  = $Ctx.Request
    $path = $req.Url.AbsolutePath

    # DNS rebinding protection: only accept a localhost Host header
    $hostHeader = ([string]$req.Headers['Host']).ToLower()
    if ($hostHeader -ne "localhost:$Port" -and $hostHeader -ne "127.0.0.1:$Port") {
        Send-Json $Ctx 403 @{ error = 'Host not allowed' }; return
    }

    if (-not $path.StartsWith('/api/')) {
        if ($req.HttpMethod -ne 'GET') { Send-Json $Ctx 405 @{ error = 'Invalid method' }; return }
        Send-Static $Ctx $path; return
    }

    # The API requires the session token in a header (browsers do not send custom headers cross-site)
    if ($req.Headers['X-EP-Token'] -ne $Token) { Send-Json $Ctx 401 @{ error = 'Invalid session. Reopen the tool from Start-EndpointPortal.cmd.' }; return }

    switch ("$($req.HttpMethod) $path") {
        'GET /api/info' {
            Send-Json $Ctx 200 @{
                name = 'Endpoint Portal Tool'; version = $Version
                operator = "$([Environment]::UserDomainName)\$([Environment]::UserName)"
                station = [Environment]::MachineName; psVersion = $PSVersionTable.PSVersion.ToString()
            }
        }
        'GET /api/manifest' {
            $m = Get-Manifest
            foreach ($p in $m.actions.PSObject.Properties) { $p.Value.PSObject.Properties.Remove('args') }
            Send-Json $Ctx 200 $m
        }
        'POST /api/run' {
            $body = Read-Body $Ctx
            try { $job = Start-EPJob $body; Send-Json $Ctx 200 @{ jobId = $job.Id } }
            catch { Send-Json $Ctx 400 @{ error = $_.Exception.Message } }
        }
        'GET /api/job' {
            $job = $Jobs[[string]$req.QueryString['id']]
            if (-not $job) { Send-Json $Ctx 404 @{ error = 'Job not found' }; return }
            Send-Json $Ctx 200 (Get-JobSnapshot $job ([int]$req.QueryString['from']))
        }
        'POST /api/job/cancel' {
            $job = $Jobs[[string]$req.QueryString['id']]
            if ($job -and $job.State -eq 'Running') { [void]$job.PS.BeginStop($null, $null) }
            Send-Json $Ctx 200 @{ ok = $true }
        }
        'POST /api/shutdown' {
            Send-Json $Ctx 200 @{ ok = $true }
            $script:StopServer = $true
        }
        default { Send-Json $Ctx 404 @{ error = 'Unknown route' } }
    }
}

# -----------------------------------------------------------------------------------------
# Listener startup (finds a free port)
# -----------------------------------------------------------------------------------------
$Listener = $null
for ($try = 0; $try -lt 10; $try++) {
    $candidate = New-Object System.Net.HttpListener
    $candidate.Prefixes.Add("http://localhost:$Port/")
    try { $candidate.Start(); $Listener = $candidate; break }
    catch { $candidate.Close(); $Port++ }
}
if (-not $Listener) { throw 'Could not open a local port (8790-8799 are in use).' }

$Url = "http://localhost:$Port/#t=$Token"
Write-Host "  Portal: http://localhost:$Port/" -ForegroundColor Green
Write-Host '  Close this window (or use the Shut down button in the portal) to stop.' -ForegroundColor Gray
Write-Host ''

if (-not $NoBrowser) {
    $opened = $false
    if ($IsWin -and $Config.BrowserMode -eq 'app') {
        try { Start-Process 'msedge.exe' -ArgumentList "--app=$Url", '--window-size=1400,900'; $opened = $true } catch {}
    }
    if (-not $opened) { try { Start-Process $Url } catch { Write-Host "  Open in your browser: $Url" -ForegroundColor Yellow } }
} else {
    Write-Host "  Session URL: $Url" -ForegroundColor Yellow
}

try {
    while ($Listener.IsListening -and -not $script:StopServer) {
        $task = $Listener.GetContextAsync()
        while (-not $task.AsyncWaitHandle.WaitOne(250)) {
            if ($script:StopServer) { break }
        }
        if ($script:StopServer -and -not $task.IsCompleted) { break }
        $ctx = $task.GetAwaiter().GetResult()
        try { Invoke-Route $ctx }
        catch {
            try { Send-Json $ctx 500 @{ error = $_.Exception.Message } } catch {}
        }
        Remove-OldJobs
    }
}
finally {
    Write-Host '  Shutting down...' -ForegroundColor Gray
    foreach ($j in $Jobs.Values) { if ($j.State -eq 'Running') { try { $j.PS.Stop() } catch {} } }
    $Listener.Stop(); $Listener.Close()
    $Pool.Close(); $Pool.Dispose()
}
