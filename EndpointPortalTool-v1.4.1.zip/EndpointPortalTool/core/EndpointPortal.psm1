<#
    Endpoint Portal Tool - shared functions used by the scripts in the .\scripts folder.
    Loaded automatically by the server for every execution.
#>

$script:Config = $null
try { $script:Config = Get-Content (Join-Path (Split-Path $PSScriptRoot -Parent) 'config.json') -Raw | ConvertFrom-Json } catch {}
$script:CimTimeout = 15
if ($script:Config -and $script:Config.CimTimeoutSeconds) { $script:CimTimeout = [int]$script:Config.CimTimeoutSeconds }

function Write-EPLog {
    <# Sends a line to the portal terminal. Level: info | ok | warn | error | debug #>
    param(
        [Parameter(Mandatory, Position = 0)][string]$Message,
        [ValidateSet('info', 'ok', 'warn', 'error', 'debug')][string]$Level = 'info'
    )
    Write-Information -MessageData @{ level = $Level; msg = $Message } -InformationAction Continue
}

function Write-EPProgress {
    <# Updates the job progress bar in the portal. #>
    param([Parameter(Mandatory)][int]$Percent, [string]$Status = '')
    if (-not $Status) { $Status = "$Percent%" }
    Write-Progress -Activity 'EndpointPortal' -Status $Status -PercentComplete ([Math]::Min(100, [Math]::Max(0, $Percent)))
}

function New-EPCimSession {
    <# Opens a CIM session: tries WinRM (WSMan) and falls back to DCOM/RPC when WinRM is blocked. #>
    param([Parameter(Mandatory)][string]$ComputerName)
    try {
        $s = New-CimSession -ComputerName $ComputerName -SessionOption (New-CimSessionOption -Protocol Wsman) -OperationTimeoutSec $script:CimTimeout -ErrorAction Stop
        $null = Get-CimInstance -CimSession $s -ClassName Win32_OperatingSystem -Property Caption -ErrorAction Stop
        Write-EPLog "CIM session over WinRM (WSMan) opened with $ComputerName" -Level debug
        return $s
    } catch {
        Write-EPLog "WinRM unavailable on $ComputerName ($($_.Exception.Message.Split([Environment]::NewLine)[0])). Trying DCOM..." -Level debug
    }
    try {
        $s = New-CimSession -ComputerName $ComputerName -SessionOption (New-CimSessionOption -Protocol Dcom) -OperationTimeoutSec $script:CimTimeout -ErrorAction Stop
        $null = Get-CimInstance -CimSession $s -ClassName Win32_OperatingSystem -Property Caption -ErrorAction Stop
        Write-EPLog "CIM session over DCOM opened with $ComputerName" -Level debug
        return $s
    } catch {
        throw "Could not connect to $ComputerName over WinRM or DCOM. Check that the computer is powered on, on the network, and that you have administrator rights on it. Detail: $($_.Exception.Message)"
    }
}

function Invoke-EPCim {
    <# Runs a block with an open CIM session and always closes it. #>
    param([Parameter(Mandatory)][string]$ComputerName, [Parameter(Mandatory)][scriptblock]$ScriptBlock)
    $session = New-EPCimSession -ComputerName $ComputerName
    try { & $ScriptBlock $session } finally { Remove-CimSession $session -ErrorAction SilentlyContinue }
}

function Invoke-EPRemote {
    <# Runs commands on the endpoint over WinRM (Invoke-Command) with a clear error message. #>
    param(
        [Parameter(Mandatory)][string]$ComputerName,
        [Parameter(Mandatory)][scriptblock]$ScriptBlock,
        [object[]]$ArgumentList = @(),
        $Session
    )
    try {
        if ($Session) { return Invoke-Command -Session $Session -ScriptBlock $ScriptBlock -ArgumentList $ArgumentList -ErrorAction Stop }
        return Invoke-Command -ComputerName $ComputerName -ScriptBlock $ScriptBlock -ArgumentList $ArgumentList -ErrorAction Stop
    } catch [System.Management.Automation.Remoting.PSRemotingTransportException] {
        throw "WinRM did not respond on $ComputerName. Use 'Repair > Enable remote WinRM' and try again. Detail: $($_.Exception.Message)"
    }
}

function Invoke-EPSchedule {
    <# Triggers a ConfigMgr agent action (SMS_Client.TriggerSchedule). #>
    param([Parameter(Mandatory)]$CimSession, [Parameter(Mandatory)][string]$ScheduleId)
    $r = Invoke-CimMethod -CimSession $CimSession -Namespace 'root\ccm' -ClassName 'SMS_Client' -MethodName 'TriggerSchedule' -Arguments @{ sScheduleID = $ScheduleId } -ErrorAction Stop
    if ($r -and $null -ne $r.ReturnValue -and $r.ReturnValue -ne 0) { throw "TriggerSchedule returned $($r.ReturnValue)" }
}

function Test-EPCcmClient {
    <# Checks whether the ConfigMgr agent exists on the endpoint. #>
    param([Parameter(Mandatory)]$CimSession)
    try {
        $null = Get-CimInstance -CimSession $CimSession -Namespace 'root\ccm' -ClassName 'SMS_Client' -ErrorAction Stop
        return $true
    } catch { return $false }
}

function Assert-EPCcmClient {
    param([Parameter(Mandatory)]$CimSession)
    if (-not (Test-EPCcmClient -CimSession $CimSession)) {
        throw 'ConfigMgr (SCCM/MECM) agent not found, or the root\ccm namespace is not reachable on this endpoint.'
    }
}

function Format-EPDate {
    param($Date, [string]$Format = 'yyyy-MM-dd HH:mm:ss')
    if ($null -eq $Date -or $Date -eq '') { return '-' }
    try {
        if ($Date -is [datetime]) { if ($Date.Year -lt 1990) { return '-' }; return $Date.ToString($Format) }
        if ($Date -match '^\d{14}\.\d{6}[\+\-]\d{3}$') { return ([Management.ManagementDateTimeConverter]::ToDateTime($Date)).ToString($Format) }
        return ([datetime]$Date).ToString($Format)
    } catch { return [string]$Date }
}

function Format-EPSize {
    param([double]$Bytes)
    if ($Bytes -ge 1TB) { return '{0:N1} TB' -f ($Bytes / 1TB) }
    if ($Bytes -ge 1GB) { return '{0:N1} GB' -f ($Bytes / 1GB) }
    if ($Bytes -ge 1MB) { return '{0:N1} MB' -f ($Bytes / 1MB) }
    return '{0:N0} KB' -f ($Bytes / 1KB)
}

function Get-EPRegValue {
    <# Reads a remote registry value via StdRegProv (works over WinRM and DCOM). HKLM hive. #>
    param(
        [Parameter(Mandatory)]$CimSession,
        [Parameter(Mandatory)][string]$Key,
        [Parameter(Mandatory)][string]$Name,
        [ValidateSet('String', 'DWORD', 'MultiString', 'ExpandedString')][string]$Type = 'String'
    )
    $method = "Get$($Type)Value"
    try {
        $r = Invoke-CimMethod -CimSession $CimSession -Namespace 'root\default' -ClassName 'StdRegProv' -MethodName $method `
            -Arguments @{ hDefKey = [uint32]2147483650; sSubKeyName = $Key; sValueName = $Name } -ErrorAction Stop
        if ($r.ReturnValue -ne 0) { return $null }
        switch ($Type) { 'DWORD' { return $r.uValue } 'MultiString' { return $r.sValue } default { return $r.sValue } }
    } catch { return $null }
}

function Test-EPRegKey {
    param([Parameter(Mandatory)]$CimSession, [Parameter(Mandatory)][string]$Key)
    try {
        $r = Invoke-CimMethod -CimSession $CimSession -Namespace 'root\default' -ClassName 'StdRegProv' -MethodName 'EnumKey' `
            -Arguments @{ hDefKey = [uint32]2147483650; sSubKeyName = $Key } -ErrorAction Stop
        return ($r.ReturnValue -eq 0)
    } catch { return $false }
}

function Wait-EPServiceState {
    param([Parameter(Mandatory)]$CimSession, [Parameter(Mandatory)][string]$Name, [Parameter(Mandatory)][string]$State, [int]$TimeoutSeconds = 45)
    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    do {
        $svc = Get-CimInstance -CimSession $CimSession -ClassName Win32_Service -Filter "Name='$Name'" -ErrorAction Stop
        if ($svc.State -eq $State) { return $true }
        Start-Sleep -Milliseconds 800
    } while ((Get-Date) -lt $deadline)
    return $false
}

function Resolve-EPADComputer {
    <# Finds the computer object in the forest via the Global Catalog (multi-domain).
       Returns Name, DistinguishedName, Domain (DNS) and DnsHostName. Accepts short name, FQDN or IP. #>
    param([Parameter(Mandatory)][string]$ComputerName)
    $name = $ComputerName
    if ($name -match '^\d+\.\d+\.\d+\.\d+$') {
        try { $name = [Net.Dns]::GetHostEntry($name).HostName }
        catch { throw "Could not resolve $ComputerName to a computer name. Enter the hostname instead (LAPS is looked up by name in Active Directory)." }
    }
    $short = $name.Split('.')[0]
    if ($short -notmatch '^[A-Za-z0-9\-_]{1,63}$') { throw "Invalid computer name: $short" }
    try {
        $forest = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
        $gc = New-Object System.DirectoryServices.DirectoryEntry("GC://$($forest.Name)")
        $filter = "(&(objectCategory=computer)(|(name=$short)(sAMAccountName=$short`$)))"
        $searcher = New-Object System.DirectoryServices.DirectorySearcher($gc, $filter, [string[]]@('distinguishedName', 'dNSHostName', 'name'))
        $hits = @($searcher.FindAll())
    } catch {
        throw "Active Directory is not reachable from this workstation (run the tool on a domain-joined computer with a domain account). Detail: $($_.Exception.Message)"
    }
    if (-not $hits.Count) { throw "Computer '$short' was not found in Active Directory." }
    if ($hits.Count -gt 1 -and $name -match '\.') {
        $exact = @($hits | Where-Object { [string]$_.Properties['dnshostname'][0] -eq $name })
        if ($exact.Count -eq 1) { $hits = $exact }
    }
    if ($hits.Count -gt 1) {
        $list = ($hits | ForEach-Object { [string]$_.Properties['distinguishedname'][0] }) -join '; '
        throw "More than one computer named '$short' exists in the forest ($list). Enter the full DNS name (FQDN)."
    }
    $dn = [string]$hits[0].Properties['distinguishedname'][0]
    $domain = (($dn -split ',') | Where-Object { $_ -like 'DC=*' } | ForEach-Object { $_.Substring(3) }) -join '.'
    [pscustomobject]@{
        Name              = [string]$hits[0].Properties['name'][0]
        DistinguishedName = $dn
        Domain            = $domain
        DnsHostName       = [string]$hits[0].Properties['dnshostname'][0]
    }
}

function Connect-EPSmsProvider {
    <# Connects to the ConfigMgr SMS Provider over WMI/CIM (no console or module needed).
       Site server: config.json "SccmServer" > ConfigMgr console's last server (HKCU MRU) >
       management point of this workstation's ConfigMgr client. Returns Server, SiteCode, Namespace, Session. #>
    $server = $null; $how = $null
    if ($script:Config -and $script:Config.SccmServer) { $server = [string]$script:Config.SccmServer; $how = 'config.json' }
    if (-not $server) {
        try { $server = (Get-ItemProperty 'HKCU:\Software\Microsoft\ConfigMgr10\AdminUI\MRU\1' -ErrorAction Stop).ServerName; $how = 'ConfigMgr console (last server used)' } catch {}
    }
    if (-not $server) {
        try { $server = (Get-CimInstance -Namespace 'root\ccm' -ClassName SMS_Authority -ErrorAction Stop | Select-Object -First 1).CurrentManagementPoint; $how = 'management point of this workstation' } catch {}
    }
    if (-not $server) { throw 'ConfigMgr site server not found. Set "SccmServer" in config.json (e.g. "cm01.corp.example").' }

    $s = New-EPCimSession -ComputerName $server
    try {
        $loc = Get-CimInstance -CimSession $s -Namespace 'root\sms' -ClassName SMS_ProviderLocation -ErrorAction Stop |
            Where-Object { $_.ProviderForLocalSite } | Select-Object -First 1
    } catch {
        Remove-CimSession $s -ErrorAction SilentlyContinue
        throw "$server ($how) is not a ConfigMgr site server or you have no access to root\sms. Set ""SccmServer"" in config.json. Detail: $($_.Exception.Message)"
    }
    if (-not $loc) { Remove-CimSession $s -ErrorAction SilentlyContinue; throw "No SMS Provider found on $server ($how)." }

    $provider = [string]$loc.Machine
    if ($provider.Split('.')[0] -ne $server.Split('.')[0]) {
        Remove-CimSession $s -ErrorAction SilentlyContinue
        $s = New-EPCimSession -ComputerName $provider
    }
    Write-EPLog "SMS Provider $provider, site $($loc.SiteCode) (found via $how)" -Level debug
    [pscustomobject]@{ Server = $provider; SiteCode = [string]$loc.SiteCode; Namespace = "root\sms\site_$($loc.SiteCode)"; Session = $s }
}

# Query rules that list computers by name, e.g. ... where SMS_R_System.Name in ("PC01","PC02")
$script:NameListRx = '(?i)\.(?:Name|NetbiosName)\s+in\s*\(([^)]*)\)'

function Test-EPQueryNameList {
    param([string]$Query)
    return [bool]($Query -and [regex]::IsMatch($Query, $script:NameListRx))
}

function Get-EPQueryNameList {
    <# Returns the computer names in the IN (...) list of a collection query (upper case, no empties). #>
    param([Parameter(Mandatory)][string]$Query)
    $m = [regex]::Match($Query, $script:NameListRx)
    if (-not $m.Success) { return @() }
    @([regex]::Matches($m.Groups[1].Value, '["'']([^"'']*)["'']') |
        ForEach-Object { $_.Groups[1].Value.Trim().ToUpper() } | Where-Object { $_ } | Select-Object -Unique)
}

function Set-EPQueryNameList {
    <# Rewrites ONLY the IN (...) list of the query; every other part of the query is kept as it is. #>
    param([Parameter(Mandatory)][string]$Query, [string[]]$Names = @())
    $m = [regex]::Match($Query, $script:NameListRx)
    if (-not $m.Success) { throw 'The query does not contain a "Name in (...)" list.' }
    $names = @($Names | Where-Object { $_ })
    $inner = if ($names.Count) { ($names | ForEach-Object { '"' + $_ + '"' }) -join ',' } else { '""' }
    $g = $m.Groups[1]
    $Query.Substring(0, $g.Index) + $inner + $Query.Substring($g.Index + $g.Length)
}

$script:Win32Codes = @{
    0 = 'Success'; 1 = 'Not supported'; 2 = 'Access denied'; 3 = 'Dependent services are running'
    5 = 'Service cannot accept control messages now'; 7 = 'Timed out'; 8 = 'Unknown failure'
    10 = 'Service is already running'; 14 = 'Service is disabled'; 15 = 'Service logon failed'
    9 = 'Path not found'; 21 = 'Invalid parameter'
}
function Get-EPWin32Message { param([int]$Code) if ($script:Win32Codes.ContainsKey($Code)) { $script:Win32Codes[$Code] } else { "Code $Code" } }

Export-ModuleMember -Function *-EP*
