#if POWERSHELL
// Real WinRM/PowerShell runner. Compiled only when the POWERSHELL constant is defined
// AND the Microsoft.PowerShell.SDK package is referenced (see EndpointPortal.Api.csproj
// and IMPLEMENTATION.docx). Windows only.
using System.Collections.ObjectModel;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using EndpointPortal.Api.Models;

namespace EndpointPortal.Api.Services;

public sealed class PowerShellRemoteRunner : IRemoteRunner
{
    private readonly ScriptCatalog _scripts;
    private readonly IConfiguration _config;

    public PowerShellRemoteRunner(ScriptCatalog scripts, IConfiguration config)
    {
        _scripts = scripts;
        _config = config;
    }

    private Runspace Open(string host)
    {
        // Uses the service account's Kerberos credentials by default. For an explicit
        // credential, read it from a secret store and build a PSCredential here.
        var port = int.TryParse(_config["WinRM:Port"], out var p) ? p : 5985;
        var useSsl = bool.TryParse(_config["WinRM:UseSsl"], out var s) && s;
        var ci = new WSManConnectionInfo(useSsl, host, port, "/wsman",
            "http://schemas.microsoft.com/powershell/Microsoft.PowerShell",
            (PSCredential)null!); // null = use the service account's default (Kerberos) credentials
        ci.OperationTimeout = 60_000;
        ci.OpenTimeout = 30_000;
        var rs = RunspaceFactory.CreateRunspace(ci);
        rs.Open();
        return rs;
    }

    private async Task<Collection<PSObject>> InvokeAsync(string host, string script, IDictionary<string, object>? parameters = null)
    {
        using var rs = Open(host);
        using var ps = PowerShell.Create();
        ps.Runspace = rs;
        ps.AddScript(script);
        if (parameters is not null)
            foreach (var kv in parameters) ps.AddParameter(kv.Key, kv.Value);
        var result = await Task.Run(() => ps.Invoke());
        if (ps.HadErrors)
            throw new InvalidOperationException(string.Join("; ", ps.Streams.Error.Select(e => e.ToString())));
        return result;
    }

    public async Task<DeviceInfo> ConnectAsync(string host)
    {
        // Real health snapshot collected from the target in one remote call.
        const string script = @"
$ErrorActionPreference='SilentlyContinue'
$os=Get-CimInstance Win32_OperatingSystem
$disk=Get-CimInstance Win32_LogicalDisk -Filter ""DeviceID='C:'""
$cs=Get-CimInstance Win32_ComputerSystem
[pscustomobject]@{
  CcmExec=""$((Get-Service ccmexec).Status)""
  AgentVersion=""$((Get-CimInstance -Namespace root\ccm -ClassName SMS_Client).ClientVersion)""
  FreeDiskGB=[math]::Round($disk.FreeSpace/1GB,1)
  OS=$os.Caption
  LastBoot=$os.LastBootUpTime
  Model=$cs.Model
  User=$cs.UserName
}";
        var o = (await InvokeAsync(host, script)).FirstOrDefault();
        string P(string n) => o?.Properties[n]?.Value?.ToString() ?? "n/a";
        var svc = P("CcmExec");
        var diags = new[]
        {
            new Diagnostic("CcmExec Service", svc, svc == "Running" ? "ok" : "crit"),
            new Diagnostic("Agent Version", P("AgentVersion"), "info"),
            new Diagnostic("Disk Space (C:)", P("FreeDiskGB") + " GB Free", "info"),
            new Diagnostic("OS", P("OS"), "info"),
            new Diagnostic("Last Boot", P("LastBoot"), "info"),
            new Diagnostic("Model", P("Model"), "info"),
            new Diagnostic("Logged-on User", P("User"), "info"),
        };
        return new DeviceInfo(host, P("User"), "", "", true, diags);
    }

    public async Task<ActionResult> RunClientActionAsync(string host, string cycle)
    {
        if (!_scripts.TryGetPath("Invoke-CcmClientAction", out var path))
            return new ActionResult(false, "Invoke-CcmClientAction.ps1 not found.");
        await InvokeAsync(host, File.ReadAllText(path), new Dictionary<string, object> { ["Action"] = cycle });
        return new ActionResult(true, $"Client action '{cycle}' triggered on {host}.");
    }

    public async Task<IReadOnlyList<ServiceInfo>> GetServicesAsync(string host)
    {
        var r = await InvokeAsync(host, "Get-Service | Select-Object Name,Status,StartType");
        return r.Select(o => new ServiceInfo(
            o.Properties["Name"]?.Value?.ToString() ?? "",
            o.Properties["Status"]?.Value?.ToString() ?? "",
            o.Properties["StartType"]?.Value?.ToString() ?? "")).ToArray();
    }

    public async Task<ActionResult> ControlServiceAsync(string host, string name, string op)
    {
        var verb = op.ToLowerInvariant() switch { "start" => "Start-Service", "stop" => "Stop-Service", _ => "Restart-Service" };
        await InvokeAsync(host, $"{verb} -Name '{name.Replace("'", "''")}' -Force");
        return new ActionResult(true, $"Service '{name}' {op} on {host}.");
    }

    public async Task<IReadOnlyList<ProcessInfo>> GetProcessesAsync(string host)
    {
        var r = await InvokeAsync(host, "Get-Process | Select-Object Name,@{n='MB';e={[math]::Round($_.WorkingSet64/1MB)}}");
        return r.Select(o => new ProcessInfo(
            o.Properties["Name"]?.Value?.ToString() ?? "",
            $"{o.Properties["MB"]?.Value} MB", "")).ToArray();
    }

    public async Task<ActionResult> RunScriptAsync(string host, string scriptName, IReadOnlyDictionary<string, string>? parameters = null)
    {
        if (!_scripts.TryGetPath(scriptName, out var path))
            return new ActionResult(false, $"Script '{scriptName}' not found.");
        var args = parameters?.ToDictionary(k => k.Key, v => (object)v.Value);
        await InvokeAsync(host, File.ReadAllText(path), args);
        return new ActionResult(true, $"Script '{scriptName}' executed on {host}.");
    }

    public async Task<SecretResult> GetLapsAsync(string host)
    {
        if (!_scripts.TryGetPath("Get-LapsPassword", out var path))
            return new SecretResult("Administrator", "", null);
        var r = await InvokeAsync(host, File.ReadAllText(path), new Dictionary<string, object> { ["ComputerName"] = host });
        var o = r.FirstOrDefault();
        return new SecretResult(
            o?.Properties["Account"]?.Value?.ToString() ?? "Administrator",
            o?.Properties["Password"]?.Value?.ToString() ?? "",
            o?.Properties["ExpirationTimestamp"]?.Value as DateTimeOffset?);
    }

    public async Task<SecretResult> GetBitLockerKeyAsync(string host)
    {
        if (!_scripts.TryGetPath("Get-BitLockerRecoveryKey", out var path))
            return new SecretResult("C:", "", null);
        var r = await InvokeAsync(host, File.ReadAllText(path));
        var o = r.FirstOrDefault();
        return new SecretResult("C:", o?.Properties["RecoveryPassword"]?.Value?.ToString() ?? "", null);
    }
}
#endif
