<#
.SYNOPSIS  Takes the agent out of provisioning mode (common after a failed OSD).
.NOTES     Endpoint Portal Tool 1.4.2
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
$dcom = Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    $prov = Get-EPRegValue -CimSession $s -Key 'SOFTWARE\Microsoft\CCM\CcmExec' -Name 'ProvisioningMode'
    Write-EPLog "Current ProvisioningMode: $(if ($prov) { $prov } else { 'not set' })" -Level info
    ([string]$s.Protocol -eq 'Dcom')
}
$r = @(Invoke-EPClientMethod -ComputerName $ComputerName -Calls @(@{ Label = 'SetClientProvisioningMode(false)'; Method = 'SetClientProvisioningMode'; Args = @($false) }) -PreferDcom:$dcom)
if (-not $r[0].Ok) { throw "SetClientProvisioningMode: $($r[0].Detail)" }
Write-EPLog "Provisioning mode disabled (via $($r[0].Via))." -Level ok
"Provisioning mode disabled on $ComputerName."
