<#
.SYNOPSIS  Resets agent policies (SMS_Client.ResetPolicy) and requests Machine Policy again.
.PARAMETER Mode  Soft = re-applies policies; Hard = purges all policies and downloads them again.
.NOTES     Endpoint Portal Tool 1.4.2
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [ValidateSet('Soft', 'Hard')][string]$Mode = 'Hard'
)
$ErrorActionPreference = 'Stop'
$dcom = Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    ([string]$s.Protocol -eq 'Dcom')
}

Write-EPProgress 30 "Policy reset ($Mode)"
$flag = [uint32]0
if ($Mode -eq 'Hard') { $flag = [uint32]1 }
$r = @(Invoke-EPClientMethod -ComputerName $ComputerName -Calls @(@{ Label = "ResetPolicy($flag)"; Method = 'ResetPolicy'; Args = @($flag) }) -PreferDcom:$dcom)
if (-not $r[0].Ok) { throw "ResetPolicy($flag): $($r[0].Detail)" }
Write-EPLog "ResetPolicy($flag) executed (via $($r[0].Via))." -Level ok

Start-Sleep -Seconds 3
Write-EPProgress 70 'Requesting Machine Policy'
$r = @(Invoke-EPClientMethod -ComputerName $ComputerName -Calls @(@{ Label = 'Machine Policy Retrieval'; Method = 'TriggerSchedule'; Args = @('{00000000-0000-0000-0000-000000000021}') }) -PreferDcom:$dcom)
if (-not $r[0].Ok) { throw "Policies were reset, but Machine Policy Retrieval failed: $($r[0].Detail). Run 'Machine Policy Retrieval' again in a minute." }
Write-EPLog 'Machine Policy Retrieval triggered.' -Level ok
Write-EPProgress 100
"Policies reset ($Mode) on $ComputerName. Follow PolicyAgent.log."
