<#
.SYNOPSIS  Triggers ConfigMgr agent cycles (same as "Agent Actions" / "Client Actions").
.PARAMETER Action  Cycle name, or 'All' to run the main cycles in sequence.
.NOTES     Endpoint Portal Tool 1.4.2
           SMS_Client.TriggerSchedule runs on the endpoint (PowerShell remoting) or over DCOM, never with
           Invoke-CimMethod over WinRM (that path returns 0x8004101e even when the cycle runs).
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][string]$Action
)
$ErrorActionPreference = 'Stop'

$Schedules = [ordered]@{
    MachinePolicy        = @{ Id = '{00000000-0000-0000-0000-000000000021}'; Name = 'Machine Policy Retrieval & Evaluation' }
    MachinePolicyEval    = @{ Id = '{00000000-0000-0000-0000-000000000022}'; Name = 'Machine Policy Evaluation' }
    AppDeployment        = @{ Id = '{00000000-0000-0000-0000-000000000121}'; Name = 'Application Deployment Evaluation' }
    AppGlobalEval        = @{ Id = '{00000000-0000-0000-0000-000000000123}'; Name = 'Application Manager Global Evaluation' }
    UpdateScan           = @{ Id = '{00000000-0000-0000-0000-000000000113}'; Name = 'Software Update Scan' }
    UpdateDeployment     = @{ Id = '{00000000-0000-0000-0000-000000000108}'; Name = 'Software Update Deployment Evaluation' }
    HardwareInventory    = @{ Id = '{00000000-0000-0000-0000-000000000001}'; Name = 'Hardware Inventory' }
    SoftwareInventory    = @{ Id = '{00000000-0000-0000-0000-000000000002}'; Name = 'Software Inventory' }
    DiscoveryData        = @{ Id = '{00000000-0000-0000-0000-000000000003}'; Name = 'Discovery Data Collection (DDR)' }
    FileCollection       = @{ Id = '{00000000-0000-0000-0000-000000000010}'; Name = 'File Collection' }
    SoftwareMetering     = @{ Id = '{00000000-0000-0000-0000-000000000031}'; Name = 'Software Metering Usage Report' }
    InstallerSourceList  = @{ Id = '{00000000-0000-0000-0000-000000000032}'; Name = 'Windows Installer Source List Update' }
    StateMessages        = @{ Id = '{00000000-0000-0000-0000-000000000111}'; Name = 'Send Unsent State Messages' }
    RefreshDefaultMP     = @{ Id = '{00000000-0000-0000-0000-000000000023}'; Name = 'Refresh Default MP' }
    RefreshLocations     = @{ Id = '{00000000-0000-0000-0000-000000000024}'; Name = 'Location Service Refresh Locations' }
    MachinePolicyCleanup = @{ Id = '{00000000-0000-0000-0000-000000000040}'; Name = 'Machine Policy Agent Cleanup' }
    ValidateMachinePolicy= @{ Id = '{00000000-0000-0000-0000-000000000042}'; Name = 'Policy Agent Validate Machine Policy' }
    UpdateStorePolicy    = @{ Id = '{00000000-0000-0000-0000-000000000114}'; Name = 'Update Store Policy' }
}

$AllSet = 'MachinePolicy', 'MachinePolicyEval', 'AppDeployment', 'UpdateScan', 'UpdateDeployment',
          'HardwareInventory', 'SoftwareInventory', 'DiscoveryData', 'FileCollection', 'StateMessages'

$list = @(if ($Action -eq 'All') { $AllSet } else { $Action })
foreach ($a in $list) { if (-not $Schedules.Contains($a)) { throw "Unknown client action: $a" } }

# Check the agent (read-only CIM query) and remember which transport works
Write-EPProgress 10 'Checking the ConfigMgr agent'
$s = New-EPCimSession -ComputerName $ComputerName
try {
    Assert-EPCcmClient -CimSession $s
    $dcom = ([string]$s.Protocol -eq 'Dcom')
} finally { Remove-CimSession $s -ErrorAction SilentlyContinue }

Write-EPProgress 40 $(if ($list.Count -eq 1) { $Schedules[$list[0]].Name } else { "Triggering $($list.Count) cycles" })
$calls = @(foreach ($a in $list) { @{ Label = $Schedules[$a].Name; Method = 'TriggerSchedule'; Args = @($Schedules[$a].Id) } })
$results = @(Invoke-EPClientMethod -ComputerName $ComputerName -Calls $calls -PreferDcom:$dcom)

$ok = 0
foreach ($r in $results) {
    if ($r.Ok) { $ok++; Write-EPLog "$($r.Label): triggered (via $($r.Via))" -Level ok }
    else { Write-EPLog "$($r.Label): $($r.Detail)" -Level error }
}
Write-EPProgress 100 'Done'
if ($ok -eq 0) { throw "No action was accepted by the agent on $ComputerName." }
"$ok of $($list.Count) action(s) accepted by the agent on $ComputerName. Check the client logs for the outcome."
