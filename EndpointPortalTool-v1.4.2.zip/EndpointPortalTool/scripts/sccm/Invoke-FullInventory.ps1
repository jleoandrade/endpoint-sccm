<#
.SYNOPSIS  FULL hardware or software inventory: removes the last cycle status and triggers it again.
.NOTES     Endpoint Portal Tool 1.4.2
#>
param(
    [Parameter(Mandatory)][string]$ComputerName,
    [Parameter(Mandatory)][ValidateSet('Hardware', 'Software', 'Discovery')][string]$Type
)
$ErrorActionPreference = 'Stop'
$ids = @{ Hardware = '{00000000-0000-0000-0000-000000000001}'; Software = '{00000000-0000-0000-0000-000000000002}'; Discovery = '{00000000-0000-0000-0000-000000000003}' }
$id = $ids[$Type]

$dcom = Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    Write-EPProgress 30 "Removing last $Type inventory status"
    $st = Get-CimInstance -CimSession $s -Namespace 'root\ccm\invagt' -ClassName InventoryActionStatus -Filter "InventoryActionID='$id'"
    if ($st) { $st | Remove-CimInstance; Write-EPLog 'Previous status removed (the next report will be a full one).' -Level info }
    else { Write-EPLog 'No previous status found.' -Level debug }
    ([string]$s.Protocol -eq 'Dcom')
}

Write-EPProgress 70 'Triggering cycle'
$r = @(Invoke-EPClientMethod -ComputerName $ComputerName -Calls @(@{ Label = "$Type Inventory"; Method = 'TriggerSchedule'; Args = @($id) }) -PreferDcom:$dcom)
if (-not $r[0].Ok) { throw "$Type Inventory: $($r[0].Detail)" }
Write-EPLog "Full $Type inventory triggered (via $($r[0].Via))." -Level ok
Write-EPProgress 100
"Full $Type inventory triggered on $ComputerName. See InventoryAgent.log."
