<#
.SYNOPSIS  Repairs the ConfigMgr agent (SMS_Client.RepairClient -> ccmrepair).
.NOTES     Endpoint Portal Tool 1.4.2
#>
param([Parameter(Mandatory)][string]$ComputerName)
$ErrorActionPreference = 'Stop'
$dcom = Invoke-EPCim -ComputerName $ComputerName -ScriptBlock {
    param($s)
    Assert-EPCcmClient -CimSession $s
    ([string]$s.Protocol -eq 'Dcom')
}
Write-EPProgress 40 'Starting agent repair'
$r = @(Invoke-EPClientMethod -ComputerName $ComputerName -Calls @(@{ Label = 'RepairClient'; Method = 'RepairClient'; Args = @() }) -PreferDcom:$dcom)
if (-not $r[0].Ok) { throw "RepairClient: $($r[0].Detail)" }
Write-EPLog "Repair started (via $($r[0].Via)). The CcmExec service will be restarted by the agent itself." -Level ok
Write-EPProgress 100
"Agent repair started on $ComputerName. Follow C:\Windows\CCM\Logs\ccmrepair.log / ccmsetup.log."
